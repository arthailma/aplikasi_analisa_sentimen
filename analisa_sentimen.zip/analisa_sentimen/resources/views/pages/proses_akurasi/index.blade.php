@extends('layouts.master')
@section('content')



<div class="page-wrapper">
    <!-- Bread crumb -->
    <div class="row page-titles">
        <div class="col-md-5 align-self-center">
            <h3 class="text-primary">Dashboard</h3> </div>
        <div class="col-md-7 align-self-center">
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="javascript:void(0)">Home</a></li>
                <li class="breadcrumb-item active">Dashboard</li>
            </ol>
        </div>
    </div>
    <!-- End Bread crumb -->
    <!-- Container fluid  -->
    <?php
    if($ekspektasi_positif_cocok == 0){

    }else{
    ?>

    <div class="container-fluid">
        <!-- Start Page Content -->
        <div class="row">
            <div class="col-lg-6">
                <div class="card">
                    <!-- <p>Viterbi</p> -->
                    <div class="card-title">
                        <h4>Opinion Detection (POSTagging Viterbi dan Rule Opinion)</h4>
                    </div>
                    Diketahui :
                    <!-- <br>Jumlah dataset viterbi =<?php echo $realita_opini+$realita_bukan_opini;?> -->
                    <br>Jumlah realita postagging label opini =<?php echo $realita_opini;?>
                    <br>Jumlah realita postagging label bukan opini = <?php echo $realita_bukan_opini; ?>
                    <br><br>Jumlah ekspektasi label postagging opini, status postagging cocok (OC) = <?php echo $ekspektasi_opini_cocok; ?>
                    <br>Jumlah ekspektasi label postagging opini, status postagging tidak cocok (OTC) = <?php echo $ekspektasi_opini_tidak_cocok; ?>
                    <br>Jumlah ekspektasi label postagging bukan opini, status postagging cocok (BOC) = <?php echo $ekspektasi_bukan_opini_cocok; ?>
                    <br>Jumlah ekspektasi label postagging bukan opini, status postagging tidak cocok (BOTC) = <?php echo $ekspektasi_bukan_opini_tidak_cocok; ?>
                </div>
            </div>
            <div class="col-lg-6">
                <div class="card">
                    <!-- <p>Naive Bayes</p> -->
                    <div class="card-title">
                        <h4>Naive Bayes</h4>
                    </div>
                    Diketahui :
                    <!-- <br>Jumlah dataset naive bayes =<?php echo $realita_positif+$realita_negatif;?> -->
                    <br>Jumlah realita naive bayes label positif =<?php echo $realita_positif;?>
                    <br>Jumlah realita naive bayes label negatif = <?php echo $realita_negatif; ?>
                    <br><br>Jumlah ekspektasi label naive bayes positif, status naive bayes cocok (PC) = <?php echo $ekspektasi_positif_cocok; ?>
                    <br>Jumlah ekspektasi label naive bayes positif, status naive bayes tidak cocok (PTC) = <?php echo $ekspektasi_positif_tidak_cocok; ?>
                    <br>Jumlah ekspektasi label naive bayes negatif, status naive bayes cocok (NC) = <?php echo $ekspektasi_negatif_cocok; ?>
                    <br>Jumlah ekspektasi label naive bayes negatif, status naive bayes tidak cocok (NTC) = <?php echo $ekspektasi_negatif_tidak_cocok; ?>
                </div>
            </div>
        </div>

        <div class="row">
            <div class="col-lg-6">
                <div class="card">
                    <p>Perhitungan Akurasi (Opinion Detection) <span class="tooltips" tooltip="
                      <table>
                        <tr>
                          <td style='color:white; vertical-align: top; text-align: left;'>
                            akurasi opinion detection menjawab pertanyaan :
                          </td>
                        </tr>
                        <tr>
                          <td style='color:white; vertical-align: top; text-align: left;'>
                            Berapa persen tweet yang benar diprediksi opini cocok dan bukan opini cocok dari kesuluruhan tweet (120)
                          </td>
                        </tr>
                      </table>" tooltip-position="right" tooltip-type="success"><button id="button" class="btn btn-success btn-xs "><i class="fa fa-info" aria-hidden="true"></i></button></span></p>


                    <div class="card-content">
                      <table>
                        <tr>
                          <td style="vertical-align: top; text-align: left;">
                            Rumus
                          </td>
                          <td style="vertical-align: top; text-align: left;">
                            :
                          </td>
                          <td style="vertical-align: top; text-align: left;">
                            (OC + BOC)/(OC + OTC + BOC + BOTC) * 100%
                          </td>
                        </tr>
                        <tr>
                          <td style="vertical-align: top; text-align: left;">

                          </td>
                          <td style="vertical-align: top; text-align: left;">
                            :
                          </td>
                          <td style="vertical-align: top; text-align: left;">
                            <?php echo '('.$ekspektasi_opini_cocok.' + '.$ekspektasi_bukan_opini_cocok.')/('.$ekspektasi_opini_cocok.' + '.$ekspektasi_opini_tidak_cocok.' + '.$ekspektasi_bukan_opini_cocok.' + '.$ekspektasi_bukan_opini_tidak_cocok.') * 100%' ?>
                          </td>
                        </tr>
                        <tr>
                          <td style="vertical-align: top; text-align: left;">

                          </td>
                          <td style="vertical-align: top; text-align: left;">
                            :
                          </td>
                          <td style="vertical-align: top; text-align: left;">
                            <?php echo '('.($ekspektasi_opini_cocok+$ekspektasi_bukan_opini_cocok).')/('.($ekspektasi_opini_cocok+$ekspektasi_opini_tidak_cocok+$ekspektasi_bukan_opini_cocok+$ekspektasi_bukan_opini_tidak_cocok).') * 100%' ?>
                          </td>
                        </tr>
                        <tr>
                          <td style="vertical-align: top; text-align: left;">

                          </td>
                          <td style="vertical-align: top; text-align: left;">
                            :
                          </td>
                          <td style="vertical-align: top; text-align: left;">
                            <?php echo '('.($ekspektasi_opini_cocok+$ekspektasi_bukan_opini_cocok)/($ekspektasi_opini_cocok+$ekspektasi_opini_tidak_cocok+$ekspektasi_bukan_opini_cocok+$ekspektasi_bukan_opini_tidak_cocok).') * 100%' ?>
                          </td>
                        </tr>
                        <tr>
                          <td style="vertical-align: top; text-align: left;">

                          </td>
                          <td style="vertical-align: top; text-align: left;">
                            :
                          </td>
                          <td style="vertical-align: top; text-align: left;">
                            <?php echo ($ekspektasi_opini_cocok+$ekspektasi_bukan_opini_cocok)/($ekspektasi_opini_cocok+$ekspektasi_opini_tidak_cocok+$ekspektasi_bukan_opini_cocok+$ekspektasi_bukan_opini_tidak_cocok)* 100 .'%' ?>
                          </td>
                        </tr>
                      </table>

                    </div>
                </div>
            </div>
            <div class="col-lg-6">
                <div class="card">
                    <div class="card-content">
                      <p>Perhitungan Akurasi (Naive Bayes) <span class="tooltips" tooltip="
                        <table>
                          <tr>
                            <td style='color:white; vertical-align: top; text-align: left;'>
                              akurasi naive bayes menjawab pertanyaan :
                            </td>
                          </tr>
                          <tr>
                            <td style='color:white; vertical-align: top; text-align: left;'>
                              Berapa persen tweet yang benar diprediksi positif cocok dan negatif cocok dari kesuluruhan tweet (90)
                            </td>
                          </tr>
                        </table>" tooltip-position="right" tooltip-type="success"><button id="button" class="btn btn-success btn-xs "><i class="fa fa-info" aria-hidden="true"></i></button></span></p>
                      <div class="card-content">
                        <table>
                          <tr>
                            <td style="vertical-align: top; text-align: left;">
                              Rumus
                            </td>
                            <td style="vertical-align: top; text-align: left;">
                              :
                            </td>
                            <td style="vertical-align: top; text-align: left;">
                              (PC + NC)/(PC + PTC + NC + NTC) * 100%
                            </td>
                          </tr>
                          <tr>
                            <td style="vertical-align: top; text-align: left;">

                            </td>
                            <td style="vertical-align: top; text-align: left;">
                              :
                            </td>
                            <td style="vertical-align: top; text-align: left;">
                              <?php echo '('.$ekspektasi_positif_cocok.' + '.$ekspektasi_negatif_cocok.')/('.$ekspektasi_positif_cocok.' + '.$ekspektasi_positif_tidak_cocok.' + '.$ekspektasi_negatif_cocok.' + '.$ekspektasi_negatif_tidak_cocok.') * 100%' ?>
                            </td>
                          </tr>
                          <tr>
                            <td style="vertical-align: top; text-align: left;">

                            </td>
                            <td style="vertical-align: top; text-align: left;">
                              :
                            </td>
                            <td style="vertical-align: top; text-align: left;">
                              <?php echo '('.($ekspektasi_positif_cocok+$ekspektasi_negatif_cocok).')/('.($ekspektasi_positif_cocok+$ekspektasi_positif_tidak_cocok+$ekspektasi_negatif_cocok+$ekspektasi_negatif_tidak_cocok).') * 100%' ?>
                            </td>
                          </tr>
                          <tr>
                            <td style="vertical-align: top; text-align: left;">

                            </td>
                            <td style="vertical-align: top; text-align: left;">
                              :
                            </td>
                            <td style="vertical-align: top; text-align: left;">
                              <?php echo '('.($ekspektasi_positif_cocok+$ekspektasi_negatif_cocok)/($ekspektasi_positif_cocok+$ekspektasi_positif_tidak_cocok+$ekspektasi_negatif_cocok+$ekspektasi_negatif_tidak_cocok).') * 100%' ?>
                            </td>
                          </tr>
                          <tr>
                            <td style="vertical-align: top; text-align: left;">

                            </td>
                            <td style="vertical-align: top; text-align: left;">
                              :
                            </td>
                            <td style="vertical-align: top; text-align: left;">
                              <?php echo ($ekspektasi_positif_cocok+$ekspektasi_negatif_cocok)/($ekspektasi_positif_cocok+$ekspektasi_positif_tidak_cocok+$ekspektasi_negatif_cocok+$ekspektasi_negatif_tidak_cocok)* 100 .'%' ?>
                            </td>
                          </tr>
                        </table>
                    </div>
                </div>
            </div>
        </div>

        <!-- <div class="row">
            <div class="col-lg-6">
                <div class="card">
                    <p>Viterbi</p>
                    <div class="card-content">
                        <div id="akurasi_postagging" style="height: 370px"></div>
                    </div>
                </div>
            </div>
            <div class="col-lg-6">
                <div class="card">
                    <p>Naive Bayes</p>
                    <div class="card-content">
                        <div id="akurasi_postagging" style="height: 370px"></div>
                    </div>
                </div>
            </div>
        </div> -->
        <!-- End PAge Content -->
    </div>

    <div class="row">
        <div class="col-lg-6">
            <div class="card">
                <p>Perhitungan Precision Opini <span class="tooltips" tooltip="
                  <table>
                    <tr>
                      <td style='color:white; vertical-align: top; text-align: left;'>
                        precision opini menjawab pertanyaan :
                      </td>
                    </tr>
                    <tr>
                      <td style='color:white; vertical-align: top; text-align: left;'>
                        Berapa persen tweet yang benar opini dari keseluruhan tweet yang diprediksi opini? (120)
                      </td>
                    </tr>
                  </table>" tooltip-position="right" tooltip-type="success"><button id="button" class="btn btn-success btn-xs "><i class="fa fa-info" aria-hidden="true"></i></button></span></p>
                <div class="card-content">
                  <table>
                    <tr>
                      <td style="vertical-align: top; text-align: left;">
                        Rumus
                      </td>
                      <td style="vertical-align: top; text-align: left;">
                        :
                      </td>
                      <td style="vertical-align: top; text-align: left;">
                        (OC)/(OC + OTC) * 100%
                      </td>
                    </tr>
                    <tr>
                      <td style="vertical-align: top; text-align: left;">

                      </td>
                      <td style="vertical-align: top; text-align: left;">
                        :
                      </td>
                      <td style="vertical-align: top; text-align: left;">
                        <?php echo '('.$ekspektasi_opini_cocok.')/('.$ekspektasi_opini_cocok.' + '.$ekspektasi_opini_tidak_cocok.') * 100%' ?>
                      </td>
                    </tr>
                    <tr>
                      <td style="vertical-align: top; text-align: left;">

                      </td>
                      <td style="vertical-align: top; text-align: left;">
                        :
                      </td>
                      <td style="vertical-align: top; text-align: left;">
                        <?php echo '('.($ekspektasi_opini_cocok).')/('.($ekspektasi_opini_cocok+$ekspektasi_opini_tidak_cocok).') * 100%' ?>
                      </td>
                    </tr>
                    <tr>
                      <td style="vertical-align: top; text-align: left;">

                      </td>
                      <td style="vertical-align: top; text-align: left;">
                        :
                      </td>
                      <td style="vertical-align: top; text-align: left;">
                        <?php echo '('.($ekspektasi_opini_cocok)/($ekspektasi_opini_cocok+$ekspektasi_opini_tidak_cocok).') * 100%' ?>
                      </td>
                    </tr>
                    <tr>
                      <td style="vertical-align: top; text-align: left;">

                      </td>
                      <td style="vertical-align: top; text-align: left;">
                        :
                      </td>
                      <td style="vertical-align: top; text-align: left;">
                        <?php echo ($ekspektasi_opini_cocok)/($ekspektasi_opini_cocok+$ekspektasi_opini_tidak_cocok)* 100 .'%' ?>
                      </td>
                    </tr>
                  </table>

                </div>
            </div>
        </div>
        <div class="col-lg-6">
            <div class="card">
                <div class="card-content">
                  <p>Perhitungan Precision sentimen positif <span class="tooltips" tooltip="
                    <table>
                      <tr>
                        <td style='color:white; vertical-align: top; text-align: left;'>
                          precision naive bayes sentimen positif menjawab pertanyaan :
                        </td>
                      </tr>
                      <tr>
                        <td style='color:white; vertical-align: top; text-align: left;'>
                          Berapa persen tweet yang benar sentimen positif dari keseluruhan tweet yang diprediksi sentimen positif? (90)
                        </td>
                      </tr>
                    </table>" tooltip-position="right" tooltip-type="success"><button id="button" class="btn btn-success btn-xs "><i class="fa fa-info" aria-hidden="true"></i></button></span></p>
                  <div class="card-content">
                    <table>
                      <tr>
                        <td style="vertical-align: top; text-align: left;">
                          Rumus
                        </td>
                        <td style="vertical-align: top; text-align: left;">
                          :
                        </td>
                        <td style="vertical-align: top; text-align: left;">
                          (PC)/(PC + PTC) * 100%
                        </td>
                      </tr>
                      <tr>
                        <td style="vertical-align: top; text-align: left;">

                        </td>
                        <td style="vertical-align: top; text-align: left;">
                          :
                        </td>
                        <td style="vertical-align: top; text-align: left;">
                          <?php echo '('.$ekspektasi_positif_cocok.')/('.$ekspektasi_positif_cocok.' + '.$ekspektasi_positif_tidak_cocok.') * 100%' ?>
                        </td>
                      </tr>
                      <tr>
                        <td style="vertical-align: top; text-align: left;">

                        </td>
                        <td style="vertical-align: top; text-align: left;">
                          :
                        </td>
                        <td style="vertical-align: top; text-align: left;">
                          <?php echo '('.($ekspektasi_positif_cocok).')/('.($ekspektasi_positif_cocok+$ekspektasi_positif_tidak_cocok).') * 100%' ?>
                        </td>
                      </tr>
                      <tr>
                        <td style="vertical-align: top; text-align: left;">

                        </td>
                        <td style="vertical-align: top; text-align: left;">
                          :
                        </td>
                        <td style="vertical-align: top; text-align: left;">
                          <?php echo '('.($ekspektasi_positif_cocok)/($ekspektasi_positif_cocok+$ekspektasi_positif_tidak_cocok).') * 100%' ?>
                        </td>
                      </tr>
                      <tr>
                        <td style="vertical-align: top; text-align: left;">

                        </td>
                        <td style="vertical-align: top; text-align: left;">
                          :
                        </td>
                        <td style="vertical-align: top; text-align: left;">
                          <?php echo ($ekspektasi_positif_cocok)/($ekspektasi_positif_cocok+$ekspektasi_positif_tidak_cocok)* 100 .'%' ?>
                        </td>
                      </tr>
                    </table>
                </div>
            </div>
        </div>
    </div>


    <!-- End PAge Content -->
</div>
<div class="row">
    <div class="col-lg-6">
        <div class="card">
            <p>Perhitungan Precision Bukan Opini <span class="tooltips" tooltip="
              <table>
                <tr>
                  <td style='color:white; vertical-align: top; text-align: left;'>
                    precision opini menjawab pertanyaan :
                  </td>
                </tr>
                <tr>
                  <td style='color:white; vertical-align: top; text-align: left;'>
                    Berapa persen tweet yang benar bukan opini dari keseluruhan tweet yang diprediksi bukan opini? (120)
                  </td>
                </tr>
              </table>" tooltip-position="right" tooltip-type="success"><button id="button" class="btn btn-success btn-xs "><i class="fa fa-info" aria-hidden="true"></i></button></span></p>
            <div class="card-content">
              <table>
                <tr>
                  <td style="vertical-align: top; text-align: left;">
                    Rumus
                  </td>
                  <td style="vertical-align: top; text-align: left;">
                    :
                  </td>
                  <td style="vertical-align: top; text-align: left;">
                    (BOC)/(BOC + BOTC) * 100%
                  </td>
                </tr>
                <tr>
                  <td style="vertical-align: top; text-align: left;">

                  </td>
                  <td style="vertical-align: top; text-align: left;">
                    :
                  </td>
                  <td style="vertical-align: top; text-align: left;">
                    <?php echo '('.$ekspektasi_bukan_opini_cocok.')/('.$ekspektasi_bukan_opini_cocok.' + '.$ekspektasi_bukan_opini_tidak_cocok.') * 100%' ?>
                  </td>
                </tr>
                <tr>
                  <td style="vertical-align: top; text-align: left;">

                  </td>
                  <td style="vertical-align: top; text-align: left;">
                    :
                  </td>
                  <td style="vertical-align: top; text-align: left;">
                    <?php echo '('.($ekspektasi_bukan_opini_cocok).')/('.($ekspektasi_bukan_opini_cocok+$ekspektasi_bukan_opini_tidak_cocok).') * 100%' ?>
                  </td>
                </tr>
                <tr>
                  <td style="vertical-align: top; text-align: left;">

                  </td>
                  <td style="vertical-align: top; text-align: left;">
                    :
                  </td>
                  <td style="vertical-align: top; text-align: left;">
                    <?php echo '('.($ekspektasi_bukan_opini_cocok)/($ekspektasi_bukan_opini_cocok+$ekspektasi_bukan_opini_tidak_cocok).') * 100%' ?>
                  </td>
                </tr>
                <tr>
                  <td style="vertical-align: top; text-align: left;">

                  </td>
                  <td style="vertical-align: top; text-align: left;">
                    :
                  </td>
                  <td style="vertical-align: top; text-align: left;">
                    <?php echo ($ekspektasi_bukan_opini_cocok)/($ekspektasi_bukan_opini_cocok+$ekspektasi_bukan_opini_tidak_cocok)* 100 .'%' ?>
                  </td>
                </tr>
              </table>

            </div>
        </div>
    </div>
    <div class="col-lg-6">
        <div class="card">
            <div class="card-content">
              <p>Perhitungan Precision sentimen negatif <span class="tooltips" tooltip="
                <table>
                  <tr>
                    <td style='color:white; vertical-align: top; text-align: left;'>
                      precision naive bayes sentimen positif menjawab pertanyaan :
                    </td>
                  </tr>
                  <tr>
                    <td style='color:white; vertical-align: top; text-align: left;'>
                      Berapa persen tweet yang benar sentimen negatif dari keseluruhan tweet yang diprediksi sentimen negatif? (90)
                    </td>
                  </tr>
                </table>" tooltip-position="right" tooltip-type="success"><button id="button" class="btn btn-success btn-xs "><i class="fa fa-info" aria-hidden="true"></i></button></span></p>
              <div class="card-content">
                <table>
                  <tr>
                    <td style="vertical-align: top; text-align: left;">
                      Rumus
                    </td>
                    <td style="vertical-align: top; text-align: left;">
                      :
                    </td>
                    <td style="vertical-align: top; text-align: left;">
                      (NC)/(NC + NTC) * 100%
                    </td>
                  </tr>
                  <tr>
                    <td style="vertical-align: top; text-align: left;">

                    </td>
                    <td style="vertical-align: top; text-align: left;">
                      :
                    </td>
                    <td style="vertical-align: top; text-align: left;">
                      <?php echo '('.$ekspektasi_negatif_cocok.')/('.$ekspektasi_negatif_cocok.' + '.$ekspektasi_negatif_tidak_cocok.') * 100%' ?>
                    </td>
                  </tr>
                  <tr>
                    <td style="vertical-align: top; text-align: left;">

                    </td>
                    <td style="vertical-align: top; text-align: left;">
                      :
                    </td>
                    <td style="vertical-align: top; text-align: left;">
                      <?php echo '('.($ekspektasi_negatif_cocok).')/('.($ekspektasi_negatif_cocok+$ekspektasi_negatif_tidak_cocok).') * 100%' ?>
                    </td>
                  </tr>
                  <tr>
                    <td style="vertical-align: top; text-align: left;">

                    </td>
                    <td style="vertical-align: top; text-align: left;">
                      :
                    </td>
                    <td style="vertical-align: top; text-align: left;">
                      <?php echo '('.($ekspektasi_negatif_cocok)/($ekspektasi_negatif_cocok+$ekspektasi_negatif_tidak_cocok).') * 100%' ?>
                    </td>
                  </tr>
                  <tr>
                    <td style="vertical-align: top; text-align: left;">

                    </td>
                    <td style="vertical-align: top; text-align: left;">
                      :
                    </td>
                    <td style="vertical-align: top; text-align: left;">
                      <?php echo ($ekspektasi_negatif_cocok)/($ekspektasi_negatif_cocok+$ekspektasi_negatif_tidak_cocok)* 100 .'%' ?>
                    </td>
                  </tr>
                </table>
            </div>
        </div>
    </div>
</div>


<!-- End PAge Content -->
</div>

<div class="row">
    <div class="col-lg-6">
        <div class="card">
            <p>Perhitungan Recall Opini <span class="tooltips" tooltip="
              <table>
                <tr>
                  <td style='color:white; vertical-align: top; text-align: left;'>
                    recall opini menjawab pertanyaan :
                  </td>
                </tr>
                <tr>
                  <td style='color:white; vertical-align: top; text-align: left;'>
                    Berapa persen tweet yang diprediksi opini dibandingkan keseluruhan tweet yang sebenarnya opini? (120)
                  </td>
                </tr>
              </table>" tooltip-position="right" tooltip-type="success"><button id="button" class="btn btn-success btn-xs "><i class="fa fa-info" aria-hidden="true"></i></button></span></p>
            <div class="card-content">
              <table>
                <tr>
                  <td style="vertical-align: top; text-align: left;">
                    Rumus
                  </td>
                  <td style="vertical-align: top; text-align: left;">
                    :
                  </td>
                  <td style="vertical-align: top; text-align: left;">
                    (OC)/(OC + BOTC) * 100%
                  </td>
                </tr>
                <tr>
                  <td style="vertical-align: top; text-align: left;">

                  </td>
                  <td style="vertical-align: top; text-align: left;">
                    :
                  </td>
                  <td style="vertical-align: top; text-align: left;">
                    <?php echo '('.$ekspektasi_opini_cocok.')/('.$ekspektasi_opini_cocok.' + '.$ekspektasi_bukan_opini_tidak_cocok.') * 100%' ?>
                  </td>
                </tr>
                <tr>
                  <td style="vertical-align: top; text-align: left;">

                  </td>
                  <td style="vertical-align: top; text-align: left;">
                    :
                  </td>
                  <td style="vertical-align: top; text-align: left;">
                    <?php echo '('.($ekspektasi_opini_cocok).')/('.($ekspektasi_opini_cocok+$ekspektasi_bukan_opini_tidak_cocok).') * 100%' ?>
                  </td>
                </tr>
                <tr>
                  <td style="vertical-align: top; text-align: left;">

                  </td>
                  <td style="vertical-align: top; text-align: left;">
                    :
                  </td>
                  <td style="vertical-align: top; text-align: left;">
                    <?php echo '('.($ekspektasi_opini_cocok)/($ekspektasi_opini_cocok+$ekspektasi_bukan_opini_tidak_cocok).') * 100%' ?>
                  </td>
                </tr>
                <tr>
                  <td style="vertical-align: top; text-align: left;">

                  </td>
                  <td style="vertical-align: top; text-align: left;">
                    :
                  </td>
                  <td style="vertical-align: top; text-align: left;">
                    <?php echo ($ekspektasi_opini_cocok)/($ekspektasi_opini_cocok+$ekspektasi_bukan_opini_tidak_cocok)* 100 .'%' ?>
                  </td>
                </tr>
              </table>

            </div>
        </div>
    </div>
    <div class="col-lg-6">
        <div class="card">
            <div class="card-content">
              <p>Perhitungan Recall sentimen positif <span class="tooltips" tooltip="
                <table>
                  <tr>
                    <td style='color:white; vertical-align: top; text-align: left;'>
                      recall naive bayes sentimen positif menjawab pertanyaan :
                    </td>
                  </tr>
                  <tr>
                    <td style='color:white; vertical-align: top; text-align: left;'>
                      Berapa persen tweet yang diprediksi sentimen positif dibandingkan keseluruhan tweet yang sebenarnya sentimen positif? (90)
                    </td>
                  </tr>
                </table>" tooltip-position="right" tooltip-type="success"><button id="button" class="btn btn-success btn-xs "><i class="fa fa-info" aria-hidden="true"></i></button></span></p>
              <div class="card-content">
                <table>
                  <tr>
                    <td style="vertical-align: top; text-align: left;">
                      Rumus
                    </td>
                    <td style="vertical-align: top; text-align: left;">
                      :
                    </td>
                    <td style="vertical-align: top; text-align: left;">
                      (PC)/(PC + NTC) * 100%
                    </td>
                  </tr>
                  <tr>
                    <td style="vertical-align: top; text-align: left;">

                    </td>
                    <td style="vertical-align: top; text-align: left;">
                      :
                    </td>
                    <td style="vertical-align: top; text-align: left;">
                      <?php echo '('.$ekspektasi_positif_cocok.')/('.$ekspektasi_positif_cocok.' + '.$ekspektasi_negatif_tidak_cocok.') * 100%' ?>
                    </td>
                  </tr>
                  <tr>
                    <td style="vertical-align: top; text-align: left;">

                    </td>
                    <td style="vertical-align: top; text-align: left;">
                      :
                    </td>
                    <td style="vertical-align: top; text-align: left;">
                      <?php echo '('.($ekspektasi_positif_cocok).')/('.($ekspektasi_positif_cocok+$ekspektasi_negatif_tidak_cocok).') * 100%' ?>
                    </td>
                  </tr>
                  <tr>
                    <td style="vertical-align: top; text-align: left;">

                    </td>
                    <td style="vertical-align: top; text-align: left;">
                      :
                    </td>
                    <td style="vertical-align: top; text-align: left;">
                      <?php echo '('.($ekspektasi_positif_cocok)/($ekspektasi_positif_cocok+$ekspektasi_negatif_tidak_cocok).') * 100%' ?>
                    </td>
                  </tr>
                  <tr>
                    <td style="vertical-align: top; text-align: left;">

                    </td>
                    <td style="vertical-align: top; text-align: left;">
                      :
                    </td>
                    <td style="vertical-align: top; text-align: left;">
                      <?php echo ($ekspektasi_positif_cocok)/($ekspektasi_positif_cocok+$ekspektasi_negatif_tidak_cocok)* 100 .'%' ?>
                    </td>
                  </tr>
                </table>
            </div>
        </div>
    </div>
</div>


<!-- End PAge Content -->
</div>


<div class="row">
    <div class="col-lg-6">
        <div class="card">
            <p>Perhitungan Recall Bukan Opini <span class="tooltips" tooltip="
              <table>
                <tr>
                  <td style='color:white; vertical-align: top; text-align: left;'>
                    recall bukan opini menjawab pertanyaan :
                  </td>
                </tr>
                <tr>
                  <td style='color:white; vertical-align: top; text-align: left;'>
                    Berapa persen tweet yang diprediksi bukan opini dibandingkan keseluruhan tweet yang sebenarnya bukan opini? (120)
                  </td>
                </tr>
              </table>" tooltip-position="right" tooltip-type="success"><button id="button" class="btn btn-success btn-xs "><i class="fa fa-info" aria-hidden="true"></i></button></span></p>
            <div class="card-content">
              <table>
                <tr>
                  <td style="vertical-align: top; text-align: left;">
                    Rumus
                  </td>
                  <td style="vertical-align: top; text-align: left;">
                    :
                  </td>
                  <td style="vertical-align: top; text-align: left;">
                    (BOC)/(BOC + OTC) * 100%
                  </td>
                </tr>
                <tr>
                  <td style="vertical-align: top; text-align: left;">

                  </td>
                  <td style="vertical-align: top; text-align: left;">
                    :
                  </td>
                  <td style="vertical-align: top; text-align: left;">
                    <?php echo '('.$ekspektasi_bukan_opini_cocok.')/('.$ekspektasi_bukan_opini_cocok.' + '.$ekspektasi_opini_tidak_cocok.') * 100%' ?>
                  </td>
                </tr>
                <tr>
                  <td style="vertical-align: top; text-align: left;">

                  </td>
                  <td style="vertical-align: top; text-align: left;">
                    :
                  </td>
                  <td style="vertical-align: top; text-align: left;">
                    <?php echo '('.($ekspektasi_bukan_opini_cocok).')/('.($ekspektasi_bukan_opini_cocok+$ekspektasi_opini_tidak_cocok).') * 100%' ?>
                  </td>
                </tr>
                <tr>
                  <td style="vertical-align: top; text-align: left;">

                  </td>
                  <td style="vertical-align: top; text-align: left;">
                    :
                  </td>
                  <td style="vertical-align: top; text-align: left;">
                    <?php echo '('.($ekspektasi_bukan_opini_cocok)/($ekspektasi_bukan_opini_cocok+$ekspektasi_opini_tidak_cocok).') * 100%' ?>
                  </td>
                </tr>
                <tr>
                  <td style="vertical-align: top; text-align: left;">

                  </td>
                  <td style="vertical-align: top; text-align: left;">
                    :
                  </td>
                  <td style="vertical-align: top; text-align: left;">
                    <?php echo ($ekspektasi_bukan_opini_cocok)/($ekspektasi_bukan_opini_cocok+$ekspektasi_opini_tidak_cocok)* 100 .'%' ?>
                  </td>
                </tr>
              </table>

            </div>
        </div>
    </div>
    <div class="col-lg-6">
        <div class="card">
            <div class="card-content">
              <p>Perhitungan Recall sentimen negatif <span class="tooltips" tooltip="
                <table>
                  <tr>
                    <td style='color:white; vertical-align: top; text-align: left;'>
                      recall naive bayes sentimen negatif menjawab pertanyaan :
                    </td>
                  </tr>
                  <tr>
                    <td style='color:white; vertical-align: top; text-align: left;'>
                      Berapa persen tweet yang diprediksi sentimen negatif dibandingkan keseluruhan tweet yang sebenarnya sentimen negatif? (90)
                    </td>
                  </tr>
                </table>" tooltip-position="right" tooltip-type="success"><button id="button" class="btn btn-success btn-xs "><i class="fa fa-info" aria-hidden="true"></i></button></span></p>
              <div class="card-content">
                <table>
                  <tr>
                    <td style="vertical-align: top; text-align: left;">
                      Rumus
                    </td>
                    <td style="vertical-align: top; text-align: left;">
                      :
                    </td>
                    <td style="vertical-align: top; text-align: left;">
                      (NC)/(NC + PTC) * 100%
                    </td>
                  </tr>
                  <tr>
                    <td style="vertical-align: top; text-align: left;">

                    </td>
                    <td style="vertical-align: top; text-align: left;">
                      :
                    </td>
                    <td style="vertical-align: top; text-align: left;">
                      <?php echo '('.$ekspektasi_negatif_cocok.')/('.$ekspektasi_negatif_cocok.' + '.$ekspektasi_positif_tidak_cocok.') * 100%' ?>
                    </td>
                  </tr>
                  <tr>
                    <td style="vertical-align: top; text-align: left;">

                    </td>
                    <td style="vertical-align: top; text-align: left;">
                      :
                    </td>
                    <td style="vertical-align: top; text-align: left;">
                      <?php echo '('.($ekspektasi_negatif_cocok).')/('.($ekspektasi_negatif_cocok+$ekspektasi_positif_tidak_cocok).') * 100%' ?>
                    </td>
                  </tr>
                  <tr>
                    <td style="vertical-align: top; text-align: left;">

                    </td>
                    <td style="vertical-align: top; text-align: left;">
                      :
                    </td>
                    <td style="vertical-align: top; text-align: left;">
                      <?php echo '('.($ekspektasi_negatif_cocok)/($ekspektasi_negatif_cocok+$ekspektasi_positif_tidak_cocok).') * 100%' ?>
                    </td>
                  </tr>
                  <tr>
                    <td style="vertical-align: top; text-align: left;">

                    </td>
                    <td style="vertical-align: top; text-align: left;">
                      :
                    </td>
                    <td style="vertical-align: top; text-align: left;">
                      <?php echo ($ekspektasi_negatif_cocok)/($ekspektasi_negatif_cocok+$ekspektasi_positif_tidak_cocok)* 100 .'%' ?>
                    </td>
                  </tr>
                </table>
            </div>
        </div>
    </div>
</div>


<!-- End PAge Content -->
</div>

    <!-- End Container fluid  -->
    <!-- footer -->
    <footer class="footer"> © 2018 All rights reserved. Template designed by <a href="https://colorlib.com">Colorlib</a></footer>
    <!-- End footer -->
</div>

<?php } ?>

@endsection

@section('script')
<script>

$('.tooltips').append("<span></span>");
$('.tooltips:not([tooltip-position])').attr('tooltip-position','bottom');


$(".tooltips").mouseenter(function(){
 $(this).find('span').empty().append($(this).attr('tooltip'));
});

</script>

@endsection
