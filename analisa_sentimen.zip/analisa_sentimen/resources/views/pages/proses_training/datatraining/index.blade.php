@extends('layouts.master')
@section('content')
<div class="page-wrapper">
    <!-- Bread crumb -->
    <div class="row page-titles">
        <div class="col-md-5 align-self-center">
            <h3 class="text-primary">Dashboard</h3> </div>
        <div class="col-md-7 align-self-center">
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="javascript:void(0)">Home</a></li>
                <li class="breadcrumb-item active">Dashboard</li>
            </ol>
        </div>
    </div>
    <!-- End Bread crumb -->
    <!-- Container fluid  -->
    <div class="container-fluid">
        <!-- Start Page Content -->
        <div class="row">
            <div class="col-12">

                <div class="card">
                    <div class="card-body">
                        <h4 class="card-title">Tabel Data Training</h4>
                        <h6 class="card-subtitle">Tabel Data Training</h6>
                        <!-- <form action="{{url('scraping_start')}}" method = "post" enctype="multipart/form-data">
                          {{ csrf_field() }}
                          <label for="inputEmail3" class="col-sm-3 col-form-label"> <input type="text" name="search" id="search" class="form-control input-rounded " placeholder="search"> </label>
                          <label for="inputEmail3" class="col-sm-2 col-form-label"> <input type="date" name="date1" id="date1" class="form-control input-rounded"> </label>
                          <label for="inputEmail3" class="col-form-label"> sampai </label>
                          <label for="inputEmail3" class="col-sm-2 col-form-label"> <input type="date" name="date2" id="date2" class="form-control input-rounded"> </label>
                          <button type="submit" class="btn btn-success hitung_scraping">Scraping start</button>
                          <a href="{{url('scraping_stop')}}" class="btn btn-success">Scraping Stop</a>
                          <a href="{{url('scraping_delete_semua')}}" class="btn btn-danger">Delete semua scrape</a>
                          </form> -->

                          <div class="card bg-light mt-3">
                            <div class="card-header">
                                Eksport Import Data Training
                            </div>
                            <div class="card-body">
                                <form action="{{ route('data_training_import') }}" method="POST" enctype="multipart/form-data">
                                    @csrf
                                    <input type="file" name="file" class="form-control">
                                    <br>
                                    <button class="btn btn-success">Import Data Training</button>
                                    <a class="btn btn-warning" href="{{ route('data_training_export') }}">Export Data Training</a>
                                    <a class="btn btn-primary" href="{{ url('data_training_download_template_excel') }}">template Data Training</a>
                                </form>
                            </div>
                          </div>

                        <div id="show" align="left"></div>

                        <div class="table-responsive m-t-20">
                            <table id="myTable" class="table table-bordered table-striped">
                                <thead>
                                    <tr>
                                        <th style="text-align:center">no</th>
                                        <th style="text-align:center">id tweet</th>
                                        <th style="text-align:center">text</th>
                                        <th style="text-align:center">usernameTweet</th>
                                        <th style="text-align:center">sentimen</th>
                                    </tr>
                                </thead>
                                <tbody>
                                  <?php
                                    $no = 1;
                                    foreach ($tb_datatraining as $data) {
                                      // code...

                                  ?>
                                    <tr>
                                        <td style="text-align:center"><?php echo $no++ ?></td>
                                        <td style="text-align:center"><?php echo $data->ID ?></td>
                                        <td style="text-align:center"><?php echo $data->text ?></td>
                                        <td style="text-align:center"><?php echo $data->usernameTweet ?></td>
                                        <td style="text-align:center"><?php echo $data->sentimen ?></td>
                                    </tr>
                                  <?php
                                  }
                                  ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>

            </div>
        </div>
        <!-- End PAge Content -->
    </div>
    <!-- End Container fluid  -->
    <!-- footer -->
    <footer class="footer"> © 2018 All rights reserved. Template designed by <a href="https://colorlib.com">Colorlib</a></footer>
    <!-- End footer -->
</div>

@endsection

@section('script')

@endsection
