@extends('layouts.master')
@section('content')
<div class="page-wrapper">
    <!-- Bread crumb -->
    <div class="row page-titles">
        <div class="col-md-5 align-self-center">
            <h3 class="text-primary">Dashboard</h3> </div>
        <div class="col-md-7 align-self-center">
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="javascript:void(0)">Home</a></li>
                <li class="breadcrumb-item active">Dashboard</li>
            </ol>
        </div>
    </div>
    <!-- End Bread crumb -->
    <!-- Container fluid  -->
    <div class="container-fluid">
        <!-- Start Page Content -->
        <div class="row">
            <div class="col-12">

                <div class="card">
                    <div class="card-body">
                        <h4 class="card-title">Tabel Postagging</h4>
                        <h6 class="card-subtitle">tabel Postagging</h6>

                        <div id="show" align="left"></div>

                        <div class="table-responsive m-t-20">
                            <table id="myTable" class="table table-bordered table-striped">
                                <thead>
                                    <tr>
                                        <th style="text-align:center">no</th>
                                        <th style="text-align:center">id tweet</th>
                                        <th style="text-align:center">usernameTweet</th>
                                        <th style="text-align:center">tweet</th>
                                        <th style="text-align:center">hasil stemming</th>
                                        <th style="text-align:center"><a href="{{url('opinion_detection_postagging')}}" class="btn btn-success">tag</a></th>
                                        <th style="text-align:center"><a href="{{url('opinion_detection_rule_proses')}}" class="btn btn-success">ekspektasi sentimen</a></th>
                                        <th style="text-align:center">detail</th>
                                        <!-- <th style="text-align:center"><a href="{{url('opinion_detection_postagging')}}" class="btn btn-success">ekspektasi sentimen</a></th> -->
                                    </tr>
                                </thead>
                                <tbody>
                                  <?php
                                    $no = 1;
                                    foreach ($postagging as $data) {
                                      // code...

                                  ?>
                                    <tr>
                                        <td style="text-align:center"><?php echo $no++ ?></td>
                                        <td style="text-align:center"><?php echo $data->id_tweet ?></td>
                                        <td style="text-align:center"><?php echo $data->usernameTweet ?></td>
                                        <td style="text-align:center"><?php echo $data->text ?></td>
                                        <td style="text-align:center"><?php echo $data->stemming_postagging ?></td>
                                        <td style="text-align:center"><?php echo $data->tag ?></td>
                                        <td style="text-align:center"><?php echo $data->label_postagging_ekspektasi ?></td>
                                        <td style="text-align:center"><a href="{{url('opinion_detection_detail/'.$data->id_tweet)}}" class="btn btn-info"><i class="fa fa-info" aria-hidden="true"></i>
                                    </tr>
                                  <?php
                                  }
                                  ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>

            </div>
        </div>
        <!-- End PAge Content -->
    </div>
    <!-- End Container fluid  -->
    <!-- footer -->
    <footer class="footer"> © 2018 All rights reserved. Template designed by <a href="https://colorlib.com">Colorlib</a></footer>
    <!-- End footer -->
    <div id="myModal" class="modal " role="dialog">
    <div class="modal-dialog modal-lg">

      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header">
          <!-- <button type="button" class="close" data-dismiss="modal">&times;</button> -->
          <h4 class="modal-title">Detail bobot per kata</h4>
        </div>
        <div class="modal-body">
          <table>
            <tr>
              <td>
                <h5 id="coba">coba1 :</h5>
              </td>
              <td>
                <h5> coba2</h5>
              </td>
            </tr>
            <tr>
              <td>
                <h5>coba3 :</h5>
              </td>
              <td>
                <h5> coba4</h5>
              </td>
            </tr>
          </table>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        </div>
      </div>

    </div>
    </div>
</div>

@endsection

@section('script')

<!-- referensi div loading every time -->
<!-- https://crunchify.com/how-to-refresh-div-content-without-reloading-page-using-jquery-and-ajax/ -->


<script>

$(document).on('click','.hitung_scraping',function(){

  var myVar = setInterval(myTimer, 100);

  function myTimer() {
    var url = "scraping_jumlah_scrape";
    $.get(url, function (data) {

      var data = JSON.parse(data);
      console.log(data[0].jumlah);

      if(data[0].jumlah == 100){
        clearInterval(myVar);
        window.location.assign("{{url('scraping_stop')}}");
        // window.location.reload(false);
        // window.location.assign("{{url('scraping_stop')}}");
        // location.reload();
        // return false;
      }else{
        $('#show').text(
          'jumlah scrape = '
        + data[0].jumlah);
      }

    })
  };
});

</script>

@endsection
