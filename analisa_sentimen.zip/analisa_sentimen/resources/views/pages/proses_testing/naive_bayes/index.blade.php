@extends('layouts.master')
@section('content')
<div class="page-wrapper">
    <!-- Bread crumb -->
    <div class="row page-titles">
        <div class="col-md-5 align-self-center">
            <h3 class="text-primary">Dashboard</h3> </div>
        <div class="col-md-7 align-self-center">
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="javascript:void(0)">Home</a></li>
                <li class="breadcrumb-item active">Dashboard</li>
            </ol>
        </div>
    </div>
    <!-- End Bread crumb -->
    <!-- Container fluid  -->
    <div class="container-fluid">
        <!-- Start Page Content -->
        <div class="row">
            <div class="col-12">

                <div class="card">
                    <div class="card-body">
                        <h4 class="card-title">Tabel Naive Bayes</h4>
                        <h6 class="card-subtitle">tabel naive bayes</h6>
                        <!-- <a href="{{url('naive_bayes_proses')}}" class="btn btn-success">naive bayes start</a> -->

                        <div id="show" align="left"></div>

                        <div class="table-responsive m-t-20">
                            <table id="myTable" class="table table-bordered table-striped">
                                <thead>
                                    <tr>
                                        <th style="text-align:center">no</th>
                                        <th style="text-align:center">kata</th>
                                        <th style="text-align:center">tweet</th>
                                        <th style="text-align:center">hasil preprocessing</th>
                                        <th style="text-align:center"><a href="{{url('naive_bayes_proses')}}" class="btn btn-success">naive bayes</a></th>
                                        <th style="text-align:center">detail</th>
                                    </tr>
                                </thead>
                                <tbody>
                                  <?php
                                  $no = 1;
                                  foreach ($tb_naivebayes as $data) {
                                  ?>
                                    <tr>
                                        <td style="text-align:center"><?php echo $no++; ?></td>
                                        <td style="text-align:center"><?php echo $data->id_tweet; ?></td>
                                        <td style="text-align:center"><?php echo $data->text ?></td>
                                        <td style="text-align:center"><?php echo $data->stemming ?></td>
                                        <td style="text-align:center"><?php echo $data->label_naive_bayes_ekspektasi; ?></td>
                                        <td style="text-align:center"><a href="{{url('naive_bayes_detail/'.$data->id_tweet)}}" class="btn btn-info"><i class="fa fa-info" aria-hidden="true"></i>
</a><td>
                                    </tr>
                                  <?php
                                  }
                                  ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>

            </div>
        </div>
        <!-- End PAge Content -->
    </div>
    <!-- End Container fluid  -->
    <!-- footer -->
    <footer class="footer"> © 2018 All rights reserved. Template designed by <a href="https://colorlib.com">Colorlib</a></footer>
    <!-- End footer -->
</div>

@endsection

@section('script')

<!-- referensi div loading every time -->
<!-- https://crunchify.com/how-to-refresh-div-content-without-reloading-page-using-jquery-and-ajax/ -->



@endsection
