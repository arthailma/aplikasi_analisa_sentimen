@extends('layouts.master')
@section('content')
<div class="page-wrapper">
    <!-- Bread crumb -->
    <div class="row page-titles">
        <div class="col-md-5 align-self-center">
            <h3 class="text-primary">Dashboard</h3> </div>
        <div class="col-md-7 align-self-center">
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="javascript:void(0)">Home</a></li>
                <li class="breadcrumb-item active">Dashboard</li>
            </ol>
        </div>
    </div>
    <!-- End Bread crumb -->
    <!-- Container fluid  -->
    <div class="container-fluid">
        <!-- Start Page Content -->
        <div class="row">
            <div class="col-4">

                <div class="card">
                    <div class="card-body">
                        <h4 class="card-title">Tabel Rule</h4>
                        <h6 class="card-subtitle">tabel rule</h6>

                        <div class="card">
                            <h4><b>Note : Default digunakan ketika kata pada data testing tidak ada di data training atau jumlah kata = 0</b></h4>
                            <p>Default bobot kata sentimen positif : <?php echo $default_bobot_sentimen_positif ?></p>
                            <p>Default bobot kata sentimen negatif : <?php echo $default_bobot_sentimen_negatif ?></p>
                        </div>


                        <div class="table-responsive m-t-20">
                            <table id="myTable" class="table table-bordered table-striped">
                                <thead>
                                    <tr>
                                        <th style="text-align:center">no</th>
                                        <th style="text-align:center">kata</th>
                                        <th style="text-align:center">jumlah kata</th>
                                        <th style="text-align:center">bobot</th>
                                        <th style="text-align:center">sentimen</th>
                                        <!-- <th style="text-align:center"><a href="{{url('opinion_detection_postagging')}}" class="btn btn-success">ekspektasi sentimen</a></th> -->
                                    </tr>
                                </thead>
                                <tbody>
                                  <?php
                                    $no = 1;
                                    foreach ($tb_laplacecorrection as $data) {
                                      // code...
                                  ?>
                                    <tr>
                                        <td style="text-align:center"><?php echo $no++ ?></td>
                                        <td style="text-align:center"><?php echo $data->kata ?></td>
                                        <td style="text-align:center"><?php echo $data->jumlah_kata ?></td>
                                        <td style="text-align:center"><?php echo $data->bobot ?> <button class="btn btn-success btn-xs sweet-alert_detail_bobot" value="<?php echo $data->id_laplacecorrection ?>"><i class="fa fa-info" aria-hidden="true"></i></button></td>
                                        <td style="text-align:center"><?php echo $data->sentimen ?>  </td>
                                    </tr>
                                  <?php
                                  }
                                  ?>
                                </tbody>
                            </table>
                        </div>
                    </div>

                </div>

            </div>

            <div class="col-8">

              <div class="row-8">

                  <div class="card">
                      <div class="card-body">
                          <h4 class="card-title">Detail Opinion Detection</h4>
                          <h6 class="card-subtitle">detail opinion detection</h6>
                          <!-- <button class="btn btn-primary btn sweet-html">Sweet HTML</button> -->
                          <!-- <div class="sweetalert m-t-15">
                              <button class="btn btn-primary btn sweet-html">Sweet HTML</button>
                          </div> -->
                          <div id="show" align="left"></div>


                      </div>
                  </div>

                </div>

              <div class="row-8">

                <div class="card">
                    <div class="card-body">
                        <table>
                          <?php foreach ($tb_naivebayes_detail as $data){ ?>

                          <tr>
                            <th width="100px" style="vertical-align: top; text-align: left;">
                              <h3>Id Tweet</h3>
                            </th>
                            <th width="20px" style="vertical-align: top; text-align: left;">
                              <h3>&nbsp; :</h3>
                            </th>
                            <th style="vertical-align: top; text-align: left;">
                              <h3>&nbsp; <?php echo $data->id_tweet ?></h3>
                            </th>
                          </tr>

                          <tr>
                            <th width="100px" style="vertical-align: top; text-align: left;">
                              <h3>Text</h3>
                            </th>
                            <th width="20px" style="vertical-align: top; text-align: left;">
                              <h3>&nbsp; :</h3>
                            </th>
                            <th style="vertical-align: top; text-align: left;">
                              <h3>&nbsp; <?php echo $data->text ?></h3>
                            </th>
                          </tr>

                          <tr>
                            <th width="100px" style="vertical-align: top; text-align: left;">
                              <h3>Hasil Preprocessing</h3>
                            </th>
                            <th width="20px" style="vertical-align: top; text-align: left;">
                              <h3>&nbsp; :</h3>
                            </th>
                            <th style="vertical-align: top; text-align: left;">
                              <h3>&nbsp; <?php echo $data->stemming ?></h3>
                            </th>
                          </tr>

                          <?php } ?>

                        </table>


                    </div>
                </div>

              </div>

              <div class="row-8">

                  <div class="card">
                      <div class="card-body">
                        <h4 class="card-title">naive bayes positif = <?php echo array_product($detail_bobot_naive_bayes_positif_explode) ?></h4>
                        <div class="table-responsive m-t-20">
                            <table id="myTable" class="table table-bordered table-striped">
                                <thead>
                                    <tr>
                                      <?php
                                        for($i=0; $i<count($data_stemming_explode); $i++){
                                      ?>
                                          <th style="text-align:center">
                                            <?php echo $data_stemming_explode[$i];?>
                                          </th>
                                      <?php
                                        }
                                      ?>

                                        <!-- <th style="text-align:center"><a href="{{url('opinion_detection_postagging')}}" class="btn btn-success">ekspektasi sentimen</a></th> -->
                                    </tr>
                                </thead>
                                <tbody>
                                  <tr>
                                    <?php
                                      for($i=0; $i<count($detail_bobot_naive_bayes_positif_explode); $i++){
                                    ?>
                                        <th style="text-align:center">
                                          <?php echo $detail_bobot_naive_bayes_positif_explode[$i];?>
                                        </th>
                                    <?php
                                      }
                                    ?>

                                      <!-- <th style="text-align:center"><a href="{{url('opinion_detection_postagging')}}" class="btn btn-success">ekspektasi sentimen</a></th> -->
                                  </tr>
                                </tbody>
                            </table>
                        </div>




                        <h4 class="card-title">naive bayes negatif = <?php echo array_product($detail_bobot_naive_bayes_negatif_explode) ?></h4>
                        <div class="table-responsive m-t-20">
                            <table id="myTable" class="table table-bordered table-striped">
                                <thead>
                                    <tr>
                                      <?php
                                        for($i=0; $i<count($data_stemming_explode); $i++){
                                      ?>
                                          <th style="text-align:center">
                                            <?php echo $data_stemming_explode[$i].'  ';?>
                                          </th>
                                      <?php
                                        }
                                      ?>

                                        <!-- <th style="text-align:center"><a href="{{url('opinion_detection_postagging')}}" class="btn btn-success">ekspektasi sentimen</a></th> -->
                                    </tr>
                                </thead>
                                <tbody>
                                  <tr>
                                    <?php
                                      for($i=0; $i<count($detail_bobot_naive_bayes_negatif_explode); $i++){
                                    ?>
                                        <th style="text-align:center">
                                          <?php echo $detail_bobot_naive_bayes_negatif_explode[$i];?>

                                        </th>
                                    <?php
                                      }
                                    ?>

                                      <!-- <th style="text-align:center"><a href="{{url('opinion_detection_postagging')}}" class="btn btn-success">ekspektasi sentimen</a></th> -->
                                  </tr>
                                </tbody>
                            </table>
                        </div>


                      </div>
                  </div>

                </div>

                <div class="row-8">

                    <div class="card">
                        <div class="card-body">
                          <table>
                            <?php foreach ($tb_naivebayes_detail as $data){ ?>

                            <tr>
                              <th width="300px" style="vertical-align: top; text-align: left;">
                                <h3>label naive bayes ekspektasi</h3>
                              </th>
                              <th width="20px" style="vertical-align: top; text-align: left;">
                                <h3>&nbsp; :</h3>
                              </th>
                              <th style="vertical-align: top; text-align: left;">
                                <h3>&nbsp; <?php echo $data->label_naive_bayes_ekspektasi ?></h3>
                              </th>
                            </tr>

                            <tr>
                              <th width="300px" style="vertical-align: top; text-align: left;">
                                <h3>label naive bayes realita</h3>
                              </th>
                              <th width="20px" style="vertical-align: top; text-align: left;">
                                <h3>&nbsp; :</h3>
                              </th>
                              <th style="vertical-align: top; text-align: left;">
                                <h3>&nbsp; <?php echo $data->label_naive_bayes_realita ?></h3>
                              </th>
                            </tr>

                            <tr>
                              <th width="300px" style="vertical-align: top; text-align: left;">
                                <h3>status naive bayes</h3>
                              </th>
                              <th width="20px" style="vertical-align: top; text-align: left;">
                                <h3>&nbsp; :</h3>
                              </th>
                              <th style="vertical-align: top; text-align: left;">
                                <h3>&nbsp; <?php echo $data->status_naive_bayes ?></h3>
                              </th>
                            </tr>

                            <?php } ?>

                          </table>


                        </div>
                    </div>

                  </div>

            </div>

        </div>
        <!-- End PAge Content -->
    </div>
    <!-- End Container fluid  -->
    <!-- footer -->
    <footer class="footer"> © 2018 All rights reserved. Template designed by <a href="https://colorlib.com">Colorlib</a></footer>
    <!-- End footer -->



</div>

@endsection

@section('script')


  <script>

  $(document).on('click','.sweet-alert_detail_bobot',function(){


      var id_laplacecorrection= $(this).val();
      var kata = '';

      $.get('<?php echo url('/laplace_corection_detail'); ?>' + '/' + id_laplacecorrection, function (data) {
  	    //success data
  	    // var obj = JSON.parse(json);
  	    // console.log(obj[0]["data.name"]);

        //array[0] = kata
        //array[1] = jumlah kata
        //array[2] = jumlah kata per kata
        //array[3] = jumlah semua kata
  	    var data = JSON.parse(data);
  	    console.log(data[0]);
        kata = data[0];
        // jumlah_kata data[1];
        // jumlah_kata_per_kata = data[2];
        // jumlah_kata_semua_kata = data[3];
        // document.getElementById("modal_tite").innerHTML= 'detail bobot per kata ('+data[0]+')';
        // document.getElementById("rumus").innerHTML= '('+data[1]+'+1)/('+data[2]+'+'+data[3]+')';
        // document.getElementById("hasil_rumus").innerHTML= (data[1]+1)/(data[2]+data[3]);

        var swal_html = '<div class="row">'+
                          '<div class="col-6">'+
                            '<div class="card">'+
                              '<div class="card-body">'+
                                '<table>'+
                                  '<tr>'+
                                    '<td style="vertical-align: top; text-align: left;">'+
                                      'kata'+
                                    '</td>'+
                                    '<td>'+
                                      ':'+
                                    '</td>'+
                                    '<td>'+
                                      data[0]+
                                    '</td>'+
                                  '</tr>'+
                                  '<tr>'+
                                    '<td style="vertical-align: top; text-align: left;">'+
                                      'jumlah kata'+
                                    '</td>'+
                                    '<td>'+
                                      ':'+
                                    '</td>'+
                                    '<td>'+
                                      data[1]+
                                    '</td>'+
                                  '</tr>'+
                                  '<tr>'+
                                    '<td style="vertical-align: top; text-align: left;">'+
                                      'jumlah kata per kata '+'('+data[4]+')'+
                                    '</td>'+
                                    '<td>'+
                                      ':'+
                                    '</td>'+
                                    '<td>'+
                                      data[2]+
                                    '</td>'+
                                  '</tr>'+
                                  '<tr>'+
                                    '<td style="vertical-align: top; text-align: left;">'+
                                      'jumlah semua kata sentimen '+'('+data[4]+')'+
                                    '</td>'+
                                    '<td>'+
                                      ':'+
                                    '</td>'+
                                    '<td>'+
                                      data[3]+
                                    '</td>'+
                                  '</tr>'+
                                '</table>'+
                              '</div>'+
                            '</div>'+
                          '</div>'+
                          '<div class="col-6">'+
                            '<div class="card">'+
                              '<div class="card-body">'+
                                '<table>'+
                                  '<tr>'+
                                    '<td style="vertical-align: top; text-align: left;">'+
                                      'rumus'+
                                    '</td>'+
                                    '<td style="vertical-align: top; text-align: left;">'+
                                      ':'+
                                    '</td>'+
                                    '<td style="vertical-align: top; text-align: left;">'+
                                      '(jumlah kata + 1)/(jumlah kata per kata + jumlah semua kata)'+
                                    '</td>'+
                                  '</tr>'+
                                  '<tr>'+
                                    '<td style="vertical-align: top; text-align: left;">'+
                                      ''+
                                    '</td>'+
                                    '<td>'+
                                      ':'+
                                    '</td>'+
                                    '<td style="vertical-align: top; text-align: left;">'+
                                      '('+data[1]+'+1)/('+data[2]+'+'+data[3]+')'+
                                    '</td>'+
                                  '</tr>'+
                                  '<tr>'+
                                    '<td style="vertical-align: top; text-align: left;">'+
                                      ''+
                                    '</td>'+
                                    '<td>'+
                                      ':'+
                                    '</td>'+
                                    '<td style="vertical-align: top; text-align: left;">'+
                                      (data[1]+1)/(data[2]+data[3])+
                                    '</td>'+
                                  '</tr>'+
                                '</table>'+
                              '</div>'+
                            '</div>'+
                          '</div>'+
                        '</div>';
          swal({
            title: kata+' ('+data[4]+')',
            html: swal_html,
            customClass: 'swal-wide'});
        });

  	  })



  </script>

@endsection
