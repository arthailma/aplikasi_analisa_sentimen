<?php

namespace App\Exports;

use App\tb_normalisasi;
use Maatwebsite\Excel\Concerns\FromCollection;

class normalisasiExport implements FromCollection
{
    /**
    * @return \Illuminate\Support\Collection
    */
    public function collection()
    {
        return tb_normalisasi::all();
    }
}
