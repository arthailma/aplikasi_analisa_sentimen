<?php

namespace App\Exports;

use App\tb_scraper;
use Maatwebsite\Excel\Concerns\FromCollection;
use DB;

class datatestingExport implements FromCollection
{
    /**
    * @return \Illuminate\Support\Collection
    */
    public function collection()
    {
        // return tb_scraper::all();
        //https://www.itsolutionstuff.com/post/import-and-export-csv-file-in-laravel-58example.html
        $tb_scraper = DB::table('tb_scraper')
        ->select(DB::raw("CONCAT('''',tb_scraper.ID), tb_scraper.url, CONCAT('''',tb_scraper.datetime), tb_scraper.text, CONCAT('''',tb_scraper.user_id), tb_scraper.usernameTweet, tb_scraper.label_postagging_realita, tb_scraper.label_naive_bayes_realita"))
        ->get();

        return $tb_scraper;
    }
}
