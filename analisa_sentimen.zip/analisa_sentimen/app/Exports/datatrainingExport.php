<?php

namespace App\Exports;

use App\tb_datatraining;
use Maatwebsite\Excel\Concerns\FromCollection;
use DB;

class datatrainingExport implements FromCollection
{
    /**
    * @return \Illuminate\Support\Collection
    */
    public function collection()
    {
        // return tb_datatraining::all();
        // https://www.itsolutionstuff.com/post/import-and-export-csv-file-in-laravel-58example.html
        $tb_datatraining = DB::table('tb_datatraining')
        ->select(DB::raw("CONCAT('''',tb_datatraining.ID), tb_datatraining.url, CONCAT('''',tb_datatraining.datetime), tb_datatraining.text, CONCAT('''',tb_datatraining.user_id), tb_datatraining.usernameTweet, tb_datatraining.sentimen"))
        ->get();

        return $tb_datatraining;
    }
}
