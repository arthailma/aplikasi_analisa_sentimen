<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class tb_preprocessingtraining extends Model
{
  protected $table = 'tb_preprocessingtraining';
  protected $primaryKey = 'id_preprocessing';
}
