<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class tb_naivebayes extends Model
{
  protected $table = 'tb_naivebayes';
  protected $primaryKey = 'id_naivebayes';
}
