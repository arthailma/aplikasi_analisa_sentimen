<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class tb_preprocessing extends Model
{
  protected $table = 'tb_preprocessing';
  protected $primaryKey = 'id_preprocessing';
}
