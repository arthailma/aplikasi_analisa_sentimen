<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\tb_scraper;
use App\tb_postagging;
use App\tb_naivebayes;
use DB;

class opiniondetectionController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
      $tb_postagging = DB::table('tb_postagging')
      ->select(DB::raw('tb_postagging.*, tb_preprocessing.*, tb_scraper.*'))
      ->join('tb_preprocessing', 'tb_preprocessing.id_tweet', '=', 'tb_postagging.id_tweet')
      ->join('tb_scraper', 'tb_scraper.ID', '=', 'tb_postagging.id_tweet')
      ->get();

      return view('pages/proses_testing/opiniondetection/index',['postagging'=>$tb_postagging]);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }

    public function opinion_postagging_viterbi(){

      set_time_limit(1800);

      DB::table('tb_postagging')
            ->update(['tag' => ""]);

      $tb_postagging = DB::table('tb_postagging')
      ->select(DB::raw('tb_postagging.*, tb_preprocessing.stemming'))
      ->join('tb_preprocessing', 'tb_preprocessing.id_tweet', '=', 'tb_postagging.id_tweet')
      ->get();

      // dd($tb_postagging);
      // $coba = [];
      foreach ($tb_postagging as $data) {

        $tweet_ganti_spasi_4 = str_replace('    ','%20',$data->stemming_postagging);
        $tweet_ganti_spasi_3 = str_replace('   ','%20',$tweet_ganti_spasi_4);
        $tweet_ganti_spasi_2 = str_replace('  ','%20',$tweet_ganti_spasi_3);
        $tweet_ganti_spasi_1 = str_replace(' ','%20',$tweet_ganti_spasi_2);


        // dd($tweet_ganti_spasi_1);

        // // dd('coba');
        // $getdataurl = file_get_contents('http://localhost/IndoPOSTag/Home/postager?tweet=hasil%20bagus');
        // // dd($getdataurl);
        // $pembersihanjson = str_replace(['[',']',',','"'],' ',$getdataurl);

        $getdataurl = file_get_contents("http://localhost/IndoPOSTag/Home/postager?tweet=$tweet_ganti_spasi_1");
        // $getdataurl = file_get_contents("https://indopostag.000webhostapp.com/Home/postager?tweet=$tweet_ganti_spasi");

      // untuk online
      //   $ch = curl_init();
      //
      // // set url
      // curl_setopt($ch, CURLOPT_URL, "http://logikadev.com/IndoPOSTag/home/postager?tweet=$tweet_ganti_spasi_1");
      //
      // // return the transfer as a string
      // curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
      //
      // // $output contains the output string
      // $output = curl_exec($ch);
      //
      // // tutup curl
      // curl_close($ch);

      // menampilkan hasil curl
      // echo $output;

        // dd($getdataurl);
        $viterbi_final_1 = str_replace(['[',']','"'],'',$getdataurl);
        $viterbi_final_2 = str_replace(',',' ',$viterbi_final_1);
        // // $coba[] = $viterbi_final;
        //
        // // echo $pembersihanjson;
        //
        tb_postagging::where('id_tweet', $data->id_tweet)->update(array('tag' => $viterbi_final_2));

        // echo $getdataurl;
        // $data_tweet = json_decode($getdataurl,true);
        // $Geonames = $data_tweet['texttweet'][0];

        // $json = file_get_contents('url_here');
        // $obj = json_decode($getdataurl);
        // echo $obj->texttweet;
        // print_r($obj);

      }



      // dd($coba);

      //tambah tb_naive_bayes

      return back();

    }

    public function strposa($haystack, $needles=array(), $offset=0) {
        $chr = array();
        foreach($needles as $needle) {
                $res = strpos($haystack, $needle, $offset);
                if ($res !== false) $chr[$needle] = $res;
        }
        if(empty($chr)) return false;
        return min($chr);
    }

    public function opinion_detection_rule_proses(){

      set_time_limit(1800);

      DB::table('tb_postagging')
            ->update(['label_postagging_ekspektasi' => ""]);

      $tb_rule_opini = DB::table('tb_rule_opini')
      ->select(DB::raw('tb_rule_opini.*'))
      ->get();

      $rule = [];
      $rule_preg_match_all = [];
      foreach ($tb_rule_opini as $data) {
        $rule[] = $data->rule.'';
        $rule_preg_match_all[] = '|'.$data->rule.''.'|';
      }
      // dd($rule);

      $tb_postagging = DB::table('tb_postagging')
      ->select(DB::raw('tb_postagging.*, tb_preprocessing.*'))
      ->join('tb_preprocessing','tb_preprocessing.id_tweet','=','tb_postagging.id_tweet')
      ->get();

      foreach ($tb_postagging as $data) {
        // echo nl2br($data->tag."\n");
        // $preg_replace_1 = preg_replace($rule_opini,'',$data->tag);
        // $preg_replace_1_backslah = '/\b'.$preg_replace_1.'\b/u';
        // $preg_replace_2 = preg_replace($preg_replace_1_backslah,'tidak ada',$data->tag);
        // echo $preg_replace_1_backslah;

        // $tag_str_replace_1 = preg_replace($rule_preg_replace,'',$data->tag);
        // $tag_str_replace_1_array = explode(' ',$tag_str_replace_1);
        // $tag_str_replace_3 = [];
        // for($i=0;$i<count($tag_str_replace_1_array)-1;$i++){
        //   // echo count($tag_str_replace_1_array)-1;
        //
        //     $tag_str_replace_3[] = $tag_str_replace_1_array[$i].' '.$tag_str_replace_1_array[$i+1];
        //
        // }
        // $tag_str_replace_4 = str_replace($tag_str_replace_3,'',$data->tag);

        // echo nl2br($tag_str_replace_4."\n");
        // print_r($tag_str_replace_3);
        // echo $tag_str_replace_4.'';
        // $tag_str_replace_array = explode(' ',$tag_str_replace);
        // print_r($tag_str_replace_array);

        //------------------------- memnetukan hasil tag itu dikategorikan opini atau bukan opini -------------------------//
        $string = $data->tag;
        // $array  = array('RB JJ', 'NN JJ', 'NEG JJ', 'NEG VB');

        if ($this->strposa($string, $rule, 1)) {
            // echo 'true';
            tb_postagging::where('id_tweet', $data->id_tweet)->update(array('label_postagging_ekspektasi' => 'opini'));
            // print_r($rule);
        } else {
            // echo 'false';
            tb_postagging::where('id_tweet', $data->id_tweet)->update(array('label_postagging_ekspektasi' => 'bukan opini'));
        }

        //referensi https://stackoverflow.com/questions/9689521/preg-match-for-multiple-words

        $rule_preg_match_all_string = implode(' ',$rule_preg_match_all);
        $rule_preg_match_all_string_2 = '#\b('.$rule_preg_match_all_string.')\b#';

        // //menghapus tanda | di depan
        // $ptn = "/^|/";  // Regex
        // $rpltxt = "";  // Replacement string
        // $rule_preg_match_all_string_3 = preg_replace($ptn, $rpltxt, $rule_preg_match_all_string_2);
        //
        // //menghapus spasi di belakang
        // $rule_preg_match_all_string_4 = rtrim($rule_preg_match_all_string_3, "|");

        // dd($rule_preg_match_all_string_4);

        if(preg_match_all($rule_preg_match_all_string_2, $string, $matches)){
          // tb_postagging::where('id_tweet', $data->id_tweet)->update(array('label_postagging_ekspektasi' => 'opini'));

          $matches_string = implode(' ',$matches[0]);

          //menghilangkan_spasi_berlebihan
          //https://www.techfry.com/php-tutorial/how-to-remove-whitespace-characters-in-a-string-in-php-trim-function
          $matches_string_2 = trim(preg_replace('/\s+/', ' ', $matches_string));

          // dd($matches_string_2);

          tb_postagging::where('id_tweet', $data->id_tweet)->update(array('rule_deteksi' => $matches_string_2));
        }

        //------------------------- menentukan status postagging yang statusnya yaitu cocok atau tidak cocok -------------------------//
        $tb_postagging = DB::table('tb_postagging')
        ->select(DB::raw('tb_postagging.*, tb_scraper.*'))
        ->join('tb_scraper','tb_scraper.ID','=','tb_postagging.id_tweet')
        ->get();

        foreach ($tb_postagging as $data) {
          if($data->label_postagging_ekspektasi == $data->label_postagging_realita){
            tb_postagging::where('id_tweet', $data->id_tweet)->update(array('status_postagging' => 'cocok'));
          }else{
            tb_postagging::where('id_tweet', $data->id_tweet)->update(array('status_postagging' => 'tidak cocok'));
          }
        }



      }

      // dd($tb_postagging);
      return back();
    }

    public function opinion_detection_detail($id){
      $id_tweet = $id;
      $tb_rule_opini = DB::table('tb_rule_opini')
      ->select(DB::raw('tb_rule_opini.*'))
      ->get();

      $tb_opinion_detection_detail = DB::table('tb_postagging')
      ->select(DB::raw('tb_postagging.*, tb_preprocessing.*, tb_scraper.*'))
      ->join('tb_preprocessing', 'tb_preprocessing.id_tweet', '=', 'tb_postagging.id_tweet')
      ->join('tb_scraper', 'tb_scraper.ID', '=', 'tb_postagging.id_tweet')
      ->where('tb_postagging.id_tweet','=',$id_tweet)
      ->get();

      $data_stemming_postagging = '';
      $data_tag = '';
      foreach ($tb_opinion_detection_detail as $data) {
        $data_stemming_postagging = $data->stemming_postagging;
        $data_tag = $data->tag;
        // echo count($data_stemming_explode);
      }

      // echo $data_stemming;
      $data_stemming_postagging_explode = explode(' ',$data_stemming_postagging);
      $data_tag_explode = explode(' ',$data_tag);
      // print_r($data_stemming_explode);




      // echo $tb_opinion_detection_detail_explode[0][0];
      // echo count($tb_opinion_detection_detail_explode);

      return view('pages/proses_testing/opiniondetection/opinion_detection_detail',['rule_opini'=>$tb_rule_opini,
      'opinion_detection_detail'=>$tb_opinion_detection_detail,
      'data_stemming_postagging_explode'=>$data_stemming_postagging_explode,
      'data_tag_explode'=>$data_tag_explode]);

      // echo $id_tweet;
    }


}
