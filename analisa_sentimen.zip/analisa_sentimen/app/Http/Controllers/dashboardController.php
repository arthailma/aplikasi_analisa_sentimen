<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Response;
use DB;

use App\Exports\normalisasiExport;
use Maatwebsite\Excel\Facades\Excel;

class dashboardController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        return view('pages/dashboard/index');
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }

    public function laporan_skripsi(){
      // PDF file is stored under project/public/download/info.pdf
      $file= public_path(). "/download_laporan_skripsi/DraftLaporanSkripsi_1941727008_Artha_Ilma_Imanidanantoyo.docx";
      // dd('coba');
      $headers = array(
              'Content-Type: application/docx',
            );

      return Response::download($file, 'Laporan Skripsi Artha.docx', $headers);

    }

    public function jurnal_skripsi(){
      // PDF file is stored under project/public/download/info.pdf
      $file= public_path(). "/download_jurnal_skripsi/DraftJurnalSkripsi_1941727008_Artha_Ilma_Imanidanantoyo.pdf";
      // dd('coba');
      $headers = array(
              'Content-Type: application/pdf',
            );

      return Response::download($file, 'Jurnal Skripsi Artha.pdf', $headers);

    }



    public function referensi_algoritma_preprocessing_1(){
      //PDF file is stored under project/public/download/info.pdf
      $file= public_path(). "/download_referensi/ANALISIS SENTIMEN TERHADAP PEMERINTAHAN JOKO WIDODO PADA MEDIA SOSIAL TWITTER MENGGUNAKAN ALGORITMA NAIVES BAYES CLASSIFIER.pdf";
      // dd($file);
      $headers = array(
              'Content-Type: application/pdf',
            );

      return Response::download($file, 'ANALISIS SENTIMEN TERHADAP PEMERINTAHAN JOKO WIDODO PADA MEDIA SOSIAL TWITTER MENGGUNAKAN ALGORITMA NAIVES BAYES CLASSIFIER.pdf', $headers);
    }

    public function referensi_algoritma_preprocessing_2(){
      //PDF file is stored under project/public/download/info.pdf
      $file= public_path(). "/download_referensi/Makalah Haris.pdf";
      // dd($file);
      $headers = array(
              'Content-Type: application/pdf',
            );

      return Response::download($file, 'Makalah Haris.pdf', $headers);
    }




    public function referensi_algoritma_laplacecorrection_1(){
      //PDF file is stored under project/public/download/info.pdf
      $file= public_path(). "/download_referensi/ANALISIS SENTIMEN TERHADAP PEMERINTAHAN JOKO WIDODO PADA MEDIA SOSIAL TWITTER MENGGUNAKAN ALGORITMA NAIVES BAYES CLASSIFIER.pdf";
      // dd($file);
      $headers = array(
              'Content-Type: application/pdf',
            );

      return Response::download($file, 'ANALISIS SENTIMEN TERHADAP PEMERINTAHAN JOKO WIDODO PADA MEDIA SOSIAL TWITTER MENGGUNAKAN ALGORITMA NAIVES BAYES CLASSIFIER.pdf', $headers);
    }

    public function referensi_algoritma_laplacecorrection_2(){
      //PDF file is stored under project/public/download/info.pdf
      $file= public_path(). "/download_referensi/ANALISIS SENTIMEN TERHADAP PEMERINTAHAN JOKO WIDODO PADA MEDIA SOSIAL TWITTER MENGGUNAKAN ALGORITMA NAIVES BAYES CLASSIFIER.pdf";
      // dd($file);
      $headers = array(
              'Content-Type: application/pdf',
            );

      return Response::download($file, 'ANALISIS SENTIMEN TERHADAP PEMERINTAHAN JOKO WIDODO PADA MEDIA SOSIAL TWITTER MENGGUNAKAN ALGORITMA NAIVES BAYES CLASSIFIER.pdf', $headers);
    }






    public function referensi_algoritma_postagging_viterbi_1(){
      //PDF file is stored under project/public/download/info.pdf
      $file= public_path(). "/download_referensi/Part-of-Speech (POS) Tagging Bahasa Indonesia Menggunakan Algoritma Viterbi.pdf";
      // dd($file);
      $headers = array(
              'Content-Type: application/pdf',
            );

      return Response::download($file, 'Part-of-Speech (POS) Tagging Bahasa Indonesia Menggunakan Algoritma Viterbi.pdf', $headers);
    }

    public function referensi_algoritma_postagging_viterbi_2(){
      //PDF file is stored under project/public/download/info.pdf
      $file= public_path(). "/download_referensi/IMPLEMENTASI RULE-BASED DOCUMENT SUBJECTIVITYPADA SISTEM OPINION MINING.pdf";
      // dd($file);
      $headers = array(
              'Content-Type: application/pdf',
            );

      return Response::download($file, 'IMPLEMENTASI RULE-BASED DOCUMENT SUBJECTIVITYPADA SISTEM OPINION MINING.pdf', $headers);
    }







    public function referensi_algoritma_naive_bayes_1(){
      //PDF file is stored under project/public/download/info.pdf
      $file= public_path(). "/download_referensi/ANALISIS SENTIMEN TERHADAP PEMERINTAHAN JOKO WIDODO PADA MEDIA SOSIAL TWITTER MENGGUNAKAN ALGORITMA NAIVES BAYES CLASSIFIER.pdf";
      // dd($file);
      $headers = array(
              'Content-Type: application/pdf',
            );

      return Response::download($file, 'ANALISIS SENTIMEN TERHADAP PEMERINTAHAN JOKO WIDODO PADA MEDIA SOSIAL TWITTER MENGGUNAKAN ALGORITMA NAIVES BAYES CLASSIFIER.pdf', $headers);
    }

    public function referensi_algoritma_naive_bayes_2(){
      //PDF file is stored under project/public/download/info.pdf
      $file= public_path(). "/download_referensi/makalah rochman.pdf";
      // dd($file);
      $headers = array(
              'Content-Type: application/pdf',
            );

      return Response::download($file, 'makalah rochman.pdf', $headers);
    }





    public function referensi_dataset_1(){
      //PDF file is stored under project/public/download/info.pdf
      return Excel::download(new normalisasiExport, 'normalisasi.xlsx');
    }
}
