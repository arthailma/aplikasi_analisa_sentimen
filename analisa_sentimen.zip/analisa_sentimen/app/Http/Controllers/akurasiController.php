<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use DB;

class akurasiController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //========================== postagging akurasi precision recall postagging viterbi=======================================
        $tb_postagging_label_postagging_ekspektasi_samadengan_opini_status_postagging_samadengan_cocok = DB::table('tb_postagging')
        ->select(DB::raw('tb_postagging.*','tb_scraper.*'))
        ->where('tb_postagging.label_postagging_ekspektasi','=','opini')
        ->where('tb_postagging.status_postagging','=','cocok')
        ->join('tb_scraper','tb_scraper.ID','=','tb_postagging.id_tweet')
        ->get();

        $ekspektasi_opini_cocok = count($tb_postagging_label_postagging_ekspektasi_samadengan_opini_status_postagging_samadengan_cocok);

        $tb_postagging_label_postagging_ekspektasi_samadengan_opini_status_postagging_samadengan_tidak_cocok = DB::table('tb_postagging')
        ->select(DB::raw('tb_postagging.*','tb_scraper.*'))
        ->where('tb_postagging.label_postagging_ekspektasi','=','opini')
        ->where('tb_postagging.status_postagging','=','tidak cocok')
        ->join('tb_scraper','tb_scraper.ID','=','tb_postagging.id_tweet')
        ->get();

        $ekspektasi_opini_tidak_cocok = count($tb_postagging_label_postagging_ekspektasi_samadengan_opini_status_postagging_samadengan_tidak_cocok);

        $tb_scraper_label_postagging_realita_samadengan_opini = DB::table('tb_scraper')
        ->select(DB::raw('tb_scraper.*'))
        ->where('tb_scraper.label_postagging_realita','=','opini')
        ->get();

        $realita_opini = count($tb_scraper_label_postagging_realita_samadengan_opini);

        $tb_postagging_label_postagging_ekspektasi_samadengan_bukan_opini_status_postagging_samadengan_cocok = DB::table('tb_postagging')
        ->select(DB::raw('tb_postagging.*','tb_scraper.*'))
        ->where('tb_postagging.label_postagging_ekspektasi','=','bukan opini')
        ->where('tb_postagging.status_postagging','=','cocok')
        ->join('tb_scraper','tb_scraper.ID','=','tb_postagging.id_tweet')
        ->get();

        $ekspektasi_bukan_opini_cocok = count($tb_postagging_label_postagging_ekspektasi_samadengan_bukan_opini_status_postagging_samadengan_cocok);

        $tb_postagging_label_postagging_ekspektasi_samadengan_bukan_opini_status_postagging_samadengan_tidak_cocok = DB::table('tb_postagging')
        ->select(DB::raw('tb_postagging.*','tb_scraper.*'))
        ->where('tb_postagging.label_postagging_ekspektasi','=','bukan opini')
        ->where('tb_postagging.status_postagging','=','tidak cocok')
        ->join('tb_scraper','tb_scraper.ID','=','tb_postagging.id_tweet')
        ->get();

        $ekspektasi_bukan_opini_tidak_cocok = count($tb_postagging_label_postagging_ekspektasi_samadengan_bukan_opini_status_postagging_samadengan_tidak_cocok);

        $tb_scraper_label_postagging_realita_samadengan_bukan_opini = DB::table('tb_scraper')
        ->select(DB::raw('tb_scraper.*'))
        ->where('tb_scraper.label_postagging_realita','=','bukan opini')
        ->get();

        $realita_bukan_opini = count($tb_scraper_label_postagging_realita_samadengan_bukan_opini);

        // dd($tb_postagging_label_postagging_ekspektasi_samadengan_bukan_opini_status_postagging_samadengan_tidak_cocok);

        //========================================================================================================================

        //========================== postagging akurasi precision recall postagging viterbi=======================================

        $tb_postagging_label_naivebayes_ekspektasi_samadengan_positif_status_naivebayes_samadengan_cocok = DB::table('tb_naivebayes')
        ->select(DB::raw('tb_naivebayes.*','tb_scraper.*'))
        ->where('tb_naivebayes.label_naive_bayes_ekspektasi','=','positif')
        ->where('tb_naivebayes.status_naive_bayes','=','cocok')
        ->join('tb_scraper','tb_scraper.ID','=','tb_naivebayes.id_tweet')
        ->get();

        $ekspektasi_positif_cocok = count($tb_postagging_label_naivebayes_ekspektasi_samadengan_positif_status_naivebayes_samadengan_cocok);

        $tb_postagging_label_naivebayes_ekspektasi_samadengan_positif_status_naivebayes_samadengan_tidak_cocok = DB::table('tb_naivebayes')
        ->select(DB::raw('tb_naivebayes.*','tb_scraper.*'))
        ->where('tb_naivebayes.label_naive_bayes_ekspektasi','=','positif')
        ->where('tb_naivebayes.status_naive_bayes','=','tidak cocok')
        ->join('tb_scraper','tb_scraper.ID','=','tb_naivebayes.id_tweet')
        ->get();

        $ekspektasi_positif_tidak_cocok = count($tb_postagging_label_naivebayes_ekspektasi_samadengan_positif_status_naivebayes_samadengan_tidak_cocok);

        $tb_scraper_label_naive_bayes_realita_samadengan_positif = DB::table('tb_scraper')
        ->select(DB::raw('tb_scraper.*'))
        ->where('tb_scraper.label_naive_bayes_realita','=','positif')
        ->get();

        $realita_positif = count($tb_scraper_label_naive_bayes_realita_samadengan_positif);

        $tb_postagging_label_naivebayes_ekspektasi_samadengan_negatif_status_naivebayes_samadengan_cocok = DB::table('tb_naivebayes')
        ->select(DB::raw('tb_naivebayes.*','tb_scraper.*'))
        ->where('tb_naivebayes.label_naive_bayes_ekspektasi','=','negatif')
        ->where('tb_naivebayes.status_naive_bayes','=','cocok')
        ->join('tb_scraper','tb_scraper.ID','=','tb_naivebayes.id_tweet')
        ->get();

        $ekspektasi_negatif_cocok = count($tb_postagging_label_naivebayes_ekspektasi_samadengan_negatif_status_naivebayes_samadengan_cocok);

        $tb_postagging_label_naivebayes_ekspektasi_samadengan_negatif_status_naivebayes_samadengan_tidak_cocok = DB::table('tb_naivebayes')
        ->select(DB::raw('tb_naivebayes.*','tb_scraper.*'))
        ->where('tb_naivebayes.label_naive_bayes_ekspektasi','=','negatif')
        ->where('tb_naivebayes.status_naive_bayes','=','tidak cocok')
        ->join('tb_scraper','tb_scraper.ID','=','tb_naivebayes.id_tweet')
        ->get();

        $ekspektasi_negatif_tidak_cocok = count($tb_postagging_label_naivebayes_ekspektasi_samadengan_negatif_status_naivebayes_samadengan_tidak_cocok);

        $tb_scraper_label_naive_bayes_realita_samadengan_negatif = DB::table('tb_scraper')
        ->select(DB::raw('tb_scraper.*'))
        ->where('tb_scraper.label_naive_bayes_realita','=','negatif')
        ->get();

        $realita_negatif = count($tb_scraper_label_naive_bayes_realita_samadengan_negatif);

        // dd($ekspektasi_opini_cocok);

        //========================================================================================================================

      return view('pages/proses_akurasi/index',[
      'ekspektasi_opini_cocok'=>$ekspektasi_opini_cocok,
      'ekspektasi_opini_tidak_cocok'=>$ekspektasi_opini_tidak_cocok,
      'realita_opini'=>$realita_opini,
      'ekspektasi_bukan_opini_cocok'=>$ekspektasi_bukan_opini_cocok,
      'ekspektasi_bukan_opini_tidak_cocok'=>$ekspektasi_bukan_opini_tidak_cocok,
      'realita_bukan_opini'=>$realita_bukan_opini,

      'ekspektasi_positif_cocok'=>$ekspektasi_positif_cocok,
      'ekspektasi_positif_tidak_cocok'=>$ekspektasi_positif_tidak_cocok,
      'realita_positif'=>$realita_positif,
      'ekspektasi_negatif_cocok'=>$ekspektasi_negatif_cocok,
      'ekspektasi_negatif_tidak_cocok'=>$ekspektasi_negatif_tidak_cocok,
      'realita_negatif'=>$realita_negatif]);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}
