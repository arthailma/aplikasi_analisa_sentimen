<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use Illuminate\Support\Facades\DB;
use App\tb_scraper;
use App\tb_preprocessing;
use App\tb_postagging;
use App\tb_naivebayes;

use Sastrawi\Stemmer\StemmerFactory;

class preprocessingController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $tb_scraper = DB::table('tb_scraper')
        ->select(DB::raw('tb_scraper.*'))
        ->get();

        return view('pages/proses_testing/preprocessing/index',['scraper'=>$tb_scraper]);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }


    public function cleaning_index(){
      $tb_scraper = DB::table('tb_scraper')
      ->select(DB::raw('tb_scraper.*, tb_preprocessing.cleaning'))
      ->join('tb_preprocessing', 'tb_scraper.ID', '=', 'tb_preprocessing.id_tweet')
      ->get();

      return view('pages/proses_testing/preprocessing/cleaning/index',['scraper'=>$tb_scraper]);
    }

    public function cleaning_proses(){
      $tb_preprocessing_deleted = tb_preprocessing::truncate();
      $tb_preprocessing_deleted->delete();

      // DB::table('tb_preprocessing')
      //       ->update(['tb_preprocessing.cleaning' => ""]);

      $tb_scraper = DB::table('tb_scraper')
      ->select(DB::raw('tb_scraper.*'))
      ->get();

      $tb_preprocessing = DB::table('tb_preprocessing')
      ->select(DB::raw('tb_preprocessing.*, tb_scraper.text'))
      ->join('tb_scraper', 'tb_scraper.ID', '=', 'tb_preprocessing.id_tweet')
      ->get();

        foreach ($tb_scraper as $data) {

          $tweet_asli = $data->text;

          $string_tweet_1 = str_replace("."," ",$tweet_asli);

          //menghilangkan koma
          $string_tweet_2 = str_replace(","," ",$string_tweet_1);

          $string_tweet_3 = preg_replace('/(?=[^ ]*[^A-Za-z \'-])([^ ]*)(?:\\s+|$)/', '', $string_tweet_2);
          $string_tweet_4 = str_replace("-"," ",$string_tweet_3);

          $tb_preprocessing_tambah = new tb_preprocessing;
          $tb_preprocessing_tambah->id_tweet = $data->ID;
          $tb_preprocessing_tambah->cleaning = $string_tweet_4;
          $tb_preprocessing_tambah->casefolding = '';
          $tb_preprocessing_tambah->normalisasi = '';
          $tb_preprocessing_tambah->filtering = '';
          $tb_preprocessing_tambah->stemming = '';
          $tb_preprocessing_tambah->save();

        }

      return back();

    }


    public function casefolding_index(){
      $tb_preprocessing = DB::table('tb_preprocessing')
      ->select(DB::raw('tb_preprocessing.*, tb_scraper.usernameTweet'))
      ->join('tb_scraper', 'tb_scraper.ID', '=', 'tb_preprocessing.id_tweet')
      ->get();
      return view('pages/proses_testing/preprocessing/casefolding/index',['preprocessing'=>$tb_preprocessing]);
    }

    public function casefolding_proses(){

      DB::table('tb_preprocessing')
            ->update(['tb_preprocessing.casefolding' => ""]);

      $table_preprocessing = DB::table('tb_preprocessing')
      ->select(DB::raw('tb_preprocessing.*'))
      ->get();

      foreach ($table_preprocessing as $data) {
        $tweet_cleaning = $data->cleaning;

        $string_tweet_1 = strtolower($data->cleaning);

        // $tb_preprocessing_update_casefolding = tb_preprocessing::find($data->id_tweet);
        // $tb_preprocessing_update_casefolding->casefolding = $string_tweet_1;
        // $tb_preprocessing_update_casefolding->update();

        //update tabel casefolding di table tb_preprocessing
        tb_preprocessing::where('id_tweet', $data->id_tweet)->update(array('casefolding' => $string_tweet_1));

      }

      return back();
    }

    public function tokenizing_index(){
      $tb_preprocessing = DB::table('tb_preprocessing')
      ->select(DB::raw('tb_preprocessing.*, tb_scraper.usernameTweet'))
      ->join('tb_scraper', 'tb_scraper.ID', '=', 'tb_preprocessing.id_tweet')
      ->get();
      return view('pages/proses_testing/preprocessing/tokenizing/index',['preprocessing'=>$tb_preprocessing]);
    }

    public function normalisasi_index(){
      $tb_preprocessing = DB::table('tb_preprocessing')
      ->select(DB::raw('tb_preprocessing.*, tb_scraper.usernameTweet'))
      ->join('tb_scraper', 'tb_scraper.ID', '=', 'tb_preprocessing.id_tweet')
      ->get();
      return view('pages/proses_testing/preprocessing/normalisasi/index',['preprocessing'=>$tb_preprocessing]);
    }

    public function normalisasi_proses(){
      set_time_limit(300);

      DB::table('tb_preprocessing')
            ->update(['tb_preprocessing.normalisasi' => ""]);

        // referensi
        // https://stackoverflow.com/questions/3426265/php-string-replace-match-whole-word

        $tb_normalisasi = DB::table('tb_normalisasi')
        ->select(DB::raw('tb_normalisasi.*'))
        ->get();

        $kata_gaul = [];
        $kata_normalisasi = [];

        foreach ($tb_normalisasi as $data) {

          $kata_gaul[] = '/\b'.''.$data->kata_gaul.''.'\b/u';
          $kata_normalisasi[] = ''.$data->normalisasi.'';

        }

        $tb_preprocessing = DB::table('tb_preprocessing')
        ->select('tb_preprocessing.*')
        ->get();

        foreach ($tb_preprocessing as $data) {

          // $String = preg_replace($kata_gaul,$kata_normalisasi,$data->casefolding);
          // echo $String."<br>";

          $tweet_normalisasi_final = preg_replace($kata_gaul,$kata_normalisasi,$data->casefolding);
          // $tweet_normalisasi_final_2 = preg_replace('/\b'.'tidak '.'\b/u','tidak', $tweet_normalisasi_final);

          // $tb_scraper_update_normaliasi = tb_scraper::find($data->ID);
          // $tb_scraper_update_normaliasi->normalisasi = $tweet_normalisasi_final;
          // $tb_scraper_update_normaliasi->update();

          //update tabel normalisasi di table tb_preprocessing
          tb_preprocessing::where('id_tweet', $data->id_tweet)->update(array('normalisasi' => $tweet_normalisasi_final));

        }

        return back();


    }

    public function filtering_index(){
      $tb_preprocessing = DB::table('tb_preprocessing')
      ->select(DB::raw('tb_preprocessing.*, tb_scraper.usernameTweet'))
      ->join('tb_scraper', 'tb_scraper.ID', '=', 'tb_preprocessing.id_tweet')
      ->get();
      return view('pages/proses_testing/preprocessing/filtering/index',['preprocessing'=>$tb_preprocessing]);
    }

    public function filtering_proses(){

      DB::table('tb_preprocessing')
            ->update(['tb_preprocessing.filtering' => ""]);

      $kata_stopword = [];

      $tb_stopword = DB::table('tb_stopword')
      ->select(DB::raw('tb_stopword.*'))
      ->get();

      foreach ($tb_stopword as $data) {
        $kata_stopword[] = '/\b'.$data->kata.'\b/u';
      }

      // print_r($kata_stopword);

      $tb_preprocessing = DB::table('tb_preprocessing')
      ->select(DB::raw('tb_preprocessing.*'))
      ->get();

      foreach ($tb_preprocessing as $data) {
        $tweet_filter_final = preg_replace($kata_stopword,"",$data->normalisasi);
        // echo $tweet_filter_final;

        //update tabel filtering di table tb_preprocessing
        tb_preprocessing::where('id_tweet', $data->id_tweet)->update(array('filtering' => $tweet_filter_final));

      }

      return back();

    }

    public function stemming_index(){
      $tb_preprocessing = DB::table('tb_preprocessing')
      ->select(DB::raw('tb_preprocessing.*, tb_scraper.usernameTweet'))
      ->join('tb_scraper', 'tb_scraper.ID', '=', 'tb_preprocessing.id_tweet')
      ->get();
      return view('pages/proses_testing/preprocessing/stemming/index',['preprocessing'=>$tb_preprocessing]);
    }

    public function stemming_proses(){
      set_time_limit(1200);
      // referensi
      // https://github.com/sastrawi/sastrawi
      // https://github.com/sastrawi/sastrawi/issues/43

      DB::table('tb_preprocessing')
            ->update(['tb_preprocessing.stemming' => ""]);

      //deleted postagging
      $tb_postaging_deleted = tb_postagging::truncate();
      $tb_postaging_deleted->delete();

      $katadasar = [];

      $tb_katadasar = DB::table('tb_katadasar')
      ->select(DB::raw('tb_katadasar.*'))
      ->get();

      foreach ($tb_katadasar as $data) {
        $katadasar[] = '/\b'.$data->kata.'\b/';
      }

      // print_r($katadasar);
      // $tb_postagging_deleted = tb_postagging::truncate();
      // $tb_postagging_deleted->delete();

      $tb_preprocessing = DB::table('tb_preprocessing')
      ->select(DB::raw('tb_preprocessing.*'))
      ->get();

      foreach ($tb_preprocessing as $data) {

          $stemmerFactory = new \Sastrawi\Stemmer\StemmerFactory();
          $stemmer  = $stemmerFactory->createStemmer();

          $tweet_filtering = $data->filtering;
          $tweet_stemming_final  = $stemmer->stem($tweet_filtering);


          // proses seleksi kata dasar (jika tidak ada di kbbi maka akan di hapus)
          $kalimat = $tweet_stemming_final;

          $tweet_stemming_final_1 = preg_replace($katadasar,"",$kalimat);

          $kalimat_pecah_stemming_final_1 = explode(" ",$tweet_stemming_final_1);

          $kalimat_pecah_stemming_final_2 = [];
          for($i=0; $i<count($kalimat_pecah_stemming_final_1); $i++){
            $kalimat_pecah_stemming_final_2[] = '/\b'.$kalimat_pecah_stemming_final_1[$i].'\b/';
          }

          $tweet_stemming_final_3 = preg_replace($kalimat_pecah_stemming_final_2,"",$kalimat);
          //---------------------------------------------------------------------

          // echo $tweet_stemming_final_3;

          //untuk negasi
          $tweet_stemming_final_4 = preg_replace('/\b'.'tidak '.'\b/u','tidak', $tweet_stemming_final_3);

          //menghapus spasi final
          // $tweet_stemming_final_5 = preg_replace(' ','');

          //update tabel stemming di table tb_preprocessing

          //menghapus 4 spasi
          $tweet_stemming_final_5 = str_replace('    ',' ', $tweet_stemming_final_4);
          //menghapus 3 spasi
          $tweet_stemming_final_6 = str_replace('   ',' ', $tweet_stemming_final_5);
          //menghapus 2 spasi
          $tweet_stemming_final_7 = str_replace('  ',' ', $tweet_stemming_final_6);
          //menghapus spasi di depan
          $ptn = "/^ /";  // Regex
          $rpltxt = "";  // Replacement string
          $tweet_stemming_final_8 = preg_replace($ptn, $rpltxt, $tweet_stemming_final_7);
          //menghapus spasi di belakang
          $tweet_stemming_final_9 = rtrim($tweet_stemming_final_8, " ");

          tb_preprocessing::where('id_tweet', $data->id_tweet)->update(array('stemming' => $tweet_stemming_final_9));

          //mengganti kata 'tidak' menjadi 'tidak ' untuk proses postagging (menentukan opini atau tidak)
          $stemming_postagging = str_replace('tidak','tidak ',$tweet_stemming_final_9);

          // echo $stemming_postagging;

        // tambah id_tweet di table tb_postagging
        $tb_postagging_tambah_id_tweet = new tb_postagging;
        $tb_postagging_tambah_id_tweet->id_tweet = $data->id_tweet;
        $tb_postagging_tambah_id_tweet->stemming_postagging = $stemming_postagging;
        $tb_postagging_tambah_id_tweet->tag = '';
        $tb_postagging_tambah_id_tweet->rule_deteksi = '';
        $tb_postagging_tambah_id_tweet->label_postagging_ekspektasi	 = '';
        $tb_postagging_tambah_id_tweet->status_postagging = '';
        $tb_postagging_tambah_id_tweet->save();

      }


      $tb_naive_bayes_deleted = tb_naivebayes::truncate();
      $tb_naive_bayes_deleted->delete();

      //mengambil data scraper yang ber status negatif dan positif
      $tb_postagging_tambah_id_twwet_ke_tb_naivebayes = DB::table('tb_scraper')
      ->select(DB::raw('tb_scraper.*'))
      ->whereIn('tb_scraper.label_naive_bayes_realita',array('positif','negatif'))
      ->get();

      foreach ($tb_postagging_tambah_id_twwet_ke_tb_naivebayes as $data) {
        $tambah_naive_bayes = new tb_naivebayes;
        $tambah_naive_bayes->id_tweet = $data->ID;
        $tambah_naive_bayes->detail_bobot_naive_bayes_positif = '';
        $tambah_naive_bayes->detail_bobot_naive_bayes_negatif = '';
        $tambah_naive_bayes->hasil_naive_bayes_sentimen_positif = '';
        $tambah_naive_bayes->hasil_naive_bayes_sentimen_negatif = '';
        $tambah_naive_bayes->label_naive_bayes_ekspektasi	 = '';
        $tambah_naive_bayes->status_naive_bayes	 = '';

        $tambah_naive_bayes->save();
      }

      return back();
      // dd($tb_postagging_tambah_id_twwet_ke_tb_naivebayes);


      // $stemmerFactory = new \Sastrawi  \Stemmer\StemmerFactory();
      // $stemmer  = $stemmerFactory->createStemmer();
      //
      // $tweet_filtering = 'menteri';
      // $tweet_stemming_final  = $stemmer->stem($tweet_filtering);
      // echo $tweet_stemming_final;
    }
}
