<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

use App\tb_scraper;

use App\Exports\datatestingExport;
use App\Imports\datatestingImport;

use Maatwebsite\Excel\Facades\Excel;

use Response;

class scrapingController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $scraper = DB::table('tb_scraper')
        ->select(DB::raw('tb_scraper.*'))
        ->get();

        // $jumlah_scrape_1 = $jumlah_scrape[0];
        // dd($jumlah_scrape[0]);

        return view('pages/proses_testing/scraping/index',['scraper'=>$scraper]);

    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
    public function scraping_start(Request $request){

      $search = $request['search'];
      $date1 = $request['date1'];
      $date2 = $request['date2'];

      //referensi
      //https://winaero.com/blog/kill-process-windows-10/
      //https://www.simonlindgren.com/notes/2017/11/7/scrape-tweets-without-using-the-api


      // untuk menjalankan python di php
      chdir('D:\Project_python\TweetScraper-master');
      // shell_exec('scrapy crawl TweetScraper -a query="jokowi"');
      // shell_exec('scrapy crawl TweetScraper -a query="jokowi since:2017-01-01 until:2017-01-02"');
      // shell_exec('scrapy crawl TweetScraper -a query="jokowi until:2017-01-02"');
      shell_exec('scrapy crawl TweetScraper -a query="'.$search.' since:'.$date1.' until:'.$date2.'"');

      return back();
    }

    public function scraping_stop(){

      //referensi
      //https://winaero.com/blog/kill-process-windows-10/
      //https://www.simonlindgren.com/notes/2017/11/7/scrape-tweets-without-using-the-api

      // untuk menghentikan proses scrapping
      chdir('D:\Project_python\TweetScraper-master');
      exec('taskkill /IM "scrapy.exe" /F');

      // return back();
      return redirect('scraping');


    }

    public function scraping_delete_semua(){
      // truncate untuk delete semua isi table;
      $admin = tb_scraper::truncate();
      $admin->delete();

      return back();

    }

    public function scraping_jumlah_scrape(){
      $jumlah_scrape = DB::table('tb_scraper')
      ->select(DB::raw('count(tb_scraper.ID) as jumlah'))
      ->get();


      echo json_encode($jumlah_scrape);
    }

    public function export()
    {
        return Excel::download(new datatestingExport, 'datatesting.xlsx');
    }

    /**
    * @return \Illuminate\Support\Collection
    */
    public function import()
    {

        $tb_scraper = tb_scraper::truncate();
        $tb_scraper->delete();

        Excel::import(new datatestingImport,request()->file('file'));

        return back();
    }

    public function data_testing_download_template_excel(){
      //PDF file is stored under project/public/download/info.pdf
      $file= public_path(). "/download_excel/template_data_testing_excel.xlsx";
      // dd($file);
      $headers = array(
              'Content-Type: application/excel',
            );

      return Response::download($file, 'template_data_testing_excel.xlsx', $headers);
    }
}
