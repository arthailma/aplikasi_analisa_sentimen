<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use DB;
use App\tb_laplacecorrection;

class laplacecorrectionController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        // dd('coba');
        $tb_laplacecorrection = DB::table('tb_laplacecorrection')
        ->select('tb_laplacecorrection.*')
        ->orderBy('tb_laplacecorrection.kata')
        ->get();

        //=========================== default bobot sentimen positif =====================================
        $jumlah_kata_positif_perkata = DB::table('tb_laplacecorrection')
        ->select(DB::raw('COUNT(DISTINCT `tb_laplacecorrection`.`kata`) as jumlah_kata_positif_perkata'))
        ->get();

        $jumlah_kata_positif_perkata_int = '';
        foreach ($jumlah_kata_positif_perkata as $data) {
          $jumlah_kata_positif_perkata_int = (int)$data->jumlah_kata_positif_perkata;
        }

        $jumlah_kata_positif_semua_kata = DB::table('tb_laplacecorrection')
        ->select(DB::raw('sum(tb_laplacecorrection.jumlah_kata) as jumlah_kata_positif_semua_kata'))
        ->where('tb_laplacecorrection.sentimen','=', 'positif')
        ->get();

        $jumlah_kata_positif_semua_kata_int = '';
        foreach ($jumlah_kata_positif_semua_kata as $data) {
          $jumlah_kata_positif_semua_kata_int = (int)$data->jumlah_kata_positif_semua_kata;
        }

        // dd($jumlah_kata_positif_perkata_int);
        if($jumlah_kata_positif_perkata_int == 0){
          $default_bobot_sentimen_positif = 0;
        }else{
          $default_bobot_sentimen_positif = (0+1)/($jumlah_kata_positif_perkata_int+$jumlah_kata_positif_semua_kata_int);
        }

        // dd($default_bobot_sentimen_positif);
        //==================================================================================================

        //=========================== default bobot sentimen positif =====================================

        $jumlah_kata_negatif_perkata = DB::table('tb_laplacecorrection')
        ->select(DB::raw('COUNT(DISTINCT `tb_laplacecorrection`.`kata`) as jumlah_kata_negatif_perkata'))
        ->get();

        $jumlah_kata_negatif_perkata_int = '';
        foreach ($jumlah_kata_negatif_perkata as $data) {
          $jumlah_kata_negatif_perkata_int = (int)$data->jumlah_kata_negatif_perkata;
        }

        $jumlah_kata_negatif_semua_kata = DB::table('tb_laplacecorrection')
        ->select(DB::raw('sum(tb_laplacecorrection.jumlah_kata) as jumlah_kata_negatif_semua_kata'))
        ->where('tb_laplacecorrection.sentimen','=', 'negatif')
        ->get();

        $jumlah_kata_negatif_semua_kata_int = '';
        foreach ($jumlah_kata_negatif_semua_kata as $data) {
          $jumlah_kata_negatif_semua_kata_int = (int)$data->jumlah_kata_negatif_semua_kata;
        }

        if($jumlah_kata_negatif_semua_kata_int == 0){
          $default_bobot_sentimen_negatif = 0;
        }else{
          $default_bobot_sentimen_negatif = (0+1)/($jumlah_kata_negatif_perkata_int+$jumlah_kata_negatif_semua_kata_int);
        }

        // dd($default_bobot_sentimen_negatif);
        //==================================================================================================

        // dd($tb_laplacecorrection);
        return view('pages/proses_training/laplacecorrection/index', ['laplacecorrection' => $tb_laplacecorrection,
        'default_bobot_sentimen_positif' => $default_bobot_sentimen_positif,
        'default_bobot_sentimen_negatif' => $default_bobot_sentimen_negatif]);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }

    public function proses_seleksi_kata_laplacecorrection(){
      set_time_limit(1800);
      $tb_laplacecorrection_deleted = tb_laplacecorrection::truncate();
      $tb_laplacecorrection_deleted->delete();
      // DB::table('tb_laplacecorrection')->delete();
      // tb_laplacecorrection::truncate();

      // $tb_laplacecorrection = DB::table('tb_laplacecorrection')
      // ->select('tb_laplacecorrection.*')
      // ->where('tb_laplacecorrection.kata', '=', 'cobaa')
      // ->get();
      // dd($tb_laplacecorrection);
      // echo count($tb_laplacecorrection);

      // $tb_preprocessingtraining = DB::table('tb_preprocessingtraining')
      // ->select('tb_preprocessingtraining.*')
      // ->get();
      //
      // foreach($tb_preprocessingtraining as $data){
      //   // echo $data->stemming;
      //   // print_r(explode(" ",$data->stemming));
      //   $kata_stemming = explode(" ",$data->stemming);
      //   for($i=0; $i<count($kata_stemming); $i++) {
      //     // echo ' '.$kata_stemming[$i].' ';
      //     $tb_laplacecorrection = DB::table('tb_laplacecorrection')
      //     ->select('tb_laplacecorrection.*')
      //     ->where('tb_laplacecorrection.kata', '=', $kata_stemming[$i])
      //     ->get();
      //
      //
      //     // dd($tb_laplacecorrection);
      //     if(count($tb_laplacecorrection) == 0){
      //       $tambah_tb_laplacecorrection = new tb_laplacecorrection;
      //       $tambah_tb_laplacecorrection->kata = $kata_stemming[$i];
      //       $tambah_tb_laplacecorrection->jumlah_kata = 1;
      //       $tambah_tb_laplacecorrection->bobot = 0;
      //       $tambah_tb_laplacecorrection->save();
      //     }else{
      //       foreach ($tb_laplacecorrection as $data2) {
      //         // code...
      //         tb_laplacecorrection::where('kata', $kata_stemming[$i])->update(array('jumlah_kata' => $data2->jumlah_kata + 1));
      //       }
      //     }
      //   }
      // }

      $tb_preprocessingtraining = DB::table('tb_preprocessingtraining')
      ->select('tb_preprocessingtraining.*', 'tb_datatraining.sentimen')
      ->join('tb_datatraining', 'tb_datatraining.ID', '=', 'tb_preprocessingtraining.id_tweet')
      ->get();

      // dd($tb_preprocessingtraining);

      foreach($tb_preprocessingtraining as $data){
        // echo $data->stemming;
        // print_r(explode(" ",$data->stemming));
        $kata_stemming = explode(" ",$data->stemming);

        // print_r($kata_stemming);
        if($data->sentimen == 'positif'){
          for($i=0; $i<count($kata_stemming); $i++) {
            // echo ' '.$kata_stemming[$i].' ';
            $tb_laplacecorrection = DB::table('tb_laplacecorrection')
            ->select('tb_laplacecorrection.*')
            ->where('tb_laplacecorrection.kata', '=', $kata_stemming[$i])
            ->where('tb_laplacecorrection.sentimen', '=', 'positif')
            ->get();

            // echo ' '.$kata_stemming[$i].'positif ';

            // dd($tb_laplacecorrection);
            if(count($tb_laplacecorrection) == 0){
              $tambah_tb_laplacecorrection = new tb_laplacecorrection;
              $tambah_tb_laplacecorrection->kata = $kata_stemming[$i];
              $tambah_tb_laplacecorrection->jumlah_kata = 1;
              $tambah_tb_laplacecorrection->bobot = 0;
              $tambah_tb_laplacecorrection->sentimen = 'positif';
              $tambah_tb_laplacecorrection->save();
            }else{
              foreach ($tb_laplacecorrection as $data2) {
                // code...
                tb_laplacecorrection::where('kata', $kata_stemming[$i])
                ->where('sentimen', 'positif')
                ->update(array('jumlah_kata' => $data2->jumlah_kata + 1));
              }
            }
          }
        }else if($data->sentimen == 'negatif'){
          for($i=0; $i<count($kata_stemming); $i++) {
            // echo ' '.$kata_stemming[$i].' ';
            $tb_laplacecorrection = DB::table('tb_laplacecorrection')
            ->select('tb_laplacecorrection.*')
            ->where('tb_laplacecorrection.kata', '=', $kata_stemming[$i])
            ->where('tb_laplacecorrection.sentimen', '=', 'negatif')
            ->get();

            // echo $kata_stemming[$i];
            // dd($tb_laplacecorrection);
            if(count($tb_laplacecorrection) == 0){
              $tambah_tb_laplacecorrection = new tb_laplacecorrection;
              $tambah_tb_laplacecorrection->kata = $kata_stemming[$i];
              $tambah_tb_laplacecorrection->jumlah_kata = 1;
              $tambah_tb_laplacecorrection->bobot = 0;
              $tambah_tb_laplacecorrection->sentimen = 'negatif';
              $tambah_tb_laplacecorrection->save();
            }else{
              foreach ($tb_laplacecorrection as $data2) {
                // code...
                tb_laplacecorrection::where('kata', $kata_stemming[$i])
                ->where('sentimen', 'negatif')
                ->update(array('jumlah_kata' => $data2->jumlah_kata + 1));
              }
            }
          }
        }

      }

      $res=tb_laplacecorrection::where('kata',' ')->delete();
      $res=tb_laplacecorrection::where('kata','-')->delete();
      return back();
      // dd($tb_laplacecorrectiontraining);
    }
    public function proses_pembobotan_laplacecorrection(){
      $tb_laplacecorrection = DB::table('tb_laplacecorrection')
      ->select('tb_laplacecorrection.*')
      ->get();

      $jumlah_kata_positif_perkata = DB::table('tb_laplacecorrection')
      ->select(DB::raw('COUNT(DISTINCT `tb_laplacecorrection`.`kata`) as jumlah_kata_positif_perkata'))
      // ->where('tb_laplacecorrection.sentimen','=', 'positif')
      ->get();

      $jumlah_kata_positif_perkata_int = '';
      foreach ($jumlah_kata_positif_perkata as $data) {
        $jumlah_kata_positif_perkata_int = $data->jumlah_kata_positif_perkata;
        // dd($jumlah_kata_positif_perkata_int);
      }
      // dd($jumlah_kata_positif_perkata_int[0]);

      $jumlah_kata_negatif_perkata = DB::table('tb_laplacecorrection')
      ->select(DB::raw('COUNT(DISTINCT `tb_laplacecorrection`.`kata`) as jumlah_kata_negatif_perkata'))
      // ->where('tb_laplacecorrection.sentimen','=', 'negatif')
      ->get();

      $jumlah_kata_negatif_perkata_int = '';
      foreach ($jumlah_kata_negatif_perkata as $data) {
        $jumlah_kata_negatif_perkata_int = $data->jumlah_kata_negatif_perkata;
        // dd($jumlah_kata_negatif_perkata_int);
      }

      $jumlah_kata_positif_semua_kata = DB::table('tb_laplacecorrection')
      ->select(DB::raw('sum(tb_laplacecorrection.jumlah_kata) as jumlah_kata_positif_semua_kata'))
      ->where('tb_laplacecorrection.sentimen','=', 'positif')
      ->get();

      $jumlah_kata_positif_semua_kata_int = '';
      foreach ($jumlah_kata_positif_semua_kata as $data) {
        $jumlah_kata_positif_semua_kata_int = (int)$data->jumlah_kata_positif_semua_kata;
        // dd($jumlah_kata_positif_semua_kata_int);
      }

      // dd($jumlah_kata_positif_semua_kata_int);

      $jumlah_kata_negatif_semua_kata = DB::table('tb_laplacecorrection')
      ->select(DB::raw('sum(tb_laplacecorrection.jumlah_kata) as jumlah_kata_negatif_semua_kata'))
      ->where('tb_laplacecorrection.sentimen','=', 'negatif')
      ->get();

      $jumlah_kata_negatif_semua_kata_int = '';
      foreach ($jumlah_kata_negatif_semua_kata as $data) {
        $jumlah_kata_negatif_semua_kata_int = (int)$data->jumlah_kata_negatif_semua_kata;

      }

      // dd($jumlah_kata_negatif_semua_kata_int);

      // dd($jumlah_kata_negatif_semua_kata_int[0]);

      // dd($jumlah_kata_positif_semua_kata);


      // dd($tb_laplacecorrection);
      foreach ($tb_laplacecorrection as $data) {
        if($data->sentimen == 'positif'){
          $rumus_laplace_correction_positif = (int)($data->jumlah_kata+1)/($jumlah_kata_positif_semua_kata_int+$jumlah_kata_positif_perkata_int);
          // dd(($data->jumlah_kata+1));
          // dd($rumus_laplace_correction_positif);
          tb_laplacecorrection::where('id_laplacecorrection', $data->id_laplacecorrection)
          ->update(array('bobot' => $rumus_laplace_correction_positif));
          // $jumlah_kata = $data->jumlah_kata;
          // $int = int()$jumlah_kata;
          // dd($int);

          // DB::table('tb_laplacecorrection')
          //   ->where('id_laplacecorrection', $data->id_laplacecorrection)
          //   ->update(['bobot' => $rumus_laplace_correction_positif]);

          // echo $data->id_laplacecorrection;

        }else if($data->sentimen = 'negatif'){
          $rumus_laplace_correction_negatif = (int)($data->jumlah_kata+1)/($jumlah_kata_negatif_semua_kata_int+$jumlah_kata_negatif_perkata_int);

          tb_laplacecorrection::where('id_laplacecorrection', $data->id_laplacecorrection)
          ->update(array('bobot' => $rumus_laplace_correction_negatif));

        }

      }

      //tambah data id_tweet ke tb_naivebayes
      // $tambah_id_twwet_ke_tb_naivebayes = DB::table('tb_laplacecorrection')
      // ->select(DB::raw('sum(tb_laplacecorrection.jumlah_kata) as jumlah_kata_positif_semua_kata'))
      // ->where('tb_laplacecorrection.sentimen','=', 'negatif')
      // ->get();
      //
      // foreach ($tambah_tb_laplacecorrection as $data) {
      //
      // }


      return back();
    }

    public function laplace_correction_detail($id){

      $id_laplace_correction = $id;

      //laplacecorrection positif
      $tb_laplacecorrection = DB::table('tb_laplacecorrection')
      ->select('tb_laplacecorrection.*')
      ->where('tb_laplacecorrection.id_laplacecorrection','=',$id_laplace_correction)
      ->get();

      $sentimen_kata_string = '';
      foreach ($tb_laplacecorrection as $data) {
        $sentimen_kata_string = $data->sentimen;
      }


      if($sentimen_kata_string == 'positif'){
          $jumlah_kata_positif = DB::table('tb_laplacecorrection')
          ->select(DB::raw('tb_laplacecorrection.*'))
          ->where('tb_laplacecorrection.sentimen','=', 'positif')
          ->where('tb_laplacecorrection.id_laplacecorrection','=',$id_laplace_correction)
          ->get();

          // echo 'positif';
          // print_r($jumlah_kata_positif);
          $kata_string = '';
          $jumlah_kata_positif_int = '';
          $sentimen = '';
          foreach ($jumlah_kata_positif as $data) {
            $kata_string = $data->kata;
            $jumlah_kata_positif_int = (int)$data->jumlah_kata;
            $sentimen = $data->sentimen;
          }

          $jumlah_kata_positif_perkata = DB::table('tb_laplacecorrection')
          ->select(DB::raw('COUNT(DISTINCT `tb_laplacecorrection`.`kata`) as jumlah_kata_positif_perkata'))
          // ->where('tb_laplacecorrection.sentimen','=', 'positif')
          // ->where('tb_laplacecorrection.id_laplacecorrection','=',$id_laplace_correction)
          ->get();

          $jumlah_kata_positif_perkata_int = '';
          foreach ($jumlah_kata_positif_perkata as $data) {
            $jumlah_kata_positif_perkata_int = (int)$data->jumlah_kata_positif_perkata;
          }

          $jumlah_kata_positif_semua_kata = DB::table('tb_laplacecorrection')
          ->select(DB::raw('sum(tb_laplacecorrection.jumlah_kata) as jumlah_kata_positif_semua_kata'))
          ->where('tb_laplacecorrection.sentimen','=', 'positif')
          ->get();

          $jumlah_kata_positif_semua_kata_int = '';
          foreach ($jumlah_kata_positif_semua_kata as $data) {
            $jumlah_kata_positif_semua_kata_int = (int)$data->jumlah_kata_positif_semua_kata;
          }

          $array_laplacecorrection = [$kata_string,$jumlah_kata_positif_int,$jumlah_kata_positif_perkata_int,$jumlah_kata_positif_semua_kata_int,$sentimen];

          // print_r($array_laplacecorrection);
          echo json_encode($array_laplacecorrection);
      }elseif($sentimen_kata = 'negatif'){
        $jumlah_kata_negatif = DB::table('tb_laplacecorrection')
        ->select(DB::raw('tb_laplacecorrection.*'))
        ->where('tb_laplacecorrection.sentimen','=', 'negatif')
        ->where('tb_laplacecorrection.id_laplacecorrection','=',$id_laplace_correction)
        ->get();

        // echo 'negatif';
        // print_r($jumlah_kata_positif);
        $kata_string = '';
        $jumlah_kata_negatif_int = '';
        $sentimen = '';
        foreach ($jumlah_kata_negatif as $data) {
          $kata_string = $data->kata;
          $jumlah_kata_negatif_int = (int)$data->jumlah_kata;
          $sentimen = $data->sentimen;
        }

        $jumlah_kata_negatif_perkata = DB::table('tb_laplacecorrection')
        ->select(DB::raw('COUNT(DISTINCT `tb_laplacecorrection`.`kata`) as jumlah_kata_negatif_perkata'))
        // ->where('tb_laplacecorrection.sentimen','=', 'negatif')
        // ->where('tb_laplacecorrection.id_laplacecorrection','=',$id_laplace_correction)
        ->get();

        $jumlah_kata_negatif_perkata_int = '';
        foreach ($jumlah_kata_negatif_perkata as $data) {
          $jumlah_kata_negatif_perkata_int = (int)$data->jumlah_kata_negatif_perkata;
        }

        $jumlah_kata_negatif_semua_kata = DB::table('tb_laplacecorrection')
        ->select(DB::raw('sum(tb_laplacecorrection.jumlah_kata) as jumlah_kata_negatif_semua_kata'))
        ->where('tb_laplacecorrection.sentimen','=', 'negatif')
        ->get();

        $jumlah_kata_negatif_semua_kata_int = '';
        foreach ($jumlah_kata_negatif_semua_kata as $data) {
          $jumlah_kata_negatif_semua_kata_int = (int)$data->jumlah_kata_negatif_semua_kata;
        }

        $array_laplacecorrection = [$kata_string,$jumlah_kata_negatif_int,$jumlah_kata_negatif_perkata_int,$jumlah_kata_negatif_semua_kata_int,$sentimen];
        // print_r($array_laplacecorrection);
        echo json_encode($array_laplacecorrection);
      }


      // $rumus_laplace_correction_positif = (int)($jumlah_kata_positif+1)/($jumlah_kata_positif_semua_kata_int+$jumlah_kata_positif_perkata_int);


      //=========================

      // foreach ($variable as $key => $value) {
      //   // code...
      // }


    }

    // public
}
