<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use DB;

use App\Exports\datatrainingExport;
use App\Imports\datatrainingImport;

use Maatwebsite\Excel\Facades\Excel;

use Response;

use App\tb_datatraining;

class datatrainingController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $tb_datatraining = DB::table('tb_datatraining')
        ->select(DB::raw('tb_datatraining.*'))
        ->get();
        // dd($tb_datatraining);
        return view('pages/proses_training/datatraining/index',['tb_datatraining'=>$tb_datatraining]);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }

    public function export()
    {
        return Excel::download(new datatrainingExport, 'datatraining.xlsx');
    }

    /**
    * @return \Illuminate\Support\Collection
    */
    public function import()
    {
        $tb_datatraining = tb_datatraining::truncate();
        $tb_datatraining->delete();

        Excel::import(new datatrainingImport,request()->file('file'));

        return back();
    }

    public function data_training_download_template_excel(){
      //PDF file is stored under project/public/download/info.pdf
      $file= public_path(). "/download_excel/template_data_training_excel.xlsx";
      // dd($file);
      $headers = array(
              'Content-Type: application/excel',
            );

      return Response::download($file, 'template_data_training_excel.xlsx', $headers);
    }
}
