<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use DB;
use App\tb_naivebayes;

class naivebayesController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        // dd('naive bayes');
        // dd($request->path());

        // dd(url('/'));
        $tb_naivebayes = DB::table('tb_naivebayes')
        ->select(DB::raw('tb_naivebayes.*, tb_preprocessing.*, tb_scraper.* '))
        ->join('tb_preprocessing', 'tb_preprocessing.id_tweet', '=', 'tb_naivebayes.id_tweet')
        ->join('tb_scraper', 'tb_scraper.ID', '=', 'tb_naivebayes.id_tweet')
        ->get();
        return view('pages/proses_testing/naive_bayes/index',['tb_naivebayes'=>$tb_naivebayes]);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }

    function proses_pembobotan_naive_bayes_positif(){

      $jumlah_kata_positif_perkata = DB::table('tb_laplacecorrection')
      ->select(DB::raw('COUNT(DISTINCT `tb_laplacecorrection`.`kata`) as jumlah_kata_positif_perkata'))
      // ->where('tb_laplacecorrection.sentimen','=', 'positif')
      ->get();

      $jumlah_kata_positif_perkata_int = '';
      foreach ($jumlah_kata_positif_perkata as $data) {
        $jumlah_kata_positif_perkata_int = $data->jumlah_kata_positif_perkata;
      }
      // dd($jumlah_kata_positif_perkata_int[0]);

      $jumlah_kata_positif_semua_kata = DB::table('tb_laplacecorrection')
      ->select(DB::raw('sum(tb_laplacecorrection.jumlah_kata) as jumlah_kata_positif_semua_kata'))
      ->where('tb_laplacecorrection.sentimen','=', 'positif')
      ->get();

      $jumlah_kata_positif_semua_kata_int = '';
      foreach ($jumlah_kata_positif_semua_kata as $data) {
        $jumlah_kata_positif_semua_kata_int = (int)$data->jumlah_kata_positif_semua_kata;
      }

      // dd($jumlah_kata_positif_semua_kata_int[0]);

      $tb_laplacecorrection_sentimen_postitif = DB::table('tb_laplacecorrection')
      ->select(DB::raw('tb_laplacecorrection.*'))
      ->where('tb_laplacecorrection.sentimen', '=', 'positif')
      ->get();

      $data_kata_positif = [];
      $data_bobot_positif = [];

      foreach ($tb_laplacecorrection_sentimen_postitif as $data) {
        $data_kata_positif[] = '/\b'.''.$data->kata.''.'\b/u';
        $data_bobot_positif[] = $data->bobot;
      }

      // dd($data_bobot_positif);

      $tb_naivebayes = DB::table('tb_naivebayes')
      ->select(DB::raw('tb_naivebayes.*,tb_preprocessing.*'))
      ->join('tb_preprocessing','tb_preprocessing.id_tweet','=','tb_naivebayes.id_tweet')
      ->get();

      $id_tweet_gabung = [];

      foreach ($tb_naivebayes as $data) {

        $id_tweet_gabung[] = $data->id_tweet;
        //proses mengganti kata menjadi detial angka pembobotan (yang kata tersebut terdapat di dataset)
        $preg_replace_ganti_kata_ke_bobot = preg_replace($data_kata_positif, $data_bobot_positif, $data->stemming);
        $preg_replace_ganti_kata_ke_bobot_array = explode(' ',$preg_replace_ganti_kata_ke_bobot);

        $final = [];
        for($i=0;$i<count($preg_replace_ganti_kata_ke_bobot_array);$i++){
          // echo $preg_replace_ganti_kata_ke_bobot_array[$i];

          if($preg_replace_ganti_kata_ke_bobot_array[$i] != ""){ //menghilangkan array yang kosong
            if($preg_replace_ganti_kata_ke_bobot_array[$i] != '-'){ //menghilangkan tanda baca '-'
              if(preg_match('/[a-zA-Z]/', $preg_replace_ganti_kata_ke_bobot_array[$i])){
                // echo ' 1';
                // $final[] = '1';
                $final[] = (int)1/($jumlah_kata_positif_semua_kata_int+$jumlah_kata_positif_perkata_int);
              }else{
                // echo ' '.$preg_replace_ganti_kata_ke_bobot_array[$i];
                $final[] = $preg_replace_ganti_kata_ke_bobot_array[$i];
              }
            }
          }else{

          }

        }

        // dd((int)1/($jumlah_kata_positif_semua_kata_int+$jumlah_kata_positif_perkata_int));

        $final_array_to_string = implode(" ", $final);

        tb_naivebayes::where('id_tweet', $data->id_tweet)->update(array('detail_bobot_naive_bayes_positif' => $final_array_to_string));

      }

    }

    function proses_pembobotan_naive_bayes_negatif(){

      $jumlah_kata_negatif_perkata = DB::table('tb_laplacecorrection')
      ->select(DB::raw('COUNT(DISTINCT `tb_laplacecorrection`.`kata`) as jumlah_kata_negatif_perkata'))
      // ->where('tb_laplacecorrection.sentimen','=', 'negatif')
      ->get();

      $jumlah_kata_negatif_perkata_int = '';
      foreach ($jumlah_kata_negatif_perkata as $data) {
        $jumlah_kata_negatif_perkata_int = $data->jumlah_kata_negatif_perkata;
      }
      // dd($jumlah_kata_positif_perkata_int[0]);

      $jumlah_kata_negatif_semua_kata = DB::table('tb_laplacecorrection')
      ->select(DB::raw('sum(tb_laplacecorrection.jumlah_kata) as jumlah_kata_negatif_semua_kata'))
      ->where('tb_laplacecorrection.sentimen','=', 'negatif')
      ->get();

      $jumlah_kata_negatif_semua_kata_int = '';
      foreach ($jumlah_kata_negatif_semua_kata as $data) {
        $jumlah_kata_negatif_semua_kata_int = (int)$data->jumlah_kata_negatif_semua_kata;
      }

      // dd($jumlah_kata_positif_semua_kata_int[0]);

      $tb_laplacecorrection_sentimen_negatif = DB::table('tb_laplacecorrection')
      ->select(DB::raw('tb_laplacecorrection.*'))
      ->where('tb_laplacecorrection.sentimen', '=', 'negatif')
      ->get();

      $data_kata_negatif = [];
      $data_bobot_negatif = [];

      foreach ($tb_laplacecorrection_sentimen_negatif as $data) {
        $data_kata_negatif[] = '/\b'.''.$data->kata.''.'\b/u';
        $data_bobot_negatif[] = $data->bobot;
      }

      // dd($data_bobot_negatif);



      $tb_naivebayes = DB::table('tb_naivebayes')
      ->select(DB::raw('tb_naivebayes.*,tb_preprocessing.*'))
      ->join('tb_preprocessing','tb_preprocessing.id_tweet','=','tb_naivebayes.id_tweet')
      ->get();

      $id_tweet_gabung = [];

      // dd($jumlah_kata_negatif_perkata_int);

      foreach ($tb_naivebayes as $data) {

        $id_tweet_gabung[] = $data->id_tweet;
        //proses mengganti kata menjadi detial angka pembobotan (yang kata tersebut terdapat di dataset)
        $preg_replace_ganti_kata_ke_bobot = preg_replace($data_kata_negatif, $data_bobot_negatif, $data->stemming);

        $preg_replace_ganti_kata_ke_bobot_array = explode(' ',$preg_replace_ganti_kata_ke_bobot);



        $final = [];
        for($i=0;$i<count($preg_replace_ganti_kata_ke_bobot_array);$i++){
          // echo $preg_replace_ganti_kata_ke_bobot_array[$i];

          if($preg_replace_ganti_kata_ke_bobot_array[$i] != ""){ //menghilangkan array yang kosong
            if($preg_replace_ganti_kata_ke_bobot_array[$i] != '-'){ //menghilangkan tanda baca '-'
              if(preg_match('/[a-zA-Z]/', $preg_replace_ganti_kata_ke_bobot_array[$i])){
                // echo ' 1';
                // $final[] = '1';
                $final[] = (int)1/($jumlah_kata_negatif_semua_kata_int+$jumlah_kata_negatif_perkata_int);
              }else{
                // echo ' '.$preg_replace_ganti_kata_ke_bobot_array[$i];
                $final[] = $preg_replace_ganti_kata_ke_bobot_array[$i];
              }
            }
          }else{

          }

        }

        // dd($final);

        $final_array_to_string = implode(" ", $final);

        // dd($final_array_to_string);

        tb_naivebayes::where('id_tweet', $data->id_tweet)->update(array('detail_bobot_naive_bayes_negatif' => $final_array_to_string));

      }

    }

    function naive_bayes_hasil_sentimen_positif_dan_negatif(){

      $tb_naivebayes = DB::table('tb_naivebayes')
      ->select(DB::raw('tb_naivebayes.*'))
      ->get();

      foreach ($tb_naivebayes as $data) {

        $data_array_explode_positif = explode(' ',$data->detail_bobot_naive_bayes_positif);
        $perkalian_naive_bayes_positif = array_product($data_array_explode_positif);

        tb_naivebayes::where('id_tweet', $data->id_tweet)->update(array('hasil_naive_bayes_sentimen_positif' => $perkalian_naive_bayes_positif));

        $data_array_explode_negatif = explode(' ',$data->detail_bobot_naive_bayes_negatif);
        $perkalian_naive_bayes_negatif = array_product($data_array_explode_negatif);

        tb_naivebayes::where('id_tweet', $data->id_tweet)->update(array('hasil_naive_bayes_sentimen_negatif' => $perkalian_naive_bayes_negatif));

     }


    }

    function naive_bayes_label_ekspetasi(){
      $tb_naivebayes = DB::table('tb_naivebayes')
      ->select(DB::raw('tb_naivebayes.*'))
      ->get();

      foreach ($tb_naivebayes as $data) {
        if($data->hasil_naive_bayes_sentimen_positif > $data->hasil_naive_bayes_sentimen_negatif){
          $status = 'positif';
        }else if($data->hasil_naive_bayes_sentimen_positif == $data->hasil_naive_bayes_sentimen_negatif){
          $status = 'netral';
        }else if($data->hasil_naive_bayes_sentimen_positif < $data->hasil_naive_bayes_sentimen_negatif){
          $status = 'negatif';
        }

        tb_naivebayes::where('id_tweet', $data->id_tweet)->update(array('label_naive_bayes_ekspektasi' => $status));

      }
    }

    function naive_bayes_status(){
      $tb_naivebayes = DB::table('tb_naivebayes')
      ->select(DB::raw('tb_naivebayes.*,tb_scraper.*'))
      ->join('tb_scraper','tb_scraper.ID','=','tb_naivebayes.id_tweet')
      ->get();

      // dd($tb_naivebayes);

      foreach ($tb_naivebayes as $data) {
        if($data->label_naive_bayes_ekspektasi == $data->label_naive_bayes_realita){
          // $status = 'positif';
          tb_naivebayes::where('id_tweet', $data->id_tweet)->update(array('status_naive_bayes' => 'cocok'));
          // echo 'cocok';
        }else{
          // $status = 'netral';
          tb_naivebayes::where('id_tweet', $data->id_tweet)->update(array('status_naive_bayes' => 'tidak cocok'));
          // echo 'tidak cocok';
        }



      }
    }


    public function naive_bayes_proses(){
      set_time_limit(600);

      $this->proses_pembobotan_naive_bayes_positif();
      $this->proses_pembobotan_naive_bayes_negatif();
      $this->naive_bayes_hasil_sentimen_positif_dan_negatif();
      $this->naive_bayes_label_ekspetasi();
      $this->naive_bayes_status();

      return back();
    }

    public function naive_bayes_detail($id){
      // echo 'coba';
      $id_naivebayes = $id;

      $tb_naivebayes_detail = DB::table('tb_naivebayes')
      ->select(DB::raw('tb_naivebayes.*,tb_preprocessing.*,tb_scraper.*'))
      ->join('tb_preprocessing','tb_preprocessing.id_tweet','=','tb_naivebayes.id_tweet')
      ->join('tb_scraper','tb_scraper.ID','=','tb_naivebayes.id_tweet')
      ->where('tb_naivebayes.id_tweet','=',$id)
      ->get();

      $tb_laplacecorrection = DB::table('tb_laplacecorrection')
      ->select(DB::raw('tb_laplacecorrection.*'))
      ->get();

      $detail_bobot_naive_bayes_positif = '';
      $detail_bobot_naive_bayes_negatif = '';
      $data_stemming = '';
      foreach ($tb_naivebayes_detail as $data) {
        $detail_bobot_naive_bayes_positif = $data->detail_bobot_naive_bayes_positif;
        $detail_bobot_naive_bayes_negatif = $data->detail_bobot_naive_bayes_negatif;
        $data_stemming = $data->stemming;
      }

      $detail_bobot_naive_bayes_positif_explode = explode(' ',$detail_bobot_naive_bayes_positif);
      $detail_bobot_naive_bayes_negatif_explode = explode(' ',$detail_bobot_naive_bayes_negatif);
      $data_stemming_explode = explode(' ',$data_stemming);








      $tb_laplacecorrection = DB::table('tb_laplacecorrection')
      ->select('tb_laplacecorrection.*')
      ->orderBy('tb_laplacecorrection.kata')
      ->get();

      //=========================== default bobot sentimen positif =====================================
      $jumlah_kata_positif_perkata = DB::table('tb_laplacecorrection')
      ->select(DB::raw('COUNT(DISTINCT `tb_laplacecorrection`.`kata`) as jumlah_kata_positif_perkata'))
      ->get();

      $jumlah_kata_positif_perkata_int = '';
      foreach ($jumlah_kata_positif_perkata as $data) {
        $jumlah_kata_positif_perkata_int = (int)$data->jumlah_kata_positif_perkata;
      }

      $jumlah_kata_positif_semua_kata = DB::table('tb_laplacecorrection')
      ->select(DB::raw('sum(tb_laplacecorrection.jumlah_kata) as jumlah_kata_positif_semua_kata'))
      ->where('tb_laplacecorrection.sentimen','=', 'positif')
      ->get();

      $jumlah_kata_positif_semua_kata_int = '';
      foreach ($jumlah_kata_positif_semua_kata as $data) {
        $jumlah_kata_positif_semua_kata_int = (int)$data->jumlah_kata_positif_semua_kata;
      }

      // dd($jumlah_kata_positif_perkata_int);
      if($jumlah_kata_positif_perkata_int == 0){
        $default_bobot_sentimen_positif = 0;
      }else{
        $default_bobot_sentimen_positif = (0+1)/($jumlah_kata_positif_perkata_int+$jumlah_kata_positif_semua_kata_int);
      }

      // dd($default_bobot_sentimen_positif);
      //==================================================================================================

      //=========================== default bobot sentimen positif =====================================

      $jumlah_kata_negatif_perkata = DB::table('tb_laplacecorrection')
      ->select(DB::raw('COUNT(DISTINCT `tb_laplacecorrection`.`kata`) as jumlah_kata_negatif_perkata'))
      ->get();

      $jumlah_kata_negatif_perkata_int = '';
      foreach ($jumlah_kata_negatif_perkata as $data) {
        $jumlah_kata_negatif_perkata_int = (int)$data->jumlah_kata_negatif_perkata;
      }

      $jumlah_kata_negatif_semua_kata = DB::table('tb_laplacecorrection')
      ->select(DB::raw('sum(tb_laplacecorrection.jumlah_kata) as jumlah_kata_negatif_semua_kata'))
      ->where('tb_laplacecorrection.sentimen','=', 'negatif')
      ->get();

      $jumlah_kata_negatif_semua_kata_int = '';
      foreach ($jumlah_kata_negatif_semua_kata as $data) {
        $jumlah_kata_negatif_semua_kata_int = (int)$data->jumlah_kata_negatif_semua_kata;
      }

      if($jumlah_kata_negatif_semua_kata_int == 0){
        $default_bobot_sentimen_negatif = 0;
      }else{
        $default_bobot_sentimen_negatif = (0+1)/($jumlah_kata_negatif_perkata_int+$jumlah_kata_negatif_semua_kata_int);
      }


      // dd($tb_naivebayes);
      return view('pages/proses_testing/naive_bayes/naive_bayes_detail'
      ,['tb_naivebayes_detail'=>$tb_naivebayes_detail
      ,'tb_laplacecorrection'=>$tb_laplacecorrection
      ,'detail_bobot_naive_bayes_positif_explode'=>$detail_bobot_naive_bayes_positif_explode
      ,'detail_bobot_naive_bayes_negatif_explode'=>$detail_bobot_naive_bayes_negatif_explode
      ,'data_stemming_explode'=>$data_stemming_explode
      ,'default_bobot_sentimen_positif' => $default_bobot_sentimen_positif
      ,'default_bobot_sentimen_negatif' => $default_bobot_sentimen_negatif]);


    }

}
