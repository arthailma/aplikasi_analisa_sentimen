<?php

namespace App\Imports;

use App\tb_scraper;
use Maatwebsite\Excel\Concerns\ToModel;
use Maatwebsite\Excel\Concerns\WithHeadingRow;

class datatestingImport implements ToModel, WithHeadingRow
{
    /**
    * @param array $row
    *
    * @return \Illuminate\Database\Eloquent\Model|null
    */
    public function model(array $row)
    {
        return new tb_scraper([
          'ID'                         => $row['id'],
          'url'                        => $row['url'],
          'datetime'                   => $row['datetime'],
          'text'                       => $row['text'],
          'user_id'                    => $row['user_id'],
          'usernameTweet'              => $row['usernametweet'],
          'label_postagging_realita'   => $row['label_postagging_realita'],
          'label_naive_bayes_realita'  => $row['label_naive_bayes_realita'],
        ]);
    }
}
