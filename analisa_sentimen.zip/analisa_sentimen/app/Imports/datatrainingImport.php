<?php

namespace App\Imports;

use App\tb_datatraining;
use Maatwebsite\Excel\Concerns\ToModel;
use Maatwebsite\Excel\Concerns\WithHeadingRow;

class datatrainingImport implements ToModel, WithHeadingRow
{
    /**
    * @param array $row
    *
    * @return \Illuminate\Database\Eloquent\Model|null
    */
    public function model(array $row)
    {
        return new tb_datatraining([
          'ID'              => $row['id'],
          'url'             => $row['url'],
          'datetime'        => $row['datetime'],
          'text'            => $row['text'],
          'user_id'         => $row['user_id'],
          'usernameTweet'   => $row['usernametweet'],
          'sentimen'        => $row['sentimen'],
        ]);
    }
}
