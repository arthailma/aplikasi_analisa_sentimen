<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class tb_katadasar extends Model
{
    //
}
