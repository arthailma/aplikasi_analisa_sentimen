<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class tb_normalisasi extends Model
{
  protected $table = 'tb_normalisasi';
  protected $primaryKey = 'id_normalisasi';
}
