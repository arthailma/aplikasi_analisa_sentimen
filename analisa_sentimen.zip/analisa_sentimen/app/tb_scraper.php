<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class tb_scraper extends Model
{
  protected $table = 'tb_scraper';
  protected $primaryKey = 'ID';

  protected $fillable = ['ID', 'url', 'datetime', 'text', 'user_id', 'usernameTweet', 'label_postagging_realita', 'label_naive_bayes_realita'];
}
