<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class tb_datatraining extends Model
{
  protected $table = 'tb_datatraining';
  protected $primaryKey = 'ID';

  protected $fillable = ['ID', 'url', 'datetime', 'text', 'user_id', 'usernameTweet', 'sentimen'];
}
