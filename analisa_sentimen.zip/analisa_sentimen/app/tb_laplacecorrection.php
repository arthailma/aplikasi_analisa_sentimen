<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class tb_laplacecorrection extends Model
{
  protected $table = 'tb_laplacecorrection';
  protected $primaryKey = 'id_laplacecorrection';
}
