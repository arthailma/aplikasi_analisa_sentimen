<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class tb_postagging extends Model
{
  protected $table = 'tb_postagging';
  protected $primaryKey = 'id_postagging';
}
