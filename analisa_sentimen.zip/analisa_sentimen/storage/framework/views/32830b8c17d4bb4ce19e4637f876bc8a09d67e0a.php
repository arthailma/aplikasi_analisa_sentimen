<?php $__env->startSection('content'); ?>
<div class="page-wrapper">
    <!-- Bread crumb -->
    <div class="row page-titles">
        <div class="col-md-5 align-self-center">
            <h3 class="text-primary">Dashboard</h3> </div>
        <div class="col-md-7 align-self-center">
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="javascript:void(0)">Home</a></li>
                <li class="breadcrumb-item active">Dashboard</li>
            </ol>
        </div>
    </div>
    <!-- End Bread crumb -->
    <!-- Container fluid  -->
    <div class="container-fluid">
        <!-- Start Page Content -->
        <div class="row">
            <div class="col-4">

                <div class="card">
                    <div class="card-body">
                        <h4 class="card-title">Tabel Rule</h4>
                        <h6 class="card-subtitle">tabel rule</h6>

                        <div id="show" align="left"></div>

                        <div class="table-responsive m-t-20">
                            <table id="myTable" class="table table-bordered table-striped">
                                <thead>
                                    <tr>
                                        <th style="text-align:center">no</th>
                                        <th style="text-align:center">rule</th>
                                        <th style="text-align:center">contoh</th>
                                        <!-- <th style="text-align:center"><a href="<?php echo e(url('opinion_detection_postagging')); ?>" class="btn btn-success">ekspektasi sentimen</a></th> -->
                                    </tr>
                                </thead>
                                <tbody>
                                  <?php
                                    $no = 1;
                                    foreach ($rule_opini as $data) {
                                      // code...

                                  ?>
                                    <tr>
                                        <td style="text-align:center"><?php echo $no++ ?></td>
                                        <td style="text-align:center"><?php echo $data->rule ?></td>
                                        <td style="text-align:center"><?php echo $data->contoh ?></td>
                                    </tr>
                                  <?php
                                  }
                                  ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>

            </div>

            <div class="col-8">

              <div class="row-8">

                  <div class="card">
                      <div class="card-body">
                          <h4 class="card-title">Detail Opinion Detection</h4>
                          <h6 class="card-subtitle">detail opinion detection</h6>

                          <div id="show" align="left"></div>


                      </div>
                  </div>

                </div>

              <div class="row-8">

                <div class="card">
                    <div class="card-body">
                        <table>
                          <?php foreach ($opinion_detection_detail as $data){ ?>

                          <tr>
                            <th width="100px" style="vertical-align: top; text-align: left;">
                              <h3>Id Tweet</h3>
                            </th>
                            <th width="20px" style="vertical-align: top; text-align: left;">
                              <h3>&nbsp; :</h3>
                            </th>
                            <th style="vertical-align: top; text-align: left;">
                              <h3>&nbsp; <?php echo $data->id_tweet ?></h3>
                            </th>
                          </tr>

                          <tr>
                            <th width="100px" style="vertical-align: top; text-align: left;">
                              <h3>Text</h3>
                            </th>
                            <th width="20px" style="vertical-align: top; text-align: left;">
                              <h3>&nbsp; :</h3>
                            </th>
                            <th style="vertical-align: top; text-align: left;">
                              <h3>&nbsp; <?php echo $data->text ?></h3>
                            </th>
                          </tr>

                          <tr>
                            <th width="100px" style="vertical-align: top; text-align: left;">
                              <h3>Hasil Preprocessing</h3>
                            </th>
                            <th width="20px" style="vertical-align: top; text-align: left;">
                              <h3>&nbsp; :</h3>
                            </th>
                            <th style="vertical-align: top; text-align: left;">
                              <h3>&nbsp; <?php echo $data->stemming_postagging ?></h3>
                            </th>
                          </tr>

                          <?php } ?>

                        </table>


                    </div>
                </div>

              </div>

              <div class="row-8">

                  <div class="card">
                      <div class="card-body">
                        kata rule terdeteksi :
                        <?php foreach ($opinion_detection_detail as $data) {
                          if($data->rule_deteksi == ''){
                            echo 'data rule deteksi tidak ditemukan';
                          }else {
                            echo $data->rule_deteksi;
                          }

                        } ?>

                        <div class="table-responsive m-t-20">
                            <table id="myTable" class="table table-bordered table-striped">
                                <thead>
                                    <tr>
                                      <?php
                                        for($i=0; $i<count($data_stemming_postagging_explode); $i++){
                                      ?>
                                          <th style="text-align:center">
                                            <?php echo $data_stemming_postagging_explode[$i];?>
                                          </th>
                                      <?php
                                        }
                                      ?>

                                        <!-- <th style="text-align:center"><a href="<?php echo e(url('opinion_detection_postagging')); ?>" class="btn btn-success">ekspektasi sentimen</a></th> -->
                                    </tr>
                                </thead>
                                <tbody>
                                  <tr>
                                    <?php
                                      for($i=0; $i<count($data_tag_explode); $i++){
                                    ?>
                                        <th style="text-align:center">
                                          <?php echo $data_tag_explode[$i];?>
                                        </th>
                                    <?php
                                      }
                                    ?>

                                      <!-- <th style="text-align:center"><a href="<?php echo e(url('opinion_detection_postagging')); ?>" class="btn btn-success">ekspektasi sentimen</a></th> -->
                                  </tr>
                                </tbody>
                            </table>
                        </div>


                      </div>
                  </div>

                </div>

                <div class="row-8">

                    <div class="card">
                        <div class="card-body">
                          <table>
                            <?php foreach ($opinion_detection_detail as $data){ ?>

                            <tr>
                              <th width="300px" style="vertical-align: top; text-align: left;">
                                <h3>label postagging ekspektasi</h3>
                              </th>
                              <th width="20px" style="vertical-align: top; text-align: left;">
                                <h3>&nbsp; :</h3>
                              </th>
                              <th style="vertical-align: top; text-align: left;">
                                <h3>&nbsp; <?php echo $data->label_postagging_ekspektasi ?></h3>
                              </th>
                            </tr>

                            <tr>
                              <th width="300px" style="vertical-align: top; text-align: left;">
                                <h3>label postagging realita</h3>
                              </th>
                              <th width="20px" style="vertical-align: top; text-align: left;">
                                <h3>&nbsp; :</h3>
                              </th>
                              <th style="vertical-align: top; text-align: left;">
                                <h3>&nbsp; <?php echo $data->label_postagging_realita ?></h3>
                              </th>
                            </tr>

                            <tr>
                              <th width="300px" style="vertical-align: top; text-align: left;">
                                <h3>status postagging</h3>
                              </th>
                              <th width="20px" style="vertical-align: top; text-align: left;">
                                <h3>&nbsp; :</h3>
                              </th>
                              <th style="vertical-align: top; text-align: left;">
                                <h3>&nbsp; <?php echo $data->status_postagging ?></h3>
                              </th>
                            </tr>

                            <?php } ?>

                          </table>


                        </div>
                    </div>

                  </div>

            </div>

        </div>
        <!-- End PAge Content -->
    </div>
    <!-- End Container fluid  -->
    <!-- footer -->
    <footer class="footer"> © 2018 All rights reserved. Template designed by <a href="https://colorlib.com">Colorlib</a></footer>
    <!-- End footer -->
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>

<!-- referensi div loading every time -->
<!-- https://crunchify.com/how-to-refresh-div-content-without-reloading-page-using-jquery-and-ajax/ -->


<script>

$(document).on('click','.hitung_scraping',function(){

  var myVar = setInterval(myTimer, 100);

  function myTimer() {
    var url = "scraping_jumlah_scrape";
    $.get(url, function (data) {

      var data = JSON.parse(data);
      console.log(data[0].jumlah);

      if(data[0].jumlah == 100){
        clearInterval(myVar);
        window.location.assign("<?php echo e(url('scraping_stop')); ?>");
        // window.location.reload(false);
        // window.location.assign("<?php echo e(url('scraping_stop')); ?>");
        // location.reload();
        // return false;
      }else{
        $('#show').text(
          'jumlah scrape = '
        + data[0].jumlah);
      }

    })
  };
});

</script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\analisa_sentimen\resources\views/pages/proses_testing/opiniondetection/opinion_detection_detail.blade.php ENDPATH**/ ?>