<?php $__env->startSection('content'); ?>
<div class="page-wrapper">
    <!-- Bread crumb -->
    <div class="row page-titles">
        <div class="col-md-5 align-self-center">
            <h3 class="text-primary">Dashboard</h3> </div>
        <div class="col-md-7 align-self-center">
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="javascript:void(0)">Home</a></li>
                <li class="breadcrumb-item active">Dashboard</li>
            </ol>
        </div>
    </div>
    <!-- End Bread crumb -->
    <!-- Container fluid  -->
    <div class="container-fluid">
        <!-- Start Page Content -->
        <div class="row">
            <div class="col-12">

                <div class="card">
                    <div class="card-body">
                        <h4 class="card-title">Tabel Postagging</h4>
                        <h6 class="card-subtitle">tabel Postagging</h6>

                        <div id="show" align="left"></div>

                        <div class="table-responsive m-t-20">
                            <table id="myTable" class="table table-bordered table-striped">
                                <thead>
                                    <tr>
                                        <th style="text-align:center">no</th>
                                        <th style="text-align:center">id tweet</th>
                                        <th style="text-align:center">usernameTweet</th>
                                        <th style="text-align:center"></th>
                                        <th style="text-align:center"><a href="<?php echo e(url('opinion_detection_postagging')); ?>" class="btn btn-success">tag</a></th>
                                    </tr>
                                </thead>
                                <tbody>
                                  <?php
                                    $no = 1;
                                    foreach ($postagging as $data) {
                                      // code...

                                  ?>
                                    <tr>
                                        <td style="text-align:center"><?php echo $no++ ?></td>
                                        <td style="text-align:center"><?php echo $data->id_tweet ?></td>
                                        <td style="text-align:center"><?php echo $data->usernameTweet ?></td>
                                        <td style="text-align:center"><?php echo $data->stemming ?></td>
                                        <td style="text-align:center"><?php echo $data->tag ?></td>
                                    </tr>
                                  <?php
                                  }
                                  ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>

            </div>
        </div>
        <!-- End PAge Content -->
    </div>
    <!-- End Container fluid  -->
    <!-- footer -->
    <footer class="footer"> © 2018 All rights reserved. Template designed by <a href="https://colorlib.com">Colorlib</a></footer>
    <!-- End footer -->
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>

<!-- referensi div loading every time -->
<!-- https://crunchify.com/how-to-refresh-div-content-without-reloading-page-using-jquery-and-ajax/ -->


<script>

$(document).on('click','.hitung_scraping',function(){

  var myVar = setInterval(myTimer, 100);

  function myTimer() {
    var url = "scraping_jumlah_scrape";
    $.get(url, function (data) {

      var data = JSON.parse(data);
      console.log(data[0].jumlah);

      if(data[0].jumlah == 100){
        clearInterval(myVar);
        window.location.assign("<?php echo e(url('scraping_stop')); ?>");
        // window.location.reload(false);
        // window.location.assign("<?php echo e(url('scraping_stop')); ?>");
        // location.reload();
        // return false;
      }else{
        $('#show').text(
          'jumlah scrape = '
        + data[0].jumlah);
      }

    })
  };
});

</script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\analisa_sentimen\resources\views/pages/opiniondetection/index.blade.php ENDPATH**/ ?>