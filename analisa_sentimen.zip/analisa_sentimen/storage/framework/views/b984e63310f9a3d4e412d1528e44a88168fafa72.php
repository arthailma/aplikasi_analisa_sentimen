<?php echo e($slot); ?>

<?php /**PATH C:\xampp\htdocs\analisa_sentimen\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/footer.blade.php ENDPATH**/ ?>