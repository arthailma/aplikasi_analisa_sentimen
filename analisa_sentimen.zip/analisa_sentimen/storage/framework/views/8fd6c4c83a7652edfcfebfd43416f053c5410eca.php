<?php $__env->startSection('content'); ?>
<div class="page-wrapper">
    <!-- Bread crumb -->
    <div class="row page-titles">
        <div class="col-md-5 align-self-center">
            <h3 class="text-primary">Dashboard</h3> </div>
        <div class="col-md-7 align-self-center">
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a target="_blank" rel="noopener noreferrer" href="javascript:void(0)">Home</a></li>
                <li class="breadcrumb-item active">Dashboard</li>
            </ol>
        </div>
    </div>
    <!-- End Bread crumb -->
    <!-- Container fluid  -->
    <div class="container-fluid">
        <!-- Start Page Content -->
        <div class="row">
            <!-- Column -->
            <div class="col-lg-12">
                <div class="card">
                    <div class="card-body">
                        <div class="card-two">
                            <header>
                                <div class="avatar">
                                    <img src="<?php echo e(asset('images/photo_artha.jpeg')); ?>" alt="Allison Walker" />
                                </div>
                            </header>

                            <h3>Artha Ilma Imanidanantoyo</h3>
                            <div class="desc">
                              IMPLEMENTASI NAIVE BAYES DAN POS TAGGING
                              <br>MENGGUNAKAN METODE HIDDEN MARKOV MODEL VITERBI
                              <br>PADA ANALISA SENTIMEN TERHADAP
                              <br>AKUN TWITTER PRESIDEN JOKO WIDODO
                              <br>DI SAAT PANDEMI COVID - 19
                            </div>
                            <div class="contacts">
                                <a target="_blank" rel="noopener noreferrer" href=""><i class="fa fa-plus"></i></a>
                                <a target="_blank" rel="noopener noreferrer" href=""><i class="fa fa-whatsapp"></i></a>
                                <a target="_blank" rel="noopener noreferrer" href=""><i class="fa fa-envelope"></i></a>
                                <div class="clear"></div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- Column -->
            <!-- Column -->
            <div class="col-lg-12">
                <div class="card">
                    <!-- Nav tabs -->
                    <ul class="nav nav-tabs profile-tab" role="tablist">
                        <li class="nav-item"> <a class="nav-link" data-toggle="tab" href="#analisa_sentimen" role="tab">Analisa Sentimen</a> </li>
                        <li class="nav-item"> <a class="nav-link" data-toggle="tab" href="#algoritma_preprocessing" role="tab">Algoritma Preprocessing</a> </li>
                        <li class="nav-item"> <a class="nav-link" data-toggle="tab" href="#algoritma_laplacecorrection" role="tab">Algoritma Laplace Correction</a> </li>
                        <li class="nav-item"> <a class="nav-link active" data-toggle="tab" href="#algoritma_postagging_viterbi" role="tab">Algoritma POSTagging Viterbi</a> </li>
                        <li class="nav-item"> <a class="nav-link" data-toggle="tab" href="#algoritma_naive_bayes" role="tab">Algoritma Naive Bayes</a> </li>
                        <li class="nav-item"> <a class="nav-link" data-toggle="tab" href="#dataset" role="tab">Dataset</a> </li>
                    </ul>
                    <!-- Tab panes -->
                    <div class="tab-content">
                        <div class="tab-pane" id="analisa_sentimen" role="tabpanel">
                            <div class="card-body">
                              <br>

                              <div class="row">
                                  <!-- Column -->
                                  <div class="col-lg-12">
                                      <div class="card">
                                          <div class="card-body">
                                              <h4 style="text-align: justify;"><besar style="font-size:133%">Analisa Sentimen </besar> merupakan salah satu bidang dari Natural Languange Processing (NLP) yang membangun sistem untuk mengenali dan mengekstraksi opini dalam bentuk teks.
                                                Data tersebut dapat menjelaskan opini masyarakat mengenai produk, merek, layanan, politik, atau topik lainnya. Perusahaan, pemerintah, maupun bidang lainnya kemudian memanfaatkan data-data tersebut untuk
                                                membuat analisis marketing, review produk, umpan-balik produk, dan layanan masyarakat. Sentiment analysis kemudian akan membedakan teks menjadi dua kategori, yakni fakta dan opini. Fakta merupakan ekspresi objetif mengenai sesuatu.
                                                Sementara opini adalah ekpresi subjektif yang menggambarkan sentimen, perasaan, maupun penghargaan terhadap suatu hal.</h4>
                                          </div>
                                      </div>
                                  </div>
                                </div>
                            </div>
                        </div>


                        <div class="tab-pane" id="algoritma_preprocessing" role="tabpanel">
                            <div class="card-body">
                              <br>

                                <div class="row">
                                  <!-- Column -->
                                  <div class="col-lg-12">
                                      <div class="card">
                                          <div class="card-body">
                                            <h4 style="text-align: justify;"><besar style="font-size:133%">Preprocessing </besar>adalah pengolahan data yang bertujuan untuk meminimalisir data / kata yang tidak memiliki nilai dalam object penelitian dan data yang tidak konsisten.
                                              Tahap preprocessing dibagi menjadi beberapa proses yaitu cleaning (untuk menghilangkan url, mestion, tag, tanda baca, angka), casefolding (untuk mengubah huruf asli menjadi huruf kecil atau huruf besar semua), tokenizing (untuk memecah kalimat menjadi kata),
                                              normalisasi (untuk mengganti kata gaul atau kata tidak baku menjadi kata baku), filtering (untuk menghilangkan kata yang tidak diperlukan (stopword)) dan stemming (untuk mengganti kata berimbuhan menjadi kata dasar).</h4>
                                          </div>
                                      </div>
                                  </div>
                                </div>
                                <div class="row">
                                  <!-- Column -->
                                  <div class="col-lg-12">
                                      <div class="card">
                                          <div class="card-body">
                                            <h4 style="text-align: justify;"><besar style="font-size:133%;">Referensi :</besar></h4>

                                            <table style="margin-left:50px">
                                              <tr>
                                                <td style="text-align:left">
                                                  <h4 style="text-align: justify; ">1. Analisis Sentimen Terhadap Pemerintahan Joko Widodo Pada Media Sosila Twitter Menggunkan Naive Bayes (Yonathan Sari Mahardhika, Eri Zuliarso) <a target="_blank" rel="noopener noreferrer" href="<?php echo e(url('referensi_algoritma_preprocessing_1')); ?>">disini</a></h4>
                                                </td>
                                              </tr>
                                              <tr>
                                                <td style="text-align:left">
                                                  <h4 style="text-align: justify;">2. Implementasi support vector machine pada analisa sentimen twitter berdasarkan waktu (Faisal Rahutomo, Imam Fahrur Rozi, Haris Setiyono) <a target="_blank" rel="noopener noreferrer" href="<?php echo e(url('referensi_algoritma_preprocessing_2')); ?>">disini</a></h4>
                                                </td>
                                              </tr>
                                            </table>

                                          </div>
                                      </div>
                                  </div>
                                </div>
                                <div class="row">
                                  <!-- Column -->
                                  <div class="col-lg-12">
                                      <div class="card">
                                          <div class="card-body">
                                            <h4>contoh implementasi preprocessing:</h4>
                                              <h4> -> Contoh Data Testing</h4>
                                                <h4 style=" margin-left: 50px;">- Data Testing</h4>
                                                <img src="<?php echo e(asset('images/gambar_preprocessing/data_training_1.jpg')); ?>" alt="Paris" style="border: 1px solid #ddd; border-radius: 4px; padding: 5px; width: 350px; margin-left: 50px;">
                                              <h4> -> Contoh Implementasi Preprocessing</h4>
                                                <h4 style=" margin-left: 50px;">- Cleaning</h4>
                                                  <h4 style=" margin-left: 60px;">Jadilah pendukung yang cerdas saya yakin pak pak pak pak dan gubernur lainya berharap kebijakan
                                                    PSBB bisa diterapkan oleh semua pihak lebih bijak salurkan langsung bantuan ke dan ke biar adil merata</h4>
                                                <h4 style=" margin-left: 50px;">- Casefolding</h4>
                                                  <h4 style=" margin-left: 60px;">jadilah pendukung yang cerdas saya yakin pak pak pak pak dan gubernur lainya berharap kebijakan
                                                    psbb bisa diterapkan oleh semua pihak lebih bijak salurkan langsung bantuan ke dan ke biar adil merata</h4>
                                                <h4 style=" margin-left: 50px;">- Tokenizing</h4>
                                                  <h4 style=" margin-left: 60px;">Jadilah, pendukung, yang, cerdas, saya, yakin, pak, pak, pak, pak, dan, gubernur, lainya, berharap,
                                                  kebijakan, psbb, bisa, diterapkan, oleh, semua, pihak, lebih, bijak, salurkan, langsung, bantuan, ke, dan, ke, biar, adil, merata</h4>
                                                <h4 style=" margin-left: 50px;">- Normalisasi</h4>
                                                  <h4 style=" margin-left: 60px;">jadilah, pendukung, yang, cerdas, saya, yakin, pak, pak, pak, pak, dan, gubernur, lainya, berharap,
                                                  kebijakan, psbb, bisa, diterapkan, oleh, semua, pihak, lebih, bijak, salurkan, langsung, bantuan, ke, dan, ke, biar, adil, merata</h4>
                                                <h4 style=" margin-left: 50px;">- Filtering</h4>
                                                  <h4 style=" margin-left: 60px;">pendukung, cerdas, gubernur, lainya, berharap, kebijakan, psbb, diterapkan, bijak, salurkan,
                                                  langsung, bantuan, biar, adil, merata </h4>
                                                <h4 style=" margin-left: 50px;">- Stemming</h4>
                                                  <h4 style=" margin-left: 60px;">dukung, cerdas, gubernur, lain, harap, bijak, terap, bijak, salur, langsung, bantu, biar, adil, rata </h4>
                                          </div>
                                      </div>
                                  </div>
                                </div>
                            </div>
                        </div>

                        <div class="tab-pane" id="algoritma_laplacecorrection" role="tabpanel">
                            <div class="card-body">
                              <br>

                              <div class="row">
                                  <!-- Column -->
                                  <div class="col-lg-12">
                                      <div class="card">
                                          <div class="card-body">
                                              <h4 style="text-align: justify;"><besar style="font-size:133%">Laplacecorrection </besar>Dalam proses prediksi untuk
                                                menghindari probabailitas 0 (nol) yang dapat menyebabkan Naïve Bayes Classifier tidak dapat mengklasifikasi sebuah
                                                data inputan dengan baik maka digunakan teknik Laplace Correction. Yaitu sebuah teknik yang menambahkan nilai 1 pada
                                                setiap kombinasi atribut. Untuk jumlah data yang banyak (hingga ribuan) teknik ini akan sangat akurat karena tidak
                                                akan membuat perbedaan yang berarti pada estimasi probabilitas.</h4>
                                          </div>
                                      </div>
                                  </div>
                              </div>
                              <div class="row">
                                  <!-- Column -->
                                  <div class="col-lg-12">
                                      <div class="card">
                                          <div class="card-body">

                                              <h4 style="text-align: justify;"><besar style="font-size:133%;">Referensi :</besar></h4>

                                              <table style="margin-left: 30px;">
                                                <tr>
                                                  <td style="text-align:left">
                                                    <h4>1. referensi Laplace Correction dari youtube klik <a target="_blank" rel="noopener noreferrer" href="https://www.youtube.com/watch?v=EGKeC2S44Rs&list=LLXHYp_5X4FrISSakdYpfnwQ&index=82&t=0s">disini</a></h4>
                                                  </td>
                                                </tr>
                                              </table>

                                          </div>
                                      </div>
                                  </div>
                                </div>
                                <div class="row">
                                    <!-- Column -->
                                    <div class="col-lg-12">
                                        <div class="card">
                                            <div class="card-body">
                                                <h4 style="text-align: justify;"><besar style="font-size:133%;">contoh implementasi algoritma laplace correction :</besar></h4>
                                                <h4 style="text-align: justify; margin-left: 50px; font-size:120%">contoh implementasi algoritma laplace correction berada di laporan penulis di bab 4.2.2,
                                                <br>download laporan penulis klik <a target="_blank" rel="noopener noreferrer" href="<?php echo e(url('laporan_skripsi')); ?>">  disini </a>
                                                <br>download jurnal penulis klik <a target="_blank" rel="noopener noreferrer" href="<?php echo e(url('jurnal_skripsi')); ?>">  disini </a>
                                                </h4>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>


                        <div class="tab-pane active" id="algoritma_postagging_viterbi" role="tabpanel">
                            <div class="card-body">
                              <br>

                              <div class="row">
                                  <!-- Column -->
                                  <div class="col-lg-12">
                                      <div class="card">
                                          <div class="card-body">
                                              <h4 style="text-align: justify;"><besar style="font-size:133%;">POS (Part-of-Speech) Tag </besar>merupakan suatu cara pengkategorian kelas kata, seperti kata benda, kata kerja, kata sifat, dll.
                                                POS Tagger merupakan sebuah aplikasi yang mampu melakukan proses anotasi part-of-speech tag untuk setiap kata di dalam dokumen secara otomatis. POS Tagger ini dikembangkan menggunakan pendekatan Rule-Based berdasarkan aturan tata bahasa Indonesia.
                                                Pertama-tama, POS Tagger akan melakukan tokenisasi terhadap teks menggunakan kamus bahasa Indonesia. Selanjutnya kata-kata yang termasuk ke dalam jenis closed-class word diproses kemudian open-class word. Lalu setiap kata yang ambigu diproses menggunakan
                                                aturan-aturan yang sudah didefinisikan untuk menemukan kelas kata yang tepat. Kata tersebut akan dibiarkan ambigu jika tidak ada aturan yang mampu menyelesaikan kasus kata ambigu tersebut.</h4>

                                              <h4 style="text-align: justify;"><besar style="font-size:133%;">Algoritma Viterbi </besar>adalah algoritma dynamic programming untuk menemukan kemungkinan rangkaian status yang tersembunyi (biasa disebut Viterbi path) yang dihasilkan pada  rangkaian pengamatan kejadian,
                                                terutama dalam lingkup HMM.</h4>
                                          </div>
                                      </div>
                                  </div>
                                </div>
                                <div class="row">
                                    <!-- Column -->
                                    <div class="col-lg-12">
                                        <div class="card">
                                            <div class="card-body">

                                                <h4 style="text-align: justify;"><besar style="font-size:133%;">Referensi :</besar></h4>

                                                <table style="margin-left: 30px;">
                                                  <tr>
                                                    <td style="text-align:left">
                                                      <h4>1. referensi POSTagging Viterbi dari youtube klik <a target="_blank" rel="noopener noreferrer" href="https://www.youtube.com/watch?v=mHEKZ8jv2SY&list=PLC0PzjY99Q_U5bba7gYJicCxIufrFmlTa&index=13">disini</a></h4>
                                                    </td>
                                                  </tr>
                                                  <tr>
                                                    <td style="text-align:left">
                                                      <h4 style="text-align: justify;">2. Part-of-Speech (POS) Tagging Bahasa Indonesia Menggunakan Algoritma Viterbi (Nitin Sabloak, Bebeto Agung Hardono, Derry Alamsyah) <a target="_blank" rel="noopener noreferrer" href="<?php echo e(url('referensi_algoritma_postagging_viterbi_1')); ?>">disini</a></h4>
                                                    </td>
                                                  </tr>
                                                  <tr>
                                                    <td style="text-align:left">
                                                      <h4>3. IMPLEMENTASI RULE-BASED DOCUMENT SUBJECTIVITYPADA SISTEM OPINION MINING (Imam Fahrur Rozi) <a target="_blank" rel="noopener noreferrer" href="<?php echo e(url('referensi_algoritma_postagging_viterbi_2')); ?>">disini</a></h4>
                                                    </td>
                                                  </tr>
                                                </table>

                                            </div>
                                        </div>
                                    </div>
                                  </div>
                                <div class="row">
                                    <!-- Column -->
                                    <div class="col-lg-12">
                                        <div class="card">
                                            <div class="card-body">
                                                <h4>contoh implementasi algoritma postagging viterbi:</h4>
                                                <h4> -> Proses Training</h4>


                                                <h4 style="margin-left: 50px;"> - Proses Emmision <br> <detail style="margin-left: 10px;">Proses Emission Probabilities adalah untuk menyatakan seberapa besar kemungkinan munculnya suatu kata diberikan kelas kata tertentu.</detail> </h4>
                                                  <h4 style="margin-left: 70px;">a. Data Training Untuk Emmision Probabilities
                                                  <!-- <h4 style=" margin-left: 70px;"></h4> -->
                                                    <br> <detail style="margin-left: 17px;">- Data Training 1</detail>
                                                    <table style="text-indent: 10px; margin-left: 17px; text-align:left; border-collapse: collapse; border: 1px solid black;">
                                                      <tr>
                                                        <td>
                                                          <h4 style="text-align:left;">Artha</h4>
                                                        </td>
                                                        <td>
                                                          <h4 style="text-align:left;">Ilma</h4>
                                                        </td>
                                                        <td>
                                                          <h4 style="text-align:left;">dapat</h4>
                                                        </td>
                                                        <td>
                                                          <h4 style="text-align:left;">melihat</h4>
                                                        </td>
                                                        <td>
                                                          <h4 style="text-align:left;">ida</h4>
                                                        </td>
                                                      </tr>
                                                      <tr>
                                                        <td>
                                                          <h4 style="text-align:left;">NNP</h4>
                                                        </td>
                                                        <td>
                                                          <h4 style="text-align:left;">NNP</h4>
                                                        </td>
                                                        <td>
                                                          <h4 style="text-align:left;">VB</h4>
                                                        </td>
                                                        <td>
                                                          <h4 style="text-align:left;">VB</h4>
                                                        </td>
                                                        <td>
                                                          <h4 style="text-align:left;">NNP</h4>
                                                        </td>
                                                      </tr>
                                                    </table>

                                                    <br> <detail style="margin-left: 17px;">- Data Training 2</detail>
                                                    <table style="text-indent: 10px; margin-left: 17px; text-align:left; border-collapse: collapse; border: 1px solid black;">
                                                      <tr>
                                                        <td>
                                                          <h4 style="text-align:left;">Ahmad</h4>
                                                        </td>
                                                        <td>
                                                          <h4 style="text-align:left;">akan</h4>
                                                        </td>
                                                        <td>
                                                          <h4 style="text-align:left;">melihat</h4>
                                                        </td>
                                                        <td>
                                                          <h4 style="text-align:left;">Artha</h4>
                                                        </td>
                                                      </tr>
                                                      <tr>
                                                        <td>
                                                          <h4 style="text-align:left;">NNP</h4>
                                                        </td>
                                                        <td>
                                                          <h4 style="text-align:left;">IN</h4>
                                                        </td>
                                                        <td>
                                                          <h4 style="text-align:left;">VB</h4>
                                                        </td>
                                                        <td>
                                                          <h4 style="text-align:left;">NNP</h4>
                                                        </td>
                                                      </tr>
                                                    </table>
                                                    <br> <detail style="margin-left: 17px;">- Data Training 3</detail>
                                                    <table style="text-indent: 10px; margin-left: 17px; text-align:left; border-collapse: collapse; border: 1px solid black;">
                                                      <tr>
                                                        <td>
                                                          <h4 style="text-align:left;">Andi</h4>
                                                        </td>
                                                        <td>
                                                          <h4 style="text-align:left;">akan</h4>
                                                        </td>
                                                        <td>
                                                          <h4 style="text-align:left;">bertemu</h4>
                                                        </td>
                                                        <td>
                                                          <h4 style="text-align:left;">Ida</h4>
                                                        </td>
                                                      </tr>
                                                      <tr>
                                                        <td>
                                                          <h4 style="text-align:left;">NNP</h4>
                                                        </td>
                                                        <td>
                                                          <h4 style="text-align:left;">IN</h4>
                                                        </td>
                                                        <td>
                                                          <h4 style="text-align:left;">VB</h4>
                                                        </td>
                                                        <td>
                                                          <h4 style="text-align:left;">NNP</h4>
                                                        </td>
                                                      </tr>
                                                    </table>
                                                    <br> <detail style="margin-left: 17px;">- Data Training 4</detail>
                                                    <table style="text-indent: 10px; margin-left: 17px; text-align:left; border-collapse: collapse; border: 1px solid black;">
                                                      <tr>
                                                        <td>
                                                          <h4 style="text-align:left;">Ida</h4>
                                                        </td>
                                                        <td>
                                                          <h4 style="text-align:left;">bertemu</h4>
                                                        </td>
                                                        <td>
                                                          <h4 style="text-align:left;">Ahmad</h4>
                                                        </td>
                                                      </tr>
                                                      <tr>
                                                        <td>
                                                          <h4 style="text-align:left;">NNP</h4>
                                                        </td>
                                                        <td>
                                                          <h4 style="text-align:left;">VB</h4>
                                                        </td>
                                                        <td>
                                                          <h4 style="text-align:left;">NNP</h4>
                                                        </td>
                                                      </tr>
                                                    </table>
                                                  </h4>

                                                  <h4 style="margin-left: 70px;">b. Proses Training Emmision Probabilities 1
                                                    <table style="text-indent: 10px; margin-left: 17px; text-align:left; border-collapse: collapse; border: 1px solid black;">
                                                      <tr>
                                                        <td>
                                                          <h4 style="text-align:left;"></h4>
                                                        </td>
                                                        <td>
                                                          <h4 style="text-align:left;">NNP</h4>
                                                        </td>
                                                        <td>
                                                          <h4 style="text-align:left;">VB</h4>
                                                        </td>
                                                        <td>
                                                          <h4 style="text-align:left;">IN</h4>
                                                        </td>
                                                      </tr>
                                                      <tr>
                                                        <td>
                                                          <h4 style="text-align:left;">Artha</h4>
                                                        </td>
                                                        <td>
                                                          <h4 style="text-align:left;">2</h4>
                                                        </td>
                                                        <td>
                                                          <h4 style="text-align:left;">0</h4>
                                                        </td>
                                                        <td>
                                                          <h4 style="text-align:left;">0</h4>
                                                        </td>
                                                      </tr>
                                                      <tr>
                                                        <td>
                                                          <h4 style="text-align:left;">Ilma</h4>
                                                        </td>
                                                        <td>
                                                          <h4 style="text-align:left;">1</h4>
                                                        </td>
                                                        <td>
                                                          <h4 style="text-align:left;">0</h4>
                                                        </td>
                                                        <td>
                                                          <h4 style="text-align:left;">0</h4>
                                                        </td>
                                                      </tr>
                                                      <tr>
                                                        <td>
                                                          <h4 style="text-align:left;">dapat</h4>
                                                        </td>
                                                        <td>
                                                          <h4 style="text-align:left;">0</h4>
                                                        </td>
                                                        <td>
                                                          <h4 style="text-align:left;">1</h4>
                                                        </td>
                                                        <td>
                                                          <h4 style="text-align:left;">0</h4>
                                                        </td>
                                                      </tr>
                                                      <tr>
                                                        <td>
                                                          <h4 style="text-align:left;">melihat</h4>
                                                        </td>
                                                        <td>
                                                          <h4 style="text-align:left;">0</h4>
                                                        </td>
                                                        <td>
                                                          <h4 style="text-align:left;">2</h4>
                                                        </td>
                                                        <td>
                                                          <h4 style="text-align:left;">0</h4>
                                                        </td>
                                                      </tr>
                                                      <tr>
                                                        <td>
                                                          <h4 style="text-align:left;">Ida</h4>
                                                        </td>
                                                        <td>
                                                          <h4 style="text-align:left;">3</h4>
                                                        </td>
                                                        <td>
                                                          <h4 style="text-align:left;">0</h4>
                                                        </td>
                                                        <td>
                                                          <h4 style="text-align:left;">0</h4>
                                                        </td>
                                                      </tr>
                                                      <tr>
                                                        <td>
                                                          <h4 style="text-align:left;">Ahmad</h4>
                                                        </td>
                                                        <td>
                                                          <h4 style="text-align:left;">2</h4>
                                                        </td>
                                                        <td>
                                                          <h4 style="text-align:left;">0</h4>
                                                        </td>
                                                        <td>
                                                          <h4 style="text-align:left;">0</h4>
                                                        </td>
                                                      </tr>
                                                      <tr>
                                                        <td>
                                                          <h4 style="text-align:left;">akan</h4>
                                                        </td>
                                                        <td>
                                                          <h4 style="text-align:left;">0</h4>
                                                        </td>
                                                        <td>
                                                          <h4 style="text-align:left;">0</h4>
                                                        </td>
                                                        <td>
                                                          <h4 style="text-align:left;">2</h4>
                                                        </td>
                                                      </tr>
                                                      <tr>
                                                        <td>
                                                          <h4 style="text-align:left;">Andi</h4>
                                                        </td>
                                                        <td>
                                                          <h4 style="text-align:left;">1</h4>
                                                        </td>
                                                        <td>
                                                          <h4 style="text-align:left;">0</h4>
                                                        </td>
                                                        <td>
                                                          <h4 style="text-align:left;">0</h4>
                                                        </td>
                                                      </tr>
                                                      <tr>
                                                        <td>
                                                          <h4 style="text-align:left;">bertemu</h4>
                                                        </td>
                                                        <td>
                                                          <h4 style="text-align:left;">0</h4>
                                                        </td>
                                                        <td>
                                                          <h4 style="text-align:left;">2</h4>
                                                        </td>
                                                        <td>
                                                          <h4 style="text-align:left;">0</h4>
                                                        </td>
                                                      </tr>
                                                      <tr>
                                                        <td colspan="4">
                                                          <hr style="border: 10px solid; border-radius: 5px;">
                                                        </td>
                                                      </tr>
                                                      <tr>
                                                        <td>
                                                          <h4 style="text-align:left;">Jumlah</h4>
                                                        </td>
                                                        <td>
                                                          <h4 style="text-align:left;">9</h4>
                                                        </td>
                                                        <td>
                                                          <h4 style="text-align:left;">5</h4>
                                                        </td>
                                                        <td>
                                                          <h4 style="text-align:left;">2</h4>
                                                        </td>
                                                      </tr>
                                                    </table>
                                                  </h4>

                                                  <h4 style=" margin-left: 70px;">b. Proses Training Emmision Probabilities 2
                                                    <table style="text-indent: 10px; margin-left: 17px; text-align:left; border-collapse: collapse; border: 1px solid black;">
                                                      <tr>
                                                        <td>
                                                          <h4 style="text-align:left;"></h4>
                                                        </td>
                                                        <td>
                                                          <h4 style="text-align:left;">NNP</h4>
                                                        </td>
                                                        <td>
                                                          <h4 style="text-align:left;">VB</h4>
                                                        </td>
                                                        <td>
                                                          <h4 style="text-align:left;">IN</h4>
                                                        </td>
                                                      </tr>
                                                      <tr>
                                                        <td>
                                                          <h4 style="text-align:left;">Artha</h4>
                                                        </td>
                                                        <td>
                                                          <h4 style="text-align:left;">2/9</h4>
                                                        </td>
                                                        <td>
                                                          <h4 style="text-align:left;">0/5</h4>
                                                        </td>
                                                        <td>
                                                          <h4 style="text-align:left;">0/2</h4>
                                                        </td>
                                                      </tr>
                                                      <tr>
                                                        <td>
                                                            <h4 style="text-align:left;">Ilma</h4>
                                                        </td>
                                                        <td>
                                                          <h4 style="text-align:left;">1/9</h4>
                                                        </td>
                                                        <td>
                                                          <h4 style="text-align:left;">0/5</h4>
                                                        </td>
                                                        <td>
                                                          <h4 style="text-align:left;">0/2</h4>
                                                        </td>
                                                      </tr>
                                                      <tr>
                                                        <td>
                                                          <h4 style="text-align:left;">dapat</h4>
                                                        </td>
                                                        <td>
                                                          <h4 style="text-align:left;">0/9</h4>
                                                        </td>
                                                        <td>
                                                          <h4 style="text-align:left;">1.5</h4>
                                                        </td>
                                                        <td>
                                                          <h4 style="text-align:left;">0/2</h4>
                                                        </td>
                                                      </tr>
                                                      <tr>
                                                        <td>
                                                          <h4 style="text-align:left;">melihat</h4>
                                                        </td>
                                                        <td>
                                                          <h4 style="text-align:left;">0/9</h4>
                                                        </td>
                                                        <td>
                                                          <h4 style="text-align:left;">2/5</h4>
                                                        </td>
                                                        <td>
                                                          <h4 style="text-align:left;">0/2</h4>
                                                        </td>
                                                      </tr>
                                                      </tr>
                                                      <tr>
                                                        <td>
                                                          <h4 style="text-align:left;">Ida</h4>
                                                        </td>
                                                        <td>
                                                          <h4 style="text-align:left;">3/9</h4>
                                                        </td>
                                                        <td>
                                                          <h4 style="text-align:left;">0/5</h4>
                                                        </td>
                                                        <td>
                                                          <h4 style="text-align:left;">0/2</h4>
                                                        </td>
                                                      </tr>
                                                      <tr>
                                                        <td>
                                                          <h4 style="text-align:left;">Ahmad</h4>
                                                        </td>
                                                          <td>
                                                          <h4 style="text-align:left;">2/9</h4>
                                                        </td>
                                                        <td>
                                                          <h4 style="text-align:left;">0/5</h4>
                                                        </td>
                                                        <td>
                                                          <h4 style="text-align:left;">0/2</h4>
                                                        </td>
                                                      </tr>
                                                      <tr>
                                                        <td>
                                                          <h4 style="text-align:left;">akan</h4>
                                                        </td>
                                                        <td>
                                                          <h4 style="text-align:left;">0/9</h4>
                                                        </td>
                                                        <td>
                                                          <h4 style="text-align:left;">0/5</h4>
                                                        </td>
                                                        <td>
                                                          <h4 style="text-align:left;">2/2</h4>
                                                        </td>
                                                      </tr>
                                                      <tr>
                                                        <td>
                                                          <h4 style="text-align:left;">Andi</h4>
                                                        </td>
                                                        <td>
                                                          <h4 style="text-align:left;">1/9</h4>
                                                        </td>
                                                        <td>
                                                          <h4 style="text-align:left;">0/5</h4>
                                                        </td>
                                                        <td>
                                                          <h4 style="text-align:left;">0/2</h4>
                                                        </td>
                                                      </tr>
                                                      <tr>
                                                        <td>
                                                          <h4 style="text-align:left;">bertemu</h4>
                                                        </td>
                                                        <td>
                                                          <h4 style="text-align:left;">0/9</h4>
                                                        </td>
                                                        <td>
                                                          <h4 style="text-align:left;">2/5</h4>
                                                        </td>
                                                        <td>
                                                          <h4 style="text-align:left;">0/2</h4>
                                                        </td>
                                                      </tr>
                                                    </table>
                                                  </h4>


                                                <h4 style=" margin-left: 50px;"> - Proses Transition <br> <detail style="margin-left: 10px;">Proses Transition Probabilities adalah untuk menyatakan seberapa besar kemungkinan munculnya suatu kelas kata dimana sebelumnya muncul kelas kata tertentu</detail> </h4>
                                                  <h4 style=" margin-left: 70px;">a. Data Training Untuk Transition Probabilities
                                                    <br> <detail style="margin-left: 17px;">- Data Training 1</detail>
                                                    <table style="text-indent: 10px; margin-left: 17px; text-align:left; border-collapse: collapse; border: 1px solid black;">
                                                      <tr>
                                                        <td>
                                                          <h4 style="text-align:left;"></h4>
                                                        </td>
                                                        <td>
                                                          <h4 style="text-align:left;">Artha</h4>
                                                        </td>
                                                        <td>
                                                          <h4 style="text-align:left;">Ilma</h4>
                                                        </td>
                                                        <td>
                                                          <h4 style="text-align:left;">dapat</h4>
                                                        </td>
                                                        <td>
                                                          <h4 style="text-align:left;">melihat</h4>
                                                        </td>
                                                        <td>
                                                          <h4 style="text-align:left;">ida</h4>
                                                        </td>
                                                        <td>
                                                          <h4 style="text-align:left;"></h4>
                                                        </td>
                                                      </tr>
                                                      <tr>
                                                        <td>
                                                          <h4 style="text-align:left;">&lt;S&gt;</h4>
                                                        </td>
                                                        <td>
                                                          <h4 style="text-align:left;">NNP</h4>
                                                        </td>
                                                        <td>
                                                          <h4 style="text-align:left;">NNP</h4>
                                                        </td>
                                                        <td>
                                                          <h4 style="text-align:left;">VB</h4>
                                                        </td>
                                                        <td>
                                                          <h4 style="text-align:left;">VB</h4>
                                                        </td>
                                                        <td>
                                                          <h4 style="text-align:left;">NNP</h4>
                                                        </td>
                                                        <td>
                                                          <h4 style="text-align:left;">&lt;E&gt;</h4>
                                                        </td>
                                                      </tr>
                                                    </table>
                                                    <br> <detail style="margin-left: 17px;">- Data Training 2</detail>
                                                    <table style="text-indent: 10px; margin-left: 17px; text-align:left; border-collapse: collapse; border: 1px solid black;">
                                                      <tr>
                                                        <td>
                                                          <h4 style="text-align:left;"></h4>
                                                        </td>
                                                        <td>
                                                          <h4 style="text-align:left;">Ahmad</h4>
                                                        </td>
                                                        <td>
                                                          <h4 style="text-align:left;">akan</h4>
                                                        </td>
                                                        <td>
                                                          <h4 style="text-align:left;">melihat</h4>
                                                        </td>
                                                        <td>
                                                          <h4 style="text-align:left;">Artha</h4>
                                                        </td>
                                                        <td>
                                                          <h4 style="text-align:left;"></h4>
                                                        </td>
                                                      </tr>
                                                      <tr>
                                                        <td>
                                                          <h4 style="text-align:left;">&lt;S&gt;</h4>
                                                        </td>
                                                        <td>
                                                          <h4 style="text-align:left;">NNP</h4>
                                                        </td>
                                                        <td>
                                                          <h4 style="text-align:left;">IN</h4>
                                                        </td>
                                                        <td>
                                                          <h4 style="text-align:left;">VB</h4>
                                                        </td>
                                                        <td>
                                                          <h4 style="text-align:left;">NNP</h4>
                                                        </td>
                                                        <td>
                                                          <h4 style="text-align:left;">&lt;E&gt;</h4>
                                                        </td>
                                                      </tr>
                                                    </table>
                                                    <br> <detail style="margin-left: 17px;">- Data Training 3</detail>
                                                    <table style="text-indent: 10px; margin-left: 17px; text-align:left; border-collapse: collapse; border: 1px solid black;">
                                                      <tr>
                                                        <td>
                                                          <h4 style="text-align:left;"></h4>
                                                        </td>
                                                        <td>
                                                          <h4 style="text-align:left;">Andi</h4>
                                                        </td>
                                                        <td>
                                                          <h4 style="text-align:left;">akan</h4>
                                                        </td>
                                                        <td>
                                                          <h4 style="text-align:left;">bertemu</h4>
                                                        </td>
                                                        <td>
                                                          <h4 style="text-align:left;">Ida</h4>
                                                        </td>
                                                        <td>
                                                          <h4 style="text-align:left;"></h4>
                                                        </td>
                                                      </tr>
                                                      <tr>
                                                        <td>
                                                          <h4 style="text-align:left;">&lt;S&gt;</h4>
                                                        </td>
                                                        <td>
                                                          <h4 style="text-align:left;">NNP</h4>
                                                        </td>
                                                        <td>
                                                          <h4 style="text-align:left;">IN</h4>
                                                        </td>
                                                        <td>
                                                          <h4 style="text-align:left;">VB</h4>
                                                        </td>
                                                        <td>
                                                          <h4 style="text-align:left;">NNP</h4>
                                                        </td>
                                                        <td>
                                                          <h4 style="text-align:left;">&lt;E&gt;</h4>
                                                        </td>
                                                      </tr>
                                                    </table>
                                                    <br> <detail style="margin-left: 17px;">- Data Training 4</detail>
                                                    <table style="text-indent: 10px; margin-left: 17px; text-align:left; border-collapse: collapse; border: 1px solid black;">
                                                      <tr>
                                                        <td>
                                                          <h4 style="text-align:left;"></h4>
                                                        </td>
                                                        <td>
                                                          <h4 style="text-align:left;">Ida</h4>
                                                        </td>
                                                        <td>
                                                          <h4 style="text-align:left;">bertemu</h4>
                                                        </td>
                                                        <td>
                                                          <h4 style="text-align:left;">Ahmad</h4>
                                                        </td>
                                                        <td>
                                                          <h4 style="text-align:left;"></h4>
                                                        </td>
                                                      </tr>
                                                      <tr>
                                                        <td>
                                                          <h4 style="text-align:left;">&lt;S&gt;</h4>
                                                        </td>
                                                        <td>
                                                          <h4 style="text-align:left;">NNP</h4>
                                                        </td>
                                                        <td>
                                                          <h4 style="text-align:left;">VB</h4>
                                                        </td>
                                                        <td>
                                                          <h4 style="text-align:left;">NNP</h4>
                                                        </td>
                                                        <td>
                                                          <h4 style="text-align:left;">&lt;E&gt;</h4>
                                                        </td>
                                                      </tr>
                                                    </table>
                                                  </h4>
                                                  <h4 style=" margin-left: 70px;">b. Proses Training Transition Probabilities 1
                                                    <table style="text-indent: 10px; margin-left: 17px; text-align:left; border-collapse: collapse; border: 1px solid black;">
                                                      <tr>
                                                        <td>
                                                          <h4 style="text-align:left;"></h4>
                                                        </td>
                                                        <td>
                                                          <h4 style="text-align:left;">NNP</h4>
                                                        </td>
                                                        <td>
                                                          <h4 style="text-align:left;">VB</h4>
                                                        </td>
                                                        <td>
                                                          <h4 style="text-align:left;">IN</h4>
                                                        </td>
                                                        <td>
                                                          <h4 style="text-align:left;">&lt;E&gt;</h4>
                                                        </td>
                                                        <td>
                                                          <h4 style="text-align:left;">Jumlah</h4>
                                                        </td>
                                                      </tr>
                                                      <tr>
                                                        <td>
                                                          <h4 style="text-align:left;">&lt;S&gt;</h4>
                                                        </td>
                                                        <td>
                                                          <h4 style="text-align:left;">4</h4>
                                                        </td>
                                                        <td>
                                                          <h4 style="text-align:left;">0</h4>
                                                        </td>
                                                        <td>
                                                          <h4 style="text-align:left;">0</h4>
                                                        </td>
                                                        <td>
                                                          <h4 style="text-align:left;">0</h4>
                                                        </td>
                                                        <td>
                                                          <h4 style="text-align:left;">4</h4>
                                                        </td>
                                                      </tr>
                                                      <tr>
                                                        <td>
                                                          <h4 style="text-align:left;">NNP</h4>
                                                        </td>
                                                        <td>
                                                          <h4 style="text-align:left;">1</h4>
                                                        </td>
                                                        <td>
                                                          <h4 style="text-align:left;">2</h4>
                                                        </td>
                                                        <td>
                                                          <h4 style="text-align:left;">2</h4>
                                                        </td>
                                                        <td>
                                                          <h4 style="text-align:left;">4</h4>
                                                        </td>
                                                        <td>
                                                          <h4 style="text-align:left;">9</h4>
                                                        </td>
                                                      </tr>
                                                      <tr>
                                                        <td>
                                                          <h4 style="text-align:left;">VB</h4>
                                                        </td>
                                                        <td>
                                                          <h4 style="text-align:left;">4</h4>
                                                        </td>
                                                        <td>
                                                          <h4 style="text-align:left;">1</h4>
                                                        </td>
                                                        <td>
                                                          <h4 style="text-align:left;">0</h4>
                                                        </td>
                                                        <td>
                                                          <h4 style="text-align:left;">0</h4>
                                                        </td>
                                                        <td>
                                                          <h4 style="text-align:left;">5</h4>
                                                        </td>
                                                      </tr>
                                                      <tr>
                                                        <td>
                                                          <h4 style="text-align:left;">IN</h4>
                                                        </td>
                                                        <td>
                                                          <h4 style="text-align:left;">0</h4>
                                                        </td>
                                                        <td>
                                                          <h4 style="text-align:left;">2</h4>
                                                        </td>
                                                        <td>
                                                          <h4 style="text-align:left;">0</h4>
                                                        </td>
                                                        <td>
                                                          <h4 style="text-align:left;">0</h4>
                                                        </td>
                                                        <td>
                                                          <h4 style="text-align:left;">2</h4>
                                                        </td>
                                                      </tr>
                                                    </table>
                                                  </h4>
                                                  <h4 style=" margin-left: 70px;">c. Proses Training Transition Probabilities 2
                                                  <table style="text-indent: 10px; margin-left: 17px; text-align:left; border-collapse: collapse; border: 1px solid black;">
                                                    <tr>
                                                      <td>
                                                        <h4 style="text-align:left;"></h4>
                                                      </td>
                                                      <td>
                                                        <h4 style="text-align:left;">NNP</h4>
                                                      </td>
                                                      <td>
                                                        <h4 style="text-align:left;">VB</h4>
                                                      </td>
                                                      <td>
                                                        <h4 style="text-align:left;">IN</h4>
                                                      </td>
                                                      <td>
                                                        <h4 style="text-align:left;">&lt;E&gt;</h4>
                                                      </td>
                                                    </tr>
                                                    <tr>
                                                      <td>
                                                        <h4 style="text-align:left;">&lt;S&gt;</h4>
                                                      </td>
                                                      <td>
                                                        <h4 style="text-align:left;">4/4</h4>
                                                      </td>
                                                      <td>
                                                        <h4 style="text-align:left;">0/4</h4>
                                                      </td>
                                                      <td>
                                                        <h4 style="text-align:left;">0/4</h4>
                                                      </td>
                                                      <td>
                                                        <h4 style="text-align:left;">0/4</h4>
                                                      </td>
                                                    </tr>
                                                    <tr>
                                                      <td>
                                                        <h4 style="text-align:left;">NNP</h4>
                                                      </td>
                                                      <td>
                                                        <h4 style="text-align:left;">1/9</h4>
                                                      </td>
                                                      <td>
                                                        <h4 style="text-align:left;">2/9</h4>
                                                      </td>
                                                      <td>
                                                        <h4 style="text-align:left;">2/9</h4>
                                                      </td>
                                                      <td>
                                                        <h4 style="text-align:left;">4/9</h4>
                                                      </td>
                                                    </tr>
                                                    <tr>
                                                      <td>
                                                        <h4 style="text-align:left;">VB</h4>
                                                      </td>
                                                      <td>
                                                        <h4 style="text-align:left;">4/5</h4>
                                                      </td>
                                                      <td>
                                                        <h4 style="text-align:left;">1/5</h4>
                                                      </td>
                                                      <td>
                                                        <h4 style="text-align:left;">0/5</h4>
                                                      </td>
                                                      <td>
                                                        <h4 style="text-align:left;">0/5</h4>
                                                      </td>
                                                    </tr>
                                                    <tr>
                                                      <td>
                                                        <h4 style="text-align:left;">IN</h4>
                                                      </td>
                                                      <td>
                                                        <h4 style="text-align:left;">0/2</h4>
                                                      </td>
                                                      <td>
                                                        <h4 style="text-align:left;">2/2</h4>
                                                      </td>
                                                      <td>
                                                        <h4 style="text-align:left;">0/2</h4>
                                                      </td>
                                                      <td>
                                                        <h4 style="text-align:left;">0/2</h4>
                                                      </td>
                                                    </tr>
                                                  </table>
                                                </h4>
                                                <h4> -> Proses Testing</h4>
                                                <h4 style=" margin-left: 53px;">a. Contoh Data Testing Viterbi</h4>
                                                  <h4 style=" margin-left: 70px;">Contoh Data Testing Viterbi adalah data yang akan diolah oleh proses testing viterbi.</h4>
                                                  <table style="text-indent: 10px; margin-left: 70px; text-align:left; border-collapse: collapse; border: 1px solid black;">
                                                    <tr>
                                                      <td>
                                                        <h4 style="text-align:left;">Artha</h4>
                                                      </td>
                                                      <td>
                                                        <h4 style="text-align:left;">akan</h4>
                                                      </td>
                                                      <td>
                                                        <h4 style="text-align:left;">dapat</h4>
                                                      </td>
                                                      <td>
                                                        <h4 style="text-align:left;">melihat</h4>
                                                      </td>
                                                      <td>
                                                        <h4 style="text-align:left;">Andi</h4>
                                                      </td>
                                                    </tr>
                                                  </table>
                                                <h4 style=" margin-left: 53px;">b.	Proses Testing Emmision Probabilities.</h4>
                                                  <h4 style=" margin-left: 70px;">Nilai dari proses Testing Emmision Probabilities diambil dari data Training Emmisin Probabilities.</h4>
                                                  <img src="<?php echo e(asset('images/gambar_postagging_viterbi/emmision_probabilities.jpg')); ?>" alt="Paris" style="border: 1px solid #ddd; border-radius: 4px; padding: 5px; width: 750px; margin-left: 70px;">
                                                <h4 style=" margin-left: 53px;">c.	Proses Testing Transition Probabilities.</h4>
                                                  <h4 style=" margin-left: 70px;">Nilai dari proses Testing Transition Probabilities diambil dari data Training Emmisin Probabilities.</h4>
                                                  <img src="<?php echo e(asset('images/gambar_postagging_viterbi/transition_probabilities.jpg')); ?>" alt="Paris" style="border: 1px solid #ddd; border-radius: 4px; padding: 5px; width: 750px; margin-left: 70px;">
                                                <h4 style=" margin-left: 53px;">d.	Proses Penggabungan Testing Emmision Probabilities dan Testing Training Probabilities.</h4>
                                                  <img src="<?php echo e(asset('images/gambar_postagging_viterbi/gabungan_emmision_dan_transition_probabilities.jpg')); ?>" alt="Paris" style="border: 1px solid #ddd; border-radius: 4px; padding: 5px; width: 750px; margin-left: 70px;">
                                                <h4 style=" margin-left: 53px;">e.	Proses Testing Viterbi.</h4>
                                                  <h4 style=" margin-left: 70px;">Diproses ini penulis akan menjelaskan proses testing viterbi per kata pada data testing “artha akan dapat melihat andi”.</h4>
                                                    <h4 style=" margin-left: 80px;">1.	Tahap algoritma Viterbi pada proses kata “artha”..</h4>
                                                      <img src="<?php echo e(asset('images/gambar_postagging_viterbi/tahap_artha.jpg')); ?>" alt="Paris" style="border: 1px solid #ddd; border-radius: 4px; padding: 5px; width: 750px; margin-left: 80px;">
                                                    <h4 style=" margin-left: 80px;">2.	Tahap algoritma Viterbi pada proses kata “akan”.</h4>
                                                      <img src="<?php echo e(asset('images/gambar_postagging_viterbi/tahap_akan.jpg')); ?>" alt="Paris" style="border: 1px solid #ddd; border-radius: 4px; padding: 5px; width: 750px; margin-left: 80px;">
                                                    <h4 style=" margin-left: 80px;">3.	Tahap algoritma Viterbi pada proses kata “dapat”.</h4>
                                                      <img src="<?php echo e(asset('images/gambar_postagging_viterbi/tahap_dapat.jpg')); ?>" alt="Paris" style="border: 1px solid #ddd; border-radius: 4px; padding: 5px; width: 750px; margin-left: 80px;">
                                                    <h4 style=" margin-left: 80px;">4.	Tahap algoritma Viterbi pada proses kata “melihat”.</h4>
                                                      <img src="<?php echo e(asset('images/gambar_postagging_viterbi/tahap_melihat.jpg')); ?>" alt="Paris" style="border: 1px solid #ddd; border-radius: 4px; padding: 5px; width: 750px; margin-left: 80px;">
                                                    <h4 style=" margin-left: 80px;">5.	Tahap algoritma Viterbi pada proses kata “andi”.</h4>
                                                      <img src="<?php echo e(asset('images/gambar_postagging_viterbi/tahap_andi.jpg')); ?>" alt="Paris" style="border: 1px solid #ddd; border-radius: 4px; padding: 5px; width: 750px; margin-left: 80px;">
                                                <h4 style=" margin-left: 53px;">f.	Kesimpulan dan Hasil Akhir Proses POSTagging Viterbi.</h4>
                                                  <h4 style=" margin-left: 80px;">Tahap ini adalah hasil akhir viterbi pada kalimat “artha akan dapat melihat andi”.</h4>
                                                  <img src="<?php echo e(asset('images/gambar_postagging_viterbi/hasil_akhir.jpg')); ?>" alt="Paris" style="border: 1px solid #ddd; border-radius: 4px; padding: 5px; width: 750px; margin-left: 80px;">
                                            </div>
                                        </div>
                                    </div>
                                  </div>
                            </div>
                        </div>
                        <div class="tab-pane" id="algoritma_naive_bayes" role="tabpanel">
                            <div class="card-body">
                              <div class="row">
                                  <!-- Column -->
                                  <div class="col-lg-12">
                                      <div class="card">
                                          <div class="card-body">
                                              <h4 style="text-align: justify;"><besar style="font-size:133%">Naive Bayes </besar>merupakan sebuah metoda klasifikasi menggunakan metode probabilitas dan statistik yg dikemukakan oleh ilmuwan Inggris Thomas Bayes.
                                                Algoritma Naive Bayes memprediksi peluang di masa depan berdasarkan pengalaman di masa sebelumnya sehingga dikenal sebagai Teorema Bayes.
                                                Ciri utama dr Naïve Bayes Classifier ini adalah asumsi yg sangat kuat (naïf) akan independensi dari masing-masing kondisi / kejadian. Naive Bayes Classifier
                                                bekerja sangat baik dibanding dengan model classifier lainnya. Hal ini dibuktikan pada jurnal Xhemali, Daniela, Chris J. Hinde, and Roger G. Stone.
                                                “Naive Bayes vs. decision trees vs. neural networks in the classification of training web pages.” (2009), mengatakan bahwa “Naïve Bayes Classifier
                                                memiliki tingkat akurasi yg lebih baik dibanding model classifier lainnya”.</h4>
                                          </div>
                                      </div>
                                  </div>
                                </div>
                                <div class="row">
                                    <!-- Column -->
                                    <div class="col-lg-12">
                                        <div class="card">
                                            <div class="card-body">
                                                <h4 style="text-align: justify;"><besar style="font-size:133%;">Referensi :</besar></h4>
                                                <table style="margin-left: 30px;">
                                                  <tr>
                                                    <td style="text-align:left">
                                                      <h4 style="text-align: justify;">1. referensi Naive Bayes dari youtube 1 klik <a target="_blank" rel="noopener noreferrer" href="https://www.youtube.com/watch?v=Zt83JnjD8zg">disini</a></h4>
                                                    </td>
                                                  </tr>
                                                  <tr>
                                                    <td style="text-align:left">
                                                      <h4 style="text-align: justify;">2. referensi Naive Bayes dari youtube 2 klik <a target="_blank" rel="noopener noreferrer" href="https://www.youtube.com/watch?v=EGKeC2S44Rs">disini</a></h4>
                                                    </td>
                                                  </tr>
                                                  <tr>
                                                    <td style="text-align:left">
                                                      <h4 style="text-align: justify;">3. Analisis sentimen terhadap pemerintahan joko widodo pada media sosial twitter menggunakan naive bayes (Yonathan Sari Mahardhika, Eri Zuliarso) <a target="_blank" rel="noopener noreferrer" href="<?php echo e(url('referensi_algoritma_naive_bayes_1')); ?>">disini</a></h4>
                                                    </td>
                                                  </tr>
                                                  <tr>
                                                    <td style="text-align:left">
                                                      <h4 style="text-align: justify;">4. Pengembangan sistem analisa kebepihakan media online berdasarkan tren waktu naive bayes (Faisal Rahutomo, Annisa Taufika Firdausi, Nur Rochmanshah) <a target="_blank" rel="noopener noreferrer" href="<?php echo e(url('referensi_algoritma_naive_bayes_2')); ?>">disini</a></h4>
                                                    </td>
                                                  </tr>
                                                </table>

                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <!-- Column -->
                                    <div class="col-lg-12">
                                        <div class="card">
                                            <div class="card-body">
                                                <h4 style="text-align: justify;"><besar style="font-size:133%;">contoh implementasi algoritma naive bayes :</besar></h4>
                                                <h4 style="text-align: justify; margin-left: 50px; font-size:120%">contoh implementasi algoritma naive bayes berada di laporan penulis di bab 4.2.2,
                                                  <br>download laporan penulis klik <a target="_blank" rel="noopener noreferrer" href="<?php echo e(url('laporan_skripsi')); ?>">  disini </a>
                                                  <br>download jurnal penulis klik <a target="_blank" rel="noopener noreferrer" href="<?php echo e(url('jurnal_skripsi')); ?>">  disini </a>
                                                </h4>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="tab-pane" id="dataset" role="tabpanel">
                            <div class="card-body">
                              <br>
                              <div class="row">
                                  <!-- Column -->
                                  <div class="col-lg-12">
                                      <div class="card">
                                          <div class="card-body">
                                              <h4 style="text-align: justify;"><besar style="font-size:133%">Dataset </besar> kumpulan data yang
                                                 dikumpulkan untuk tujuan tertentu. Ada banyak cara di mana data dapat dikumpulkan — misalnya,
                                                 sebagai bagian dari pemberian layanan, survei satu kali, wawancara, pengamatan, dan sebagainya.
                                                 Untuk memastikan bahwa makna data dalam kumpulan data dipahami dengan jelas dan data dapat
                                                 dikumpulkan dan digunakan secara konsisten, data didefinisikan menggunakan metadata.</h4>
                                          </div>
                                      </div>
                                  </div>
                                </div>
                                <div class="row">
                                    <!-- Column -->
                                    <div class="col-lg-12">
                                        <div class="card">
                                            <div class="card-body">
                                                <h4 style="text-align: justify;"><besar style="font-size:133%;">Referensi :</besar></h4>
                                                <table style="margin-left: 30px;">
                                                  <tr>
                                                    <td style="text-align:left">
                                                      <h4 style="text-align: justify;">1. Dataset stopword (untuk preprocessing filtering)<a target="_blank" rel="noopener noreferrer" href="https://www.kaggle.com/oswinrh/indonesian-stoplist"> disini</a></h4>
                                                    </td>
                                                  </tr>
                                                  <tr>
                                                    <td style="text-align:left">
                                                      <h4 style="text-align: justify;">2. Dataset + App PHP postagging algoritma viterbi <a target="_blank" rel="noopener noreferrer" href="https://github.com/faisalsyfl/IndoPOSTag/tree/master/datasets/idn-tagged-corpus-master#readmemd-versi-bahasa"> disini</a></h4>
                                                    </td>
                                                  </tr>
                                                  <tr>
                                                    <td style="text-align:left">
                                                      <h4 style="text-align: justify;">3. App Python untuk melakukan scraping <a target="_blank" rel="noopener noreferrer" href="https://github.com/jonbakerfish/TweetScraper"> disini</a></h4>
                                                    </td>
                                                  </tr>
                                                  <tr>
                                                    <td style="text-align:left">
                                                      <h4 style="text-align: justify;">4. Dataset KBBI dan stopword <a target="_blank" rel="noopener noreferrer" href="http://hikaruyuuki.lecture.ub.ac.id/kamus-kata-dasar-dan-stopword-list-bahasa-indonesia/"> disini</a></h4>
                                                    </td>
                                                  </tr>
                                                  <tr>
                                                    <td style="text-align:left">
                                                      <h4 style="text-align: justify;">5. Cara import export excel laravel <a target="_blank" rel="noopener noreferrer" href="https://www.itsolutionstuff.com/post/import-and-export-csv-file-in-laravel-58example.html"> disini</a></h4>
                                                    </td>
                                                  </tr>
                                                  <tr>
                                                    <td style="text-align:left">
                                                      <h4 style="text-align: justify;">6. Dataset kata gaul (untuk preprocessing normalisasi) <a target="_blank" rel="noopener noreferrer" href="<?php echo e(url('referensi_dataset_1')); ?>"> disini</a>, websitenya <a target="_blank" rel="noopener noreferrer" href="https://github.com/panggi/pujangga/blob/master/resource/formalization/formalizationDict.txt"> disini</a></h4>
                                                    </td>
                                                  </tr>

                                                </table>

                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- Column -->
        </div>

        <!-- End PAge Content -->
    </div>
    <!-- End Container fluid  -->
    <!-- footer -->
    <footer class="footer"> © 2018 All rights reserved. Template designed by <a target="_blank" rel="noopener noreferrer" href="https://colorlib.com">Colorlib</a></footer>
    <!-- End footer -->
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\analisa_sentimen\resources\views/pages/dashboard/index.blade.php ENDPATH**/ ?>