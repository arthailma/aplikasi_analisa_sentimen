<?php $__env->startSection('content'); ?>
<div class="page-wrapper">
    <!-- Bread crumb -->
    <div class="row page-titles">
        <div class="col-md-5 align-self-center">
            <h3 class="text-primary">Dashboard</h3> </div>
        <div class="col-md-7 align-self-center">
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="javascript:void(0)">Home</a></li>
                <li class="breadcrumb-item active">Dashboard</li>
            </ol>
        </div>
    </div>
    <!-- End Bread crumb -->
    <!-- Container fluid  -->
    <div class="container-fluid">
        <!-- Start Page Content -->
        <div class="row">
            <div class="col-12">

                <div class="card">
                    <div class="card-body">
                        <h4 class="card-title">Tabel Scraping</h4>
                        <h6 class="card-subtitle">tabel Scraping</h6>
                        <form action="<?php echo e(url('scraping_start')); ?>" method = "post" enctype="multipart/form-data">
                          <?php echo e(csrf_field()); ?>

                          <label for="inputEmail3" class="col-sm-3 col-form-label"> <input type="text" name="search" id="search" class="form-control input-rounded " placeholder="search"> </label>
                          <label for="inputEmail3" class="col-sm-2 col-form-label"> <input type="date" name="date1" id="date1" class="form-control input-rounded"> </label>
                          <label for="inputEmail3" class="col-form-label"> sampai </label>
                          <label for="inputEmail3" class="col-sm-2 col-form-label"> <input type="date" name="date2" id="date2" class="form-control input-rounded"> </label>
                          <button type="submit" class="btn btn-success hitung_scraping">Scraping start</button>
                          <a href="<?php echo e(url('scraping_stop')); ?>" class="btn btn-success">Scraping Stop</a>
                          <a href="<?php echo e(url('scraping_delete_semua')); ?>" class="btn btn-danger">Delete semua scrape</a>
                          </form>

                        <div id="show" align="left"></div>

                        <div class="table-responsive m-t-20">
                            <table id="myTable" class="table table-bordered table-striped">
                                <thead>
                                    <tr>
                                        <th style="text-align:center">no</th>
                                        <th style="text-align:center">id tweet</th>
                                        <th style="text-align:center">text</th>
                                        <th style="text-align:center">usernameTweet</th>
                                    </tr>
                                </thead>
                                <tbody>
                                  <?php
                                    $no = 1;
                                    foreach ($scraper as $data) {
                                      // code...

                                  ?>
                                    <tr>
                                        <td style="text-align:center"><?php echo $no++ ?></td>
                                        <td style="text-align:center"><?php echo $data->ID ?></td>
                                        <td style="text-align:center"><?php echo $data->text ?></td>
                                        <td style="text-align:center"><?php echo $data->usernameTweet ?></td>
                                    </tr>
                                  <?php
                                  }
                                  ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>

            </div>
        </div>
        <!-- End PAge Content -->
    </div>
    <!-- End Container fluid  -->
    <!-- footer -->
    <footer class="footer"> © 2018 All rights reserved. Template designed by <a href="https://colorlib.com">Colorlib</a></footer>
    <!-- End footer -->
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>

<!-- referensi div loading every time -->
<!-- https://crunchify.com/how-to-refresh-div-content-without-reloading-page-using-jquery-and-ajax/ -->


<script>

$(document).on('click','.hitung_scraping',function(){

  var myVar = setInterval(myTimer, 100);

  function myTimer() {
    var url = "scraping_jumlah_scrape";
    $.get(url, function (data) {

      var data = JSON.parse(data);
      console.log(data[0].jumlah);

      if(data[0].jumlah == 100){
        clearInterval(myVar);
        window.location.assign("<?php echo e(url('scraping_stop')); ?>");
        // window.location.reload(false);
        // window.location.assign("<?php echo e(url('scraping_stop')); ?>");
        // location.reload();
        // return false;
      }else{
        $('#show').text(
          'jumlah scrape = '
        + data[0].jumlah);
      }

    })
  };
});

</script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\analisa_sentimen\resources\views/pages/scraping/index.blade.php ENDPATH**/ ?>