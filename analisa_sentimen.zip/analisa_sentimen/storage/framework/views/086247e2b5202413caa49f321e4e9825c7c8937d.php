<?php $__env->startSection('content'); ?>
<div class="page-wrapper">
    <!-- Bread crumb -->
    <div class="row page-titles">
        <div class="col-md-5 align-self-center">
            <h3 class="text-primary">Dashboard</h3> </div>
        <div class="col-md-7 align-self-center">
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="javascript:void(0)">Home</a></li>
                <li class="breadcrumb-item active">Normalisasi</li>
            </ol>
        </div>
    </div>
    <!-- End Bread crumb -->
    <!-- Container fluid  -->
    <div class="container-fluid">
        <!-- Start Page Content -->
        <div class="row">
            <div class="col-12">

                <div class="card">
                    <div class="card-body">
                        <h4 class="card-title">Tabel Normalisasi</h4>
                        <h6 class="card-subtitle">tabel Normalisasi</h6>

                        <div class="table-responsive m-t-20">
                            <table id="myTable" class="table table-bordered table-striped">
                                <thead>
                                    <tr>
                                        <th style="text-align:center">no</th>
                                        <th style="text-align:center">text</th>
                                        <th style="text-align:center">usernameTweet</th>
                                        <th style="text-align:center"><a href="<?php echo e(url('preprocessing_normalisasi_proses')); ?>" class="btn btn-success">nomalisasi</a></th>
                                    </tr>
                                </thead>
                                <tbody>
                                  <?php
                                    $no = 1;
                                    foreach ($preprocessing as $data) {
                                      // code...

                                  ?>
                                    <tr>
                                        <td style="text-align:center"><?php echo $no++ ?></td>
                                        <td style="text-align:center"><?php print_r(explode(" ",$data->casefolding)) ?></td>
                                        <td style="text-align:center"><?php echo $data->usernameTweet ?></td>
                                        <td style="text-align:center"><?php echo $data->normalisasi ?></td>
                                    </tr>
                                  <?php
                                  }
                                  ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>

            </div>
        </div>
        <!-- End PAge Content -->
    </div>
    <!-- End Container fluid  -->
    <!-- footer -->
    <footer class="footer"> © 2018 All rights reserved. Template designed by <a href="https://colorlib.com">Colorlib</a></footer>
    <!-- End footer -->
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\analisa_sentimen\resources\views/pages/proses_testing/preprocessing/normalisasi/index.blade.php ENDPATH**/ ?>