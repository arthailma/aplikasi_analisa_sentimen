<?php $__env->startSection('content'); ?>
<div class="page-wrapper">
    <!-- Bread crumb -->
    <div class="row page-titles">
        <div class="col-md-5 align-self-center">
            <h3 class="text-primary">Dashboard</h3> </div>
        <div class="col-md-7 align-self-center">
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="javascript:void(0)">Home</a></li>
                <li class="breadcrumb-item active">Dashboard</li>
            </ol>
        </div>
    </div>
    <!-- End Bread crumb -->
    <!-- Container fluid  -->
    <div class="container-fluid">
        <!-- Start Page Content -->
        <div class="row">
            <div class="col-12">

                <div class="card">
                    <div class="card-body">
                        <h4 class="card-title">Tabel Postagging</h4>
                        <h6 class="card-subtitle">tabel Postagging</h6>
                        <a href="<?php echo e(url('naive_bayes_proses')); ?>" class="btn btn-success">naive bayes start</a>

                        <div id="show" align="left"></div>

                        <div class="table-responsive m-t-20">
                            <table id="myTable" class="table table-bordered table-striped">
                                <thead>
                                    <tr>
                                        <th style="text-align:center">no</th>
                                        <th style="text-align:center">kata</th>
                                        <th style="text-align:center"><a href="<?php echo e(url('laplace_corection_seleksi_kata_proses')); ?>" class="btn btn-success">jumlah kata</a></th>
                                        <th style="text-align:center"><a href="<?php echo e(url('laplace_corection_pembobotan_proses')); ?>" class="btn btn-success">bobot</a></th>
                                        <th style="text-align:center"> sentimen</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <tr>
                                        <td style="text-align:center"></td>
                                        <td style="text-align:center">></td>
                                        <td style="text-align:center"></td>
                                        <td style="text-align:center"></td>
                                        <td style="text-align:center"></td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>

            </div>
        </div>
        <!-- End PAge Content -->
    </div>
    <!-- End Container fluid  -->
    <!-- footer -->
    <footer class="footer"> © 2018 All rights reserved. Template designed by <a href="https://colorlib.com">Colorlib</a></footer>
    <!-- End footer -->
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>

<!-- referensi div loading every time -->
<!-- https://crunchify.com/how-to-refresh-div-content-without-reloading-page-using-jquery-and-ajax/ -->



<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\analisa_sentimen\resources\views/pages/proses_training/naive_bayes/index.blade.php ENDPATH**/ ?>