<?php $__env->startSection('content'); ?>
<div class="page-wrapper">
    <!-- Bread crumb -->
    <div class="row page-titles">
        <div class="col-md-5 align-self-center">
            <h3 class="text-primary">Dashboard</h3> </div>
        <div class="col-md-7 align-self-center">
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="javascript:void(0)">Home</a></li>
                <li class="breadcrumb-item active">Dashboard</li>
            </ol>
        </div>
    </div>
    <!-- End Bread crumb -->
    <!-- Container fluid  -->
    <div class="container-fluid">
        <!-- Start Page Content -->
        <div class="row">
            <div class="col-12">

                <div class="card">
                    <div class="card-body">
                        <h4 class="card-title">Tabel Postagging</h4>
                        <h6 class="card-subtitle">tabel Postagging</h6>

                        <!-- <div id="show" align="left"></div> -->
                        <div class="card">
                            <h4><b>Note : Default digunakan ketika kata pada data testing tidak ada di data training atau jumlah kata = 0</b></h4>
                            <p>Default bobot kata sentimen positif : <?php echo $default_bobot_sentimen_positif ?></p>
                            <p>Default bobot kata sentimen negatif : <?php echo $default_bobot_sentimen_negatif ?></p>
                        </div>

                        <div class="table-responsive m-t-20">
                            <table id="myTable" class="table table-bordered table-striped">
                                <thead>
                                    <tr>
                                        <th style="text-align:center">no</th>
                                        <th style="text-align:center">kata</th>
                                        <th style="text-align:center"><a href="<?php echo e(url('laplace_corection_seleksi_kata_proses')); ?>" class="btn btn-success">jumlah kata</a></th>
                                        <th style="text-align:center"><a href="<?php echo e(url('laplace_corection_pembobotan_proses')); ?>" class="btn btn-success">bobot</a></th>
                                        <th style="text-align:center"> sentimen</th>
                                    </tr>
                                </thead>
                                <tbody>
                                  <?php
                                    $no = 1;
                                    foreach ($laplacecorrection as $data) {
                                      // code...

                                  ?>
                                    <tr>
                                        <td style="text-align:center"><?php echo $no++ ?></td>
                                        <td style="text-align:center"><?php echo $data->kata ?></td>
                                        <td style="text-align:center"><?php echo $data->jumlah_kata ?></td>
                                        <td style="text-align:center"><?php echo $data->bobot ?> <button class="btn btn-success btn-xs sweet-alert_detail_bobot" value="<?php echo $data->id_laplacecorrection ?>"><i class="fa fa-info" aria-hidden="true"></i></button></td>
                                        <td style="text-align:center"><?php echo $data->sentimen ?></td>
                                    </tr>
                                  <?php
                                  }
                                  ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>

            </div>
        </div>
        <!-- End PAge Content -->
    </div>
    <!-- End Container fluid  -->
    <!-- footer -->
    <footer class="footer"> © 2018 All rights reserved. Template designed by <a href="https://colorlib.com">Colorlib</a></footer>
    <!-- End footer -->
    <div id="detail_laplacecorrection" class="modal" role="dialog">
    <div class="modal-dialog modal-lg">

      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header">
          <!-- <button type="button" class="close" data-dismiss="modal">&times;</button> -->
          <h4 class="modal-title" id="modal_tite"></h4>
        </div>
        <div class="modal-body">
          <div class="row">
              <div class="col-6">
                  <div class="card">
                      <div class="card-body">
                        <table>
                          <tr>
                            <td>
                              <h5 style="text-align:left">kata :</h5>
                            </td>
                            <td>
                              <h5 id="kata"></h5>
                            </td>
                          </tr>
                          <tr>
                            <td>
                              <h5 style="text-align:left">jumlah kata :</h5>
                            </td>
                            <td>
                              <h5 id="jumlah_kata"></h5>
                            </td>
                          </tr>
                          <tr>
                            <td>
                              <h5 style="text-align:left">jumlah kata per kata :</h5>
                            </td>
                            <td>
                              <h5 id="jumlah_kata_per_kata"></h5>
                            </td>
                          </tr>
                          <tr>
                            <td>
                              <h5 style="text-align:left">jumlah semua kata :</h5>
                            </td>
                            <td>
                              <h5 id="jumlah_kata_semua_kata"></h5>
                            </td>
                          </tr>
                        </table>
                      </div>
                  </div>
              </div>
              <div class="col-6">
                  <div class="card">
                      <div class="card-body">
                        <table>
                          <tr>
                            <td style="vertical-align: top; text-align: left;">
                              <h5 style=" width:55px">
                                rumus
                              </h5>
                            </td>
                            <td style="vertical-align: top; text-align: left;">
                              <h5 style=" width:5px">
                                :
                              </h5>
                            </td>
                            <td style="vertical-align: top; text-align: left;">
                              <h5>
                                (jumlah kata + 1)/(jumlah kata per kata + jumlah semua kata)
                              </h5>
                            </td>
                          </tr>
                          <tr>
                            <td style="vertical-align: top; text-align: left;">
                              <h5 style=" width:55px">

                              </h5>
                            </td>
                            <td style="vertical-align: top; text-align: left;">
                              <h5 style=" width:5px">
                                :
                              </h5>
                            </td>
                            <td style="vertical-align: top; text-align: left;">
                              <h5 id="rumus"></h5>
                            </td>
                          </tr>
                          <tr>
                            <td style="vertical-align: top; text-align: left;">
                              <h5 style=" width:55px">

                              </h5>
                            </td>
                            <td style="vertical-align: top; text-align: left;">
                              <h5 style=" width:5px">
                                :
                              </h5>
                            </td>
                            <td style="vertical-align: top; text-align: left;">
                              <h5 id="hasil_rumus"></h5>
                            </td>
                          </tr>
                        </table>
                      </div>
                  </div>
              </div>
            </div>

        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        </div>
      </div>

    </div>
    </div>




</div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>

<script>

$(document).on('click','.sweet-alert_detail_bobot',function(){


    var id_laplacecorrection= $(this).val();
    var kata = '';

    $.get('<?php echo url('/laplace_corection_detail'); ?>' + '/' + id_laplacecorrection, function (data) {
      //success data
      // var obj = JSON.parse(json);
      // console.log(obj[0]["data.name"]);

      //array[0] = kata
      //array[1] = jumlah kata
      //array[2] = jumlah kata per kata
      //array[3] = jumlah semua kata
      //array[4] = sentimen
      var data = JSON.parse(data);
      console.log(data[0]);
      kata = data[0];
      // jumlah_kata data[1];
      // jumlah_kata_per_kata = data[2];
      // jumlah_kata_semua_kata = data[3];
      // document.getElementById("modal_tite").innerHTML= 'detail bobot per kata ('+data[0]+')';
      // document.getElementById("rumus").innerHTML= '('+data[1]+'+1)/('+data[2]+'+'+data[3]+')';
      // document.getElementById("hasil_rumus").innerHTML= (data[1]+1)/(data[2]+data[3]);

      var swal_html = '<div class="row">'+
                        '<div class="col-6">'+
                          '<div class="card">'+
                            '<div class="card-body">'+
                              '<table>'+
                                '<tr>'+
                                  '<td style="vertical-align: top; text-align: left;">'+
                                    'kata'+
                                  '</td>'+
                                  '<td>'+
                                    ':'+
                                  '</td>'+
                                  '<td>'+
                                    data[0]+
                                  '</td>'+
                                '</tr>'+
                                '<tr>'+
                                  '<td style="vertical-align: top; text-align: left;">'+
                                    'jumlah kata'+
                                  '</td>'+
                                  '<td>'+
                                    ':'+
                                  '</td>'+
                                  '<td>'+
                                    data[1]+
                                  '</td>'+
                                '</tr>'+
                                '<tr>'+
                                  '<td style="vertical-align: top; text-align: left;">'+
                                    'jumlah kata per kata '+'('+data[4]+')'+
                                  '</td>'+
                                  '<td>'+
                                    ':'+
                                  '</td>'+
                                  '<td>'+
                                    data[2]+
                                  '</td>'+
                                '</tr>'+
                                '<tr>'+
                                  '<td style="vertical-align: top; text-align: left;">'+
                                    'jumlah semua kata sentimen '+'('+data[4]+')'+
                                  '</td>'+
                                  '<td>'+
                                    ':'+
                                  '</td>'+
                                  '<td>'+
                                    data[3]+
                                  '</td>'+
                                '</tr>'+
                              '</table>'+
                            '</div>'+
                          '</div>'+
                        '</div>'+
                        '<div class="col-6">'+
                          '<div class="card">'+
                            '<div class="card-body">'+
                              '<table>'+
                                '<tr>'+
                                  '<td style="vertical-align: top; text-align: left;">'+
                                    'rumus'+
                                  '</td>'+
                                  '<td style="vertical-align: top; text-align: left;">'+
                                    ':'+
                                  '</td>'+
                                  '<td style="vertical-align: top; text-align: left;">'+
                                    '(jumlah kata + 1)/(jumlah kata per kata + jumlah semua kata)'+
                                  '</td>'+
                                '</tr>'+
                                '<tr>'+
                                  '<td style="vertical-align: top; text-align: left;">'+
                                    ''+
                                  '</td>'+
                                  '<td>'+
                                    ':'+
                                  '</td>'+
                                  '<td style="vertical-align: top; text-align: left;">'+
                                    '('+data[1]+'+1)/('+data[2]+'+'+data[3]+')'+
                                  '</td>'+
                                '</tr>'+
                                '<tr>'+
                                  '<td style="vertical-align: top; text-align: left;">'+
                                    ''+
                                  '</td>'+
                                  '<td>'+
                                    ':'+
                                  '</td>'+
                                  '<td style="vertical-align: top; text-align: left;">'+
                                    (data[1]+1)/(data[2]+data[3])+
                                  '</td>'+
                                '</tr>'+
                              '</table>'+
                            '</div>'+
                          '</div>'+
                        '</div>'+
                      '</div>';
        swal({
          title: kata+' ('+data[4]+')',
          html: swal_html,
          customClass: 'swal-wide'});
      });

    })



</script>




<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\analisa_sentimen\resources\views/pages/proses_training/laplacecorrection/index.blade.php ENDPATH**/ ?>