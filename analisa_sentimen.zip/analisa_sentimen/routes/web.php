<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});

// Route::get('/login', 'homeController@index');



Auth::routes();

Route::get('/home', 'HomeController@index')->name('home');

Route::group(['middleware'=>'auth'], function(){

//-------------------------------------------------- proses import eksport  -------------------------------------------------------//
Route::get('data_training_export', 'datatrainingController@export')->name('data_training_export');
Route::post('data_training_import', 'datatrainingController@import')->name('data_training_import');
Route::get('data_training_download_template_excel','datatrainingController@data_training_download_template_excel');

Route::get('data_testing_export', 'scrapingController@export')->name('data_testing_export');
Route::post('data_testing_import', 'scrapingController@import')->name('data_testing_import');
Route::get('data_testing_download_template_excel','scrapingController@data_testing_download_template_excel');

//----------------------------------------------------- proses training ----------------------------------------------------------//

Route::get('/dashboard','dashboardController@index');

Route::get('/laporan_skripsi','dashboardController@laporan_skripsi');
Route::get('/jurnal_skripsi','dashboardController@jurnal_skripsi');

Route::get('/referensi_algoritma_preprocessing_1','dashboardController@referensi_algoritma_preprocessing_1');
Route::get('/referensi_algoritma_preprocessing_2','dashboardController@referensi_algoritma_preprocessing_2');

Route::get('/referensi_algoritma_laplacecorrection_1','dashboardController@referensi_algoritma_laplacecorrection_1');
Route::get('/referensi_algoritma_laplacecorrection_2','dashboardController@referensi_algoritma_laplacecorrection_2');

Route::get('/referensi_algoritma_postagging_viterbi_1','dashboardController@referensi_algoritma_postagging_viterbi_1');
Route::get('/referensi_algoritma_postagging_viterbi_2','dashboardController@referensi_algoritma_postagging_viterbi_2');

Route::get('/referensi_algoritma_naive_bayes_1','dashboardController@referensi_algoritma_naive_bayes_1');
Route::get('/referensi_algoritma_naive_bayes_2','dashboardController@referensi_algoritma_naive_bayes_2');

Route::get('/referensi_dataset_1','dashboardController@referensi_dataset_1');


//----------------------------------------------------- proses training ----------------------------------------------------------//

Route::get('/data_training','datatrainingController@index');

Route::get('/preprocessing_cleaning_data_training', 'preprocessingtrainingController@cleaning_index');
Route::get('/preprocessing_cleaning_data_training_proses', 'preprocessingtrainingController@cleaning_proses');

Route::get('/preprocessing_casefolding_data_training', 'preprocessingtrainingController@casefolding_index');
Route::get('/preprocessing_casefolding_data_training_proses', 'preprocessingtrainingController@casefolding_proses');

Route::get('/preprocessing_tokenizing_data_training', 'preprocessingtrainingController@tokenizing_index');

Route::get('/preprocessing_normalisasi_data_training', 'preprocessingtrainingController@normalisasi_index');
Route::get('/preprocessing_normalisasi_data_training_proses', 'preprocessingtrainingController@normalisasi_proses');

Route::get('/preprocessing_filtering_data_training', 'preprocessingtrainingController@filtering_index');
Route::get('/preprocessing_filtering_data_training_proses', 'preprocessingtrainingController@filtering_proses');

Route::get('/preprocessing_stemming_data_training', 'preprocessingtrainingController@stemming_index');
Route::get('/preprocessing_stemming_data_training_proses', 'preprocessingtrainingController@stemming_proses');

//----------------------------------------------------- proses testing ----------------------------------------------------------//
Route::get('/scraping', 'scrapingController@index');
Route::post('/scraping_start', 'scrapingController@scraping_start');
Route::get('/scraping_stop', 'scrapingController@scraping_stop');
Route::get('/scraping_delete_semua', 'scrapingController@scraping_delete_semua');
Route::get('/scraping_jumlah_scrape', 'scrapingController@scraping_jumlah_scrape');

//tahap preprocessing
Route::get('/preprocessing', 'preprocessingController@index');

//casefolding
Route::get('/preprocessing_cleaning', 'preprocessingController@cleaning_index');
Route::get('/preprocessing_cleaning_proses', 'preprocessingController@cleaning_proses');

Route::get('/preprocessing_casefolding', 'preprocessingController@casefolding_index');
Route::get('/preprocessing_casefolding_proses', 'preprocessingController@casefolding_proses');

Route::get('/preprocessing_tokenizing', 'preprocessingController@tokenizing_index');

Route::get('/preprocessing_normalisasi', 'preprocessingController@normalisasi_index');
Route::get('/preprocessing_normalisasi_proses', 'preprocessingController@normalisasi_proses');

Route::get('/preprocessing_filtering', 'preprocessingController@filtering_index');
Route::get('/preprocessing_filtering_proses', 'preprocessingController@filtering_proses');

Route::get('/preprocessing_stemming', 'preprocessingController@stemming_index');
Route::get('/preprocessing_stemming_proses', 'preprocessingController@stemming_proses');

//tahap opinion detection
Route::get('/opinion_detection', 'opiniondetectionController@index');
Route::get('/opinion_detection_postagging', 'opiniondetectionController@opinion_postagging_viterbi');
Route::get('/opinion_detection_rule_proses', 'opiniondetectionController@opinion_detection_rule_proses');
Route::get('/opinion_detection_detail/{id}', 'opiniondetectionController@opinion_detection_detail');

//tahap laplace corectiom
Route::get('laplace_corection', 'laplacecorrectionController@index');
Route::get('laplace_corection_seleksi_kata_proses', 'laplacecorrectionController@proses_seleksi_kata_laplacecorrection');
Route::get('laplace_corection_pembobotan_proses', 'laplacecorrectionController@proses_pembobotan_laplacecorrection');
Route::get('laplace_corection_detail/{id}','laplacecorrectionController@laplace_correction_detail');

//tahap naive bayes
Route::get('naive_bayes', 'naivebayesController@index');
Route::get('naive_bayes_proses', 'naivebayesController@naive_bayes_proses');
Route::get('naive_bayes_detail/{id}', 'naivebayesController@naive_bayes_detail');
// Route::get('naive');

//tahap akurasi
Route::get('akurasi','akurasiController@index');

});
